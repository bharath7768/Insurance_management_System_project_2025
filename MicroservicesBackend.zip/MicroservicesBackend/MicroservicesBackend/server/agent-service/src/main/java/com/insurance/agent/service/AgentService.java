package com.insurance.agent.service;

import com.insurance.agent.client.NotificationServiceClient;
import com.insurance.agent.dto.AgentProfileUpdateRequest;
import com.insurance.agent.dto.AgentRequest;
import com.insurance.agent.dto.AgentResponse;
import com.insurance.agent.dto.NotificationRequest;
import com.insurance.agent.entity.Agent;
import com.insurance.agent.repository.AgentRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class AgentService {
    
    private final AgentRepository agentRepository;
    private final NotificationServiceClient notificationServiceClient;
    
    public AgentResponse createAgent(AgentRequest request, Long userId) {
        log.info("Creating agent for user ID: {}", userId);
        
        if (agentRepository.existsByEmail(request.getEmail())) {
            log.error("Agent with email {} already exists", request.getEmail());
            throw new RuntimeException("Agent with this email already exists");
        }
        
        if (agentRepository.existsByLicenseNumber(request.getLicenseNumber())) {
            log.error("Agent with license number {} already exists", request.getLicenseNumber());
            throw new RuntimeException("Agent with this license number already exists");
        }
        
        Agent agent = new Agent();
        agent.setName(request.getName());
        agent.setEmail(request.getEmail());
        agent.setPhone(request.getPhone());
        agent.setAddress(request.getAddress());
        agent.setLicenseNumber(request.getLicenseNumber());
        agent.setSpecialization(request.getSpecialization());
        agent.setCommissionRate(request.getCommissionRate());
        agent.setUserId(userId);
        agent.setIsActive(true);
        
        Agent savedAgent = agentRepository.save(agent);
        log.info("Agent created successfully with ID: {}", savedAgent.getAgentId());
        
        // Send welcome notification
        try {
            var notification = new NotificationRequest();
            notification.setCustomerId(savedAgent.getAgentId());
            notification.setTargetRole("AGENT");
            notification.setTitle("Welcome to Insurance Portal");
            notification.setMessage("Welcome! Your agent account has been created successfully.");
            notification.setType("WELCOME_MESSAGE");
            notification.setCategory("SUCCESS");
            notification.setPriority("MEDIUM");
            notification.setSendEmail(false); // Disabled - SMTP blocked by company network
            notification.setSendSms(false);
            
            notificationServiceClient.createNotification(notification, "2", "ADMIN");
            log.info("Welcome notification sent to agent: {}", savedAgent.getAgentId());
        } catch (Exception e) {
            log.error("Failed to send welcome notification to agent: {}", savedAgent.getAgentId(), e);
        }
        
        return mapToResponse(savedAgent);
    }
    
    private void sendAgentWelcomeNotification(Agent agent) {
        try {
            // Agent notification - using agentId as targetId with AGENT role
            NotificationRequest notification = new NotificationRequest();
            notification.setCustomerId(agent.getAgentId()); // Using agentId as targetId
            notification.setTargetRole("AGENT");
            notification.setTitle("Welcome to Our Agent Network!");
            notification.setMessage("Welcome " + agent.getName() + "! Your agent profile has been created successfully. " +
                "License: " + agent.getLicenseNumber() + ". Specialization: " + agent.getSpecialization() + 
                ". You can now start managing policies and helping customers.");
            notification.setType("WELCOME_MESSAGE");
            notification.setCategory("SUCCESS");
            notification.setPriority("MEDIUM");
            notification.setSendEmail(false);
            notification.setSendSms(false);
            
            notificationServiceClient.createNotification(notification, "2", "ADMIN");
            log.info("Welcome notification sent for agent: {}", agent.getAgentId());
        } catch (Exception e) {
            log.error("Failed to send welcome notification for agent: {}", agent.getAgentId(), e);
        }
    }

    public AgentResponse getAgentById(Long agentId) {
        log.debug("Fetching agent with ID: {}", agentId);
        Agent agent = agentRepository.findById(agentId)
                .orElseThrow(() -> new RuntimeException("Agent not found"));
        return mapToResponse(agent);
    }
    
    public AgentResponse getAgentByUserId(Long userId) {
        log.debug("Fetching agent with userId: {}", userId);
        Agent agent = agentRepository.findByUserId(userId)
                .orElseThrow(() -> new RuntimeException("Agent not found for userId: " + userId));
        return mapToResponse(agent);
    }
    
    public List<AgentResponse> getAllAgents(Pageable pageable) {
        log.debug("Fetching all agents with pagination");
        Page<Agent> agents = agentRepository.findAll(pageable);
        return agents.getContent().stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }
    
    public List<AgentResponse> getAllAgents(Pageable pageable, Boolean active, String specialization) {
        log.info("=== FILTERING AGENTS ===");
        log.info("Active filter: {}", active);
        log.info("Specialization filter: {}", specialization);
        
        List<Agent> agents;
        
        if (active != null && specialization != null) {
            log.info("Using filter: findByIsActiveAndSpecializationContainingIgnoreCase({}, {})", active, specialization);
            agents = agentRepository.findByIsActiveAndSpecializationContainingIgnoreCase(active, specialization);
        } else if (active != null) {
            log.info("Using filter: findByIsActive({})", active);
            agents = agentRepository.findByIsActive(active);
        } else if (specialization != null) {
            log.info("Using filter: findBySpecializationContainingIgnoreCase({})", specialization);
            agents = agentRepository.findBySpecializationContainingIgnoreCase(specialization);
        } else {
            log.info("No filters applied - getting all agents");
            Page<Agent> agentPage = agentRepository.findAll(pageable);
            agents = agentPage.getContent();
        }
        
        log.info("Found {} agents total", agents.size());
        
        // Let's also log each agent's active status for debugging
        for (Agent agent : agents) {
            log.info("Agent ID: {}, Name: {}, IsActive: {}", agent.getAgentId(), agent.getName(), agent.getIsActive());
        }
        
        return agents.stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }
    
    public List<AgentResponse> getActiveAgents() {
        log.debug("Fetching active agents");
        List<Agent> agents = agentRepository.findByIsActive(true);
        return agents.stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }
    
    public AgentResponse updateAgent(Long agentId, AgentRequest request, Long userId, String role) {
        log.info("Updating agent with ID: {} for user: {}", agentId, userId);
        
        Agent agent = agentRepository.findById(agentId)
                .orElseThrow(() -> new RuntimeException("Agent not found"));
        
        // Check if the agent belongs to the user (for AGENT role)
        if (!agent.getUserId().equals(userId) && !role.equals("ADMIN")) {
            log.error("User {} attempted to update agent {} without permission", userId, agentId);
            throw new RuntimeException("Unauthorized to update this agent");
        }
        
        agent.setName(request.getName());
        agent.setEmail(request.getEmail());
        agent.setPhone(request.getPhone());
        agent.setAddress(request.getAddress());
        agent.setSpecialization(request.getSpecialization());
        agent.setCommissionRate(request.getCommissionRate());
        
        Agent updatedAgent = agentRepository.save(agent);
        log.info("Agent updated successfully with ID: {}", updatedAgent.getAgentId());
        
        return mapToResponse(updatedAgent);
    }
    
    public AgentResponse updateAgentByUserId(Long userId, AgentProfileUpdateRequest request) {
        log.info("Updating agent profile for user ID: {}", userId);
        
        Agent agent = agentRepository.findByUserId(userId)
                .orElseThrow(() -> new RuntimeException("Agent not found for user"));
        
        // Only update allowed fields (name, phone, address) - other fields should not be changed
        if (request.getName() != null) {
            agent.setName(request.getName());
        }
        if (request.getPhone() != null) {
            agent.setPhone(request.getPhone());
        }
        if (request.getAddress() != null) {
            agent.setAddress(request.getAddress());
        }
        // Note: email, licenseNumber, specialization, commissionRate are NOT updated
        
        Agent updatedAgent = agentRepository.save(agent);
        log.info("Agent profile updated successfully for user ID: {}", userId);
        
        return mapToResponse(updatedAgent);
    }
    
    public void deactivateAgent(Long agentId) {
        log.info("Deactivating agent with ID: {}", agentId);
        Agent agent = agentRepository.findById(agentId)
                .orElseThrow(() -> new RuntimeException("Agent not found"));
        
        agent.setIsActive(false);
        agentRepository.save(agent);
        log.info("Agent deactivated successfully with ID: {}", agentId);
    }
    
    public void activateAgent(Long agentId) {
        log.info("Activating agent with ID: {}", agentId);
        Agent agent = agentRepository.findById(agentId)
                .orElseThrow(() -> new RuntimeException("Agent not found"));
        
        agent.setIsActive(true);
        agentRepository.save(agent);
        log.info("Agent activated successfully with ID: {}", agentId);
    }
    
    public void deleteAgent(Long agentId) {
        log.info("Deleting agent with ID: {}", agentId);
        if (!agentRepository.existsById(agentId)) {
            throw new RuntimeException("Agent not found");
        }
        agentRepository.deleteById(agentId);
        log.info("Agent deleted successfully with ID: {}", agentId);
    }
    
    private AgentResponse mapToResponse(Agent agent) {
        return new AgentResponse(
                agent.getAgentId(),
                agent.getName(),
                agent.getEmail(),
                agent.getPhone(),
                agent.getAddress(),
                agent.getLicenseNumber(),
                agent.getSpecialization(),
                agent.getCommissionRate(),
                agent.getIsActive(),
                agent.getCreatedAt(),
                agent.getUpdatedAt(),
                agent.getUserId()
        );
    }

    public boolean isAgentActive(Long agentId) {
        Agent agent = agentRepository.findById(agentId)
                .orElseThrow(() -> new RuntimeException("Agent not found"));
        return agent.getIsActive();
    }
}

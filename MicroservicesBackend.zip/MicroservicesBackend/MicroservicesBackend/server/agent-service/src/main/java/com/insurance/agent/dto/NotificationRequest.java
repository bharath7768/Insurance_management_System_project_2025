package com.insurance.agent.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class NotificationRequest {
    private Long customerId;           // Acts as targetId
    private String targetRole = "USER"; // USER/AGENT/ADMIN (using String for simplicity)
    private String title;
    private String message;
    private String type;              // Using String to avoid enum dependency
    private String category = "info"; // success/warning/info/error (lowercase to match notification service)
    private String priority = "MEDIUM"; // HIGH/MEDIUM/LOW
    private Boolean sendEmail = false;
    private Boolean sendSms = false;
}

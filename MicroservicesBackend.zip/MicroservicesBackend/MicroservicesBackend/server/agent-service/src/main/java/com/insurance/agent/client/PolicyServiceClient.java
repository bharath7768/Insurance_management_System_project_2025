package com.insurance.agent.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;

import java.util.List;

@FeignClient(name = "policy-service", path = "/api/policies")
public interface PolicyServiceClient {
    
    @GetMapping("/agent/{agentId}")
    ResponseEntity<List<Object>> getPoliciesByAgentId(
            @PathVariable Long agentId,
            @RequestHeader("X-User-Id") String userId,
            @RequestHeader("X-User-Role") String role
    );
} 

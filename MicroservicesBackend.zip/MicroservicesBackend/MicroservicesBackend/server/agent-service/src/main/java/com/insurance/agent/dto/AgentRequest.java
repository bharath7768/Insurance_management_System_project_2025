package com.insurance.agent.dto;

import jakarta.validation.constraints.*;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class AgentRequest {
    @NotBlank(message = "Name is required")
    private String name;
    
    @NotBlank(message = "Email is required")
    @Email(message = "Email should be valid")
    private String email;
    
    @NotBlank(message = "Phone is required")
    @Pattern(regexp = "^[+]?[0-9]{10,15}$", message = "Phone number should be valid")
    private String phone;
    
    @NotBlank(message = "Address is required")
    private String address;
    
    @NotBlank(message = "License number is required")
    private String licenseNumber;
    
    private String specialization;
    
    @DecimalMin(value = "0.0", message = "Commission rate must be positive")
    @DecimalMax(value = "100.0", message = "Commission rate must not exceed 100%")
    private BigDecimal commissionRate;
} 

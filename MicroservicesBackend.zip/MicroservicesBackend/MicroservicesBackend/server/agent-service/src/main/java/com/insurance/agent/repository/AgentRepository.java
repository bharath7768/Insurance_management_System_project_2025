package com.insurance.agent.repository;

import com.insurance.agent.entity.Agent;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface AgentRepository extends JpaRepository<Agent, Long> {
    Optional<Agent> findByUserId(Long userId);
    Optional<Agent> findByEmail(String email);
    Optional<Agent> findByLicenseNumber(String licenseNumber);
    List<Agent> findByIsActive(Boolean isActive);
    List<Agent> findBySpecializationContainingIgnoreCase(String specialization);
    List<Agent> findByIsActiveAndSpecializationContainingIgnoreCase(Boolean isActive, String specialization);
    boolean existsByEmail(String email);
    boolean existsByLicenseNumber(String licenseNumber);
} 

package com.insurance.agent.client;

import com.insurance.agent.dto.NotificationRequest;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

@FeignClient(name = "notification-service", path = "/api/notifications")
public interface NotificationServiceClient {
    
    @PostMapping
    ResponseEntity<Object> createNotification(
            @RequestBody NotificationRequest request,
            @RequestHeader("X-User-Id") String userId,
            @RequestHeader("X-User-Role") String role
    );
} 

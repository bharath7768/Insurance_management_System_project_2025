package com.insurance.agent.controller;

import com.insurance.agent.dto.AgentProfileUpdateRequest;
import com.insurance.agent.dto.AgentRequest;
import com.insurance.agent.dto.AgentResponse;
import com.insurance.agent.service.AgentService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import com.insurance.agent.entity.Agent;
import com.insurance.agent.repository.AgentRepository;

import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/agents")
@RequiredArgsConstructor
@Slf4j
public class AgentController {
    
    private final AgentService agentService;
    private final AgentRepository agentRepository;
    
    @PostMapping
    public ResponseEntity<AgentResponse> createAgent(
            @Valid @RequestBody AgentRequest request,
            @RequestHeader("X-User-Id") Long userId,
            @RequestHeader("X-User-Role") String role) {
        
        log.info("Creating agent request from user: {} with role: {}", userId, role);
        
        // Only ADMIN can create agents
        if (!"ADMIN".equals(role)) {
            log.warn("Unauthorized agent creation attempt by role: {}", role);
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(null);
        }
        
        try {
            AgentResponse response = agentService.createAgent(request, userId);
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        } catch (RuntimeException e) {
            log.error("Error creating agent: {}", e.getMessage());
            return ResponseEntity.badRequest().body(null);
        }
    }

    @GetMapping("/{agentId}")
    public ResponseEntity<AgentResponse> getAgentById(
            @PathVariable Long agentId,
            @RequestHeader("X-User-Id") Long userId,
            @RequestHeader("X-User-Role") String role) {

        log.debug("Getting agent {} by user {} with role {}", agentId, userId, role);

        try {
            AgentResponse response = agentService.getAgentById(agentId);

            // Access control logic
            if ("ADMIN".equals(role)) {
                // ADMIN can view any agent
                log.debug("Admin access granted for agent {}", agentId);
                return ResponseEntity.ok(response);
            } else if ("AGENT".equals(role)) {
                // AGENT can only view their own profile
                if (response.getAgentId().equals(userId)) {
                    log.debug("Agent access granted for own profile {}", agentId);
                    return ResponseEntity.ok(response);
                } else {
                    log.warn("Agent {} attempted to access different agent profile {}", userId, agentId);
                    return ResponseEntity.status(HttpStatus.FORBIDDEN).body(null);
                }
            } else {
                // USER or other roles cannot access
                log.warn("User {} with role {} denied access to agent profile {}", userId, role, agentId);
                return ResponseEntity.status(HttpStatus.FORBIDDEN).body(null);
            }

        } catch (RuntimeException e) {
            log.error("Error fetching agent {}: {}", agentId, e.getMessage());
            return ResponseEntity.notFound().build();
        }
    }
    
    @GetMapping("/profile")
    public ResponseEntity<AgentResponse> getMyProfile(
            @RequestHeader("X-User-Id") Long userId,
            @RequestHeader("X-User-Role") String role) {
        
        log.debug("Getting profile for user: {}", userId);
        
        if (!"AGENT".equals(role)) {
            log.warn("Non-agent user {} attempted to access agent profile", userId);
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(null);
        }
        
        try {
            AgentResponse response = agentService.getAgentByUserId(userId);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            log.error("Error fetching profile for user {}: {}", userId, e.getMessage());
            return ResponseEntity.notFound().build();
        }
    }
    
    @PutMapping("/profile")
    public ResponseEntity<AgentResponse> updateMyProfile(
            @Valid @RequestBody AgentProfileUpdateRequest request,
            @RequestHeader("X-User-Id") Long userId,
            @RequestHeader("X-User-Role") String role) {
        
        log.info("Updating profile for user: {}", userId);
        
        if (!"AGENT".equals(role)) {
            log.warn("Non-agent user {} attempted to update agent profile", userId);
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(null);
        }
        
        try {
            AgentResponse response = agentService.updateAgentByUserId(userId, request);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            log.error("Error updating profile for user {}: {}", userId, e.getMessage());
            return ResponseEntity.badRequest().body(null);
        }
    }
    
    @GetMapping
    public ResponseEntity<List<AgentResponse>> getAllAgents(
            Pageable pageable,
            @RequestParam(required = false) Boolean active,
            @RequestParam(required = false) String specialization,
            @RequestHeader("X-User-Role") String role) {
        
        log.debug("Getting agents by user with role: {}, active: {}, specialization: {}", role, active, specialization);
        
        // Only ADMIN and AGENT can view agents
        if (!"ADMIN".equals(role) && !"AGENT".equals(role)) {
            log.warn("Unauthorized access attempt to view agents by role: {}", role);
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(null);
        }
        
        List<AgentResponse> agents = agentService.getAllAgents(pageable, active, specialization);
        return ResponseEntity.ok(agents);
    }
    
    @GetMapping("/active")
    public ResponseEntity<List<AgentResponse>> getActiveAgents() {
        log.debug("Getting active agents");
        
        List<AgentResponse> agents = agentService.getActiveAgents();
        return ResponseEntity.ok(agents);
    }
    
    @PutMapping("/{agentId}")
    public ResponseEntity<AgentResponse> updateAgent(
            @PathVariable Long agentId,
            @Valid @RequestBody AgentRequest request,
            @RequestHeader("X-User-Id") Long userId,
            @RequestHeader("X-User-Role") String role) {
        
        log.info("Updating agent {} by user {} with role {}", agentId, userId, role);
        
        try {
            AgentResponse response = agentService.updateAgent(agentId, request, userId, role);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            log.error("Error updating agent {}: {}", agentId, e.getMessage());
            return ResponseEntity.badRequest().body(null);
        }
    }
    
    @PostMapping("/{agentId}/deactivate")
    public ResponseEntity<String> deactivateAgent(
            @PathVariable Long agentId,
            @RequestHeader("X-User-Role") String role) {
        
        log.info("Deactivating agent {} by user with role {}", agentId, role);
        
        // Only ADMIN can deactivate agents
        if (!"ADMIN".equals(role)) {
            log.warn("Unauthorized deactivation attempt by role: {}", role);
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Access denied");
        }
        
        try {
            if (!agentService.isAgentActive(agentId)) {
                log.warn("Attempt to Deactivate already deactivated agent {}", agentId);
                return ResponseEntity.badRequest()
                        .body("{\"message\": \"Agent already deactive\"}");
            }
            agentService.deactivateAgent(agentId);
            return ResponseEntity.ok("{\"message\": \"Agent deactivated successfully\", \"agentId\": " + agentId + ", \"isActive\": false}");
        } catch (RuntimeException e) {
            log.error("Error deactivating agent {}: {}", agentId, e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("error", "Agent not found").toString());
        }
    }
    
    @PostMapping("/{agentId}/activate")
    public ResponseEntity<String> activateAgent(
            @PathVariable Long agentId,
            @RequestHeader("X-User-Role") String role) {
        
        log.info("Activating agent {} by user with role {}", agentId, role);
        
        // Only ADMIN can activate agents
        if (!"ADMIN".equals(role)) {
            log.warn("Unauthorized activation attempt by role: {}", role);
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Access denied");
        }
        
        try {
            if (agentService.isAgentActive(agentId)) {
                log.warn("Attempt to activate already active agent {}", agentId);
                return ResponseEntity.badRequest()
                        .body("{\"message\": \"Agent already active\"}");
            }
            agentService.activateAgent(agentId);
            return ResponseEntity.ok("{\"message\": \"Agent activated successfully\", \"agentId\": " + agentId + ", \"isActive\": true}");
        } catch (RuntimeException e) {
            log.error("Error activating agent {}: {}", agentId, e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("error", "Agent not found").toString());
        }
    }
    
    @DeleteMapping("/{agentId}")
    public ResponseEntity<Void> deleteAgent(
            @PathVariable Long agentId,
            @RequestHeader("X-User-Role") String role) {
        
        log.info("Deleting agent {} by user with role {}", agentId, role);
        
        // Only ADMIN can delete agents
        if (!"ADMIN".equals(role)) {
            log.warn("Unauthorized deletion attempt by role: {}", role);
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }
        
        try {
            agentService.deleteAgent(agentId);
            return ResponseEntity.noContent().build();
        } catch (RuntimeException e) {
            log.error("Error deleting agent {}: {}", agentId, e.getMessage());
            return ResponseEntity.notFound().build();
        }
    }


    @GetMapping("/by-user/{userId}")
    public ResponseEntity<AgentResponse> getAgentByUserId(@PathVariable Long userId) {
        log.debug("Getting agent by userId: {}", userId);
        
        try {
            AgentResponse agent = agentService.getAgentByUserId(userId);
            return ResponseEntity.ok(agent);
        } catch (RuntimeException e) {
            log.error("Agent not found for userId {}: {}", userId, e.getMessage());
            return ResponseEntity.notFound().build();
        }
    }
}

package com.insurance.agent.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AgentResponse {
    private Long agentId;
    private String name;
    private String email;
    private String phone;
    private String address;
    private String licenseNumber;
    private String specialization;
    private BigDecimal commissionRate;
    private Boolean isActive;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private Long userId;
} 

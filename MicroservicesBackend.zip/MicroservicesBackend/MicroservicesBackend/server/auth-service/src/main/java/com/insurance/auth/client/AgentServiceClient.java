package com.insurance.auth.client;

import com.insurance.auth.dto.AgentCreationRequest;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

@FeignClient(
    name = "agent-service", 
    path = "/api/agents",
    configuration = com.insurance.auth.config.FeignConfig.class
)
public interface AgentServiceClient {
    
    @PostMapping
    ResponseEntity<Object> createAgent(
            @RequestBody AgentCreationRequest request,
            @RequestHeader("X-User-Id") String userId,
            @RequestHeader("X-User-Role") String role
    );
    
    @GetMapping("/by-user/{userId}")
    ResponseEntity<Object> getAgentByUserId(@PathVariable Long userId);
} 

package com.insurance.auth.entity;

public enum Role {
    ADMIN, AGENT, USER
} 

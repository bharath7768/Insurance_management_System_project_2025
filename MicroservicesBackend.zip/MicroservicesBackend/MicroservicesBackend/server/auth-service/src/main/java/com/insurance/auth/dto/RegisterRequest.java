package com.insurance.auth.dto;

import com.insurance.auth.entity.Role;
import jakarta.validation.constraints.*;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class RegisterRequest {
    @NotBlank(message = "Username is required")
    @Size(min = 3, max = 50, message = "Username must be between 3 and 50 characters")
    private String username;
    
    @NotBlank(message = "Email is required")
    @Email(message = "Email should be valid")
    private String email;
    
    @NotBlank(message = "Password is required")
    @Size(min = 6, message = "Password must be at least 6 characters")
    private String password;
    
    @NotNull(message = "Role is required")
    private Role role;
    
    // Additional fields for USER/AGENT creation by ADMIN
    @NotBlank(message = "Name is required")
    private String name;
    
    @NotBlank(message = "Phone is required")
    @Pattern(regexp = "^[0-9]{10}$", message = "Phone must be 10 digits")
    private String phone;
    
    @NotBlank(message = "Address is required")
    @Size(min = 10, max = 200, message = "Address must be between 10 and 200 characters")
    private String address;
    
    // Agent-specific fields (required only when role = AGENT)
    private String licenseNumber;
    
    private String specialization;
    
    @DecimalMin(value = "0.0", message = "Commission rate must be positive")
    @DecimalMax(value = "50.0", message = "Commission rate cannot exceed 50%")
    private BigDecimal commissionRate;
} 

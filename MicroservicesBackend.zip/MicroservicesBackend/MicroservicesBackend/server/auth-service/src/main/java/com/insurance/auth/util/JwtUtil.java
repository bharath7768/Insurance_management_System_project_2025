package com.insurance.auth.util;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.insurance.auth.entity.User;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
@Slf4j
public class JwtUtil {
    
    @Value("${jwt.secret}")
    private String jwtSecret;
    
    @Value("${jwt.expiration}")
    private Long jwtExpiration;
    
    public String generateToken(User user) {
        log.debug("Generating JWT token for user: {} with role: {}", user.getUsername(), user.getRole());
        
        return JWT.create()
                .withSubject(user.getId().toString())
                .withClaim("username", user.getUsername())
                .withClaim("role", user.getRole().name())
                .withIssuedAt(new Date())
                .withExpiresAt(new Date(System.currentTimeMillis() + jwtExpiration))
                .sign(Algorithm.HMAC256(jwtSecret));
    }
    
    public String generateTokenWithEntities(User user, Long customerId, Long agentId) {
        log.debug("Generating JWT token with entities for user: {} with role: {}", user.getUsername(), user.getRole());
        
        var builder = JWT.create()
                .withSubject(user.getId().toString())
                .withClaim("username", user.getUsername())
                .withClaim("role", user.getRole().name())
                .withIssuedAt(new Date())
                .withExpiresAt(new Date(System.currentTimeMillis() + jwtExpiration));
        
        // Add business entity IDs if they exist
        if (customerId != null) {
            builder.withClaim("customerId", customerId.toString());
        }
        if (agentId != null) {
            builder.withClaim("agentId", agentId.toString());
        }
        
        return builder.sign(Algorithm.HMAC256(jwtSecret));
    }
    
    public boolean validateToken(String token) {
        try {
            JWT.require(Algorithm.HMAC256(jwtSecret))
                .build()
                .verify(token);
            return true;
        } catch (JWTVerificationException e) {
            log.error("JWT validation failed: {}", e.getMessage());
            return false;
        }
    }
    
    public DecodedJWT decodeToken(String token) throws JWTVerificationException {
        return JWT.require(Algorithm.HMAC256(jwtSecret))
                .build()
                .verify(token);
    }
    
    public String getUserIdFromToken(String token) {
        try {
            DecodedJWT decodedJWT = decodeToken(token);
            return decodedJWT.getSubject();
        } catch (JWTVerificationException e) {
            log.error("Failed to extract user ID from token: {}", e.getMessage());
            return null;
        }
    }
    
    public String getUsernameFromToken(String token) {
        try {
            DecodedJWT decodedJWT = decodeToken(token);
            return decodedJWT.getClaim("username").asString();
        } catch (JWTVerificationException e) {
            log.error("Failed to extract username from token: {}", e.getMessage());
            return null;
        }
    }
    
    public String getRoleFromToken(String token) {
        try {
            DecodedJWT decodedJWT = decodeToken(token);
            return decodedJWT.getClaim("role").asString();
        } catch (JWTVerificationException e) {
            log.error("Failed to extract role from token: {}", e.getMessage());
            return null;
        }
    }
    
    public boolean isTokenExpired(String token) {
        try {
            DecodedJWT decodedJWT = decodeToken(token);
            return decodedJWT.getExpiresAt().before(new Date());
        } catch (JWTVerificationException e) {
            log.error("Failed to check token expiration: {}", e.getMessage());
            return true; // Consider invalid tokens as expired
        }
    }

    public String getClaim(DecodedJWT jwt, String claimName) {
        var claim = jwt.getClaim(claimName);
        return claim.isNull() ? null : claim.asString();
    }
} 

package com.insurance.auth.controller;

import com.insurance.auth.dto.*;
import com.insurance.auth.entity.Role;
import com.insurance.auth.entity.User;
import com.insurance.auth.repository.UserRepository;
import com.insurance.auth.service.AuthService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
@Slf4j
public class AuthController {
    
    private final AuthService authService;
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    
    /**
     * ADMIN-ONLY endpoint to create new users
     * Creates user in auth service and corresponding record in customer/agent service
     */
    @PostMapping("/admin/create-user")
    public ResponseEntity<?> createUser(
            @Valid @RequestBody RegisterRequest request,
            @RequestHeader("X-User-Role") String adminRole,
            BindingResult bindingResult,
            HttpServletRequest httpRequest) {
        
        log.info("=== ADMIN USER CREATION REQUEST ===");
        log.info("Admin Role: {}, Creating: {} with role: {}", 
                adminRole, request.getUsername(), request.getRole());
        
        // Handle validation errors
        if (bindingResult.hasErrors()) {
            List<String> errorDetails = bindingResult.getFieldErrors().stream()
                    .map(FieldError::getDefaultMessage)
                    .collect(Collectors.toList());
            
            String mainMessage = "Validation failed for user creation";
            
            ErrorResponse error = new ErrorResponse(
                HttpStatus.BAD_REQUEST.value(),
                "Validation Failed",
                mainMessage,
                httpRequest.getRequestURI(),
                errorDetails
            );
            
            log.error("Validation errors: {}", errorDetails);
            return ResponseEntity.badRequest().body(error);
        }
        
        try {
            AuthResponse response = authService.createUser(request, adminRole);
            
            SuccessResponse success = new SuccessResponse(
                HttpStatus.CREATED.value(),
                "User created successfully with " + request.getRole() + " profile",
                response
            );
            
            log.info("User creation successful: {}", request.getUsername());
            return ResponseEntity.status(HttpStatus.CREATED).body(success);
            
        } catch (RuntimeException e) {
            log.error("User creation failed: {}", e.getMessage());
            
            HttpStatus status = e.getMessage().contains("Unauthorized") ? 
                HttpStatus.FORBIDDEN : HttpStatus.BAD_REQUEST;
            
            ErrorResponse error = new ErrorResponse(
                status.value(),
                status == HttpStatus.FORBIDDEN ? "Access Denied" : "User Creation Failed",
                e.getMessage(),
                httpRequest.getRequestURI()
            );
            
            return ResponseEntity.status(status).body(error);
            
        } catch (Exception e) {
            log.error("Unexpected error during user creation: {}", e.getMessage(), e);
            
            ErrorResponse error = new ErrorResponse(
                HttpStatus.INTERNAL_SERVER_ERROR.value(),
                "Internal Server Error",
                "An unexpected error occurred during user creation. Please try again.",
                httpRequest.getRequestURI()
            );
            
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);
        }
    }
    
    @PostMapping("/login")
    public ResponseEntity<?> login(
            @Valid @RequestBody LoginRequest request,
            BindingResult bindingResult,
            HttpServletRequest httpRequest) {
        
        log.info("Login attempt for username: {}", request.getUsername());
        
        // Check and create admin user if none exists
        ensureAdminUserExists();
        
        // Handle validation errors
        if (bindingResult.hasErrors()) {
            List<String> errorDetails = bindingResult.getFieldErrors().stream()
                    .map(FieldError::getDefaultMessage)
                    .collect(Collectors.toList());
            
            ErrorResponse error = new ErrorResponse(
                HttpStatus.BAD_REQUEST.value(),
                "Validation Failed",
                "Please provide valid login credentials",
                httpRequest.getRequestURI(),
                errorDetails
            );
            
            return ResponseEntity.badRequest().body(error);
        }
        
        try {
            AuthResponse response = authService.login(request);
            
            SuccessResponse success = new SuccessResponse(
                HttpStatus.OK.value(),
                "Login successful",
                response
            );
            
            log.info("Login successful for user: {}", request.getUsername());
            return ResponseEntity.ok(success);
            
        } catch (RuntimeException e) {
            log.error("Login failed for {}: {}", request.getUsername(), e.getMessage());
            
            ErrorResponse error = new ErrorResponse(
                HttpStatus.UNAUTHORIZED.value(),
                "Authentication Failed",
                e.getMessage(),
                httpRequest.getRequestURI()
            );
            
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(error);
            
        } catch (Exception e) {
            log.error("Unexpected error during login: {}", e.getMessage(), e);
            
            ErrorResponse error = new ErrorResponse(
                HttpStatus.INTERNAL_SERVER_ERROR.value(),
                "Internal Server Error",
                "An unexpected error occurred during login. Please try again.",
                httpRequest.getRequestURI()
            );
            
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);
        }
    }
    
    /**
     * Reset/Change password endpoint
     */
    @PutMapping("/reset-password")
    public ResponseEntity<?> resetPassword(
            @Valid @RequestBody PasswordResetRequest request,
            @RequestHeader("X-User-Id") Long userId) {
        
        log.info("Password reset request from user: {}", userId);
        
        try {
            authService.resetPassword(userId, request);
            
            SuccessResponse success = new SuccessResponse(
                HttpStatus.OK.value(),
                "Password updated successfully",
                "Your password has been changed successfully"
            );
            
            log.info("Password reset successful for user: {}", userId);
            return ResponseEntity.ok(success);
            
        } catch (RuntimeException e) {
            log.error("Password reset failed for user {}: {}", userId, e.getMessage());
            
            ErrorResponse error = new ErrorResponse(
                HttpStatus.BAD_REQUEST.value(),
                "Password Reset Failed",
                e.getMessage(),
                "/api/auth/reset-password"
            );
            
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    /**
     * Ensures that an admin user exists in the system
     * Creates default admin if no admin users are found
     */
    private void ensureAdminUserExists() {
        try {
            // Check if any admin user exists
            boolean adminExists = userRepository.existsByRole(Role.ADMIN);
            
            if (!adminExists) {
                log.info("=== NO ADMIN USER FOUND - CREATING DEFAULT ADMIN ===");
                
                // Create default admin user
                User adminUser = new User();
                adminUser.setUsername("admin");
                adminUser.setEmail("admin@insurance.com");
                adminUser.setPassword(passwordEncoder.encode("admin123"));
                adminUser.setRole(Role.ADMIN);
                adminUser.setIsActive(true);
                
                User savedAdmin = userRepository.save(adminUser);
                
                log.info("✅ DEFAULT ADMIN USER CREATED SUCCESSFULLY");
                log.info("Admin ID: {}", savedAdmin.getId());
                log.info("Username: admin");
                log.info("Password: admin123");
                log.info("Email: admin@insurance.com");
                log.info("=== SAVE THESE CREDENTIALS FOR LOGIN ===");
            } else {
                log.debug("Admin user already exists, skipping creation");
            }
            
        } catch (Exception e) {
            log.error("Error checking/creating admin user: {}", e.getMessage());
            // Don't throw exception here to avoid breaking login flow
        }
    }
    /**
     * ADMIN: Update user activation status
     */
    @PutMapping("/admin/users/{userId}/status")
    public ResponseEntity<?> updateUserStatus(
            @PathVariable Long userId,
            @RequestParam Boolean isActive,
            @RequestHeader("X-User-Role") String adminRole,
            HttpServletRequest httpRequest) {
        try {
            authService.updateUserStatus(userId, isActive, adminRole);
            SuccessResponse success = new SuccessResponse(
                    HttpStatus.OK.value(),
                    "User status updated successfully",
                    null
            );
            return ResponseEntity.ok(success);
        } catch (RuntimeException e) {
            HttpStatus status = e.getMessage().contains("Only ADMIN")
                    ? HttpStatus.FORBIDDEN
                    : HttpStatus.BAD_REQUEST;

            ErrorResponse error = new ErrorResponse(
                    status.value(),
                    status == HttpStatus.FORBIDDEN ? "Access Denied" : "User Status Update Failed",
                    e.getMessage(),
                    httpRequest.getRequestURI()
            );
            return ResponseEntity.status(status).body(error);
        }
    }

    /**
     * ADMIN: Get user activation status
     */
    @GetMapping("/admin/users/{userId}/status")
    public ResponseEntity<?> getUserStatus(@PathVariable Long userId) {
        boolean status = authService.getUserStatus(userId);
        SuccessResponse success = new SuccessResponse(
                HttpStatus.OK.value(),
                "User status fetched",
                status
        );
        return ResponseEntity.ok(success);
    }
    
    /**
     * Health check endpoint
     */
    @GetMapping("/health")
    public ResponseEntity<?> health() {
        SuccessResponse response = new SuccessResponse(
            HttpStatus.OK.value(),
            "Auth service is running",
            "OK"
        );
        return ResponseEntity.ok(response);
    }
}

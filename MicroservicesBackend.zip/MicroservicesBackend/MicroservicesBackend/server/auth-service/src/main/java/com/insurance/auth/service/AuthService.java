package com.insurance.auth.service;

import com.insurance.auth.client.AgentServiceClient;
import com.insurance.auth.client.CustomerServiceClient;
import com.insurance.auth.dto.*;
import com.insurance.auth.entity.Role;
import com.insurance.auth.entity.User;
import com.insurance.auth.repository.UserRepository;
import com.insurance.auth.util.JwtUtil;
import feign.FeignException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class AuthService {
    
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;
    private final CustomerServiceClient customerServiceClient;
    private final AgentServiceClient agentServiceClient;
    
    /**
     * ADMIN-ONLY user creation method
     * Creates users and automatically creates records in respective services using Feign Clients
     */
    public AuthResponse createUser(RegisterRequest request, String adminRole) {
        log.info("=== ADMIN USER CREATION PROCESS ===");
        log.info("Admin creating user - Username: {}, Email: {}, Role: {}", 
                request.getUsername(), request.getEmail(), request.getRole());
        
        // Verify that only ADMIN can create users
        if (!"ADMIN".equals(adminRole)) {
            log.error("Unauthorized user creation attempt by role: {}", adminRole);
            throw new RuntimeException("Only ADMIN can create new users");
        }
        
        // Validate unique constraints
        if (userRepository.existsByUsername(request.getUsername())) {
            log.error("Username {} already exists", request.getUsername());
            throw new RuntimeException("Username already exists");
        }
        
        if (userRepository.existsByEmail(request.getEmail())) {
            log.error("Email {} already exists", request.getEmail());
            throw new RuntimeException("Email already exists");
        }
        
        // Validate role-specific requirements
        validateRoleSpecificFields(request);
        
        // Create user in auth service
        User user = new User();
        user.setUsername(request.getUsername());
        user.setEmail(request.getEmail());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setRole(request.getRole());
        user.setIsActive(true);
        
        User savedUser = userRepository.save(user);
        log.info("User created in auth-service with ID: {}", savedUser.getId());
        
        // Create records in respective services based on role using Feign Clients
        String serviceMessage = "";
        try {
            if (request.getRole() == Role.USER) {
                createCustomerRecord(savedUser.getId(), request);
                serviceMessage = "Customer profile created successfully";
            } else if (request.getRole() == Role.AGENT) {
                createAgentRecord(savedUser.getId(), request);
                serviceMessage = "Agent profile created successfully";
            } else {
                serviceMessage = "Admin user created successfully";
            }
        } catch (Exception e) {
            log.error("Failed to create record in respective service: {}", e.getMessage());
            // Rollback: Delete the user if downstream service fails
            userRepository.delete(savedUser);
            throw new RuntimeException("User creation failed: " + e.getMessage());
        }
        
        String token = jwtUtil.generateToken(savedUser);
        
        log.info("=== USER CREATION COMPLETED SUCCESSFULLY ===");
        log.info("Service message: {}", serviceMessage);
        
        return new AuthResponse(token, savedUser.getUsername(), 
                               savedUser.getRole().name(), savedUser.getId());
    }
    
    private void validateRoleSpecificFields(RegisterRequest request) {
        if (request.getRole() == Role.AGENT) {
            if (request.getLicenseNumber() == null || request.getLicenseNumber().trim().isEmpty()) {
                throw new RuntimeException("License number is required for agents");
            }
            if (request.getSpecialization() == null || request.getSpecialization().trim().isEmpty()) {
                throw new RuntimeException("Specialization is required for agents");
            }
            if (request.getCommissionRate() == null) {
                throw new RuntimeException("Commission rate is required for agents");
            }
        }
    }
    
    private void createCustomerRecord(Long userId, RegisterRequest request) {
        log.info("Creating customer record for user ID: {} using Feign Client", userId);
        
        CustomerCreationRequest customerRequest = new CustomerCreationRequest(
            request.getName(),
            request.getEmail(),
            request.getPhone(),
            request.getAddress()
        );
        
        try {
            ResponseEntity<Object> response = customerServiceClient.createCustomer(
                customerRequest,
                userId.toString(),
                "ADMIN"
            );
            
            if (response.getStatusCode().is2xxSuccessful()) {
                log.info("Customer record created successfully via Feign Client");
            } else {
                throw new RuntimeException("Failed to create customer record - HTTP " + response.getStatusCode());
            }
        } catch (FeignException e) {
            log.error("Feign error calling customer service: Status {}, Message: {}", 
                     e.status(), e.getMessage());
            throw new RuntimeException("Failed to create customer record: " + e.getMessage());
        } catch (Exception e) {
            log.error("Error calling customer service via Feign: {}", e.getMessage());
            throw new RuntimeException("Failed to create customer record: " + e.getMessage());
        }
    }
    
    private void createAgentRecord(Long userId, RegisterRequest request) {
        log.info("Creating agent record for user ID: {} using Feign Client", userId);
        
        AgentCreationRequest agentRequest = new AgentCreationRequest(
            request.getName(),
            request.getEmail(),
            request.getPhone(),
            request.getAddress(),
            request.getLicenseNumber(),
            request.getSpecialization(),
            request.getCommissionRate()
        );
        
        try {
            ResponseEntity<Object> response = agentServiceClient.createAgent(
                agentRequest,
                userId.toString(),
                "ADMIN"
            );
            
            if (response.getStatusCode().is2xxSuccessful()) {
                log.info("Agent record created successfully via Feign Client");
            } else {
                throw new RuntimeException("Failed to create agent record - HTTP " + response.getStatusCode());
            }
        } catch (FeignException e) {
            log.error("Feign error calling agent service: Status {}, Message: {}", 
                     e.status(), e.getMessage());
            throw new RuntimeException("Failed to create agent record: " + e.getMessage());
        } catch (Exception e) {
            log.error("Error calling agent service via Feign: {}", e.getMessage());
            throw new RuntimeException("Failed to create agent record: " + e.getMessage());
        }
    }
    
    /**
     * Update user activation status (Admin only)
     */
    public void updateUserStatus(Long userId, Boolean isActive, String adminRole) {
        log.info("Updating user {} status to {} by admin role {}", userId, isActive, adminRole);
        
        // Verify that only ADMIN can update user status
        if (!"ADMIN".equals(adminRole)) {
            log.error("Unauthorized user status update attempt by role: {}", adminRole);
            throw new RuntimeException("Only ADMIN can update user status");
        }
        
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found with ID: " + userId));
        
        if (user.getIsActive().equals(isActive)) {
            log.warn("User {} is already {}", userId, isActive ? "active" : "inactive");
            throw new RuntimeException("User is already " + (isActive ? "active" : "inactive"));
        }
        
        user.setIsActive(isActive);
        userRepository.save(user);
        
        log.info("User {} status updated to {} successfully", userId, isActive ? "active" : "inactive");
    }
    
    /**
     * Get user activation status
     */
    public boolean getUserStatus(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found with ID: " + userId));
        return user.getIsActive();
    }
    
    /**
     * Reset user password
     */
    public void resetPassword(Long userId, PasswordResetRequest request) {
        log.info("Resetting password for user: {}", userId);
        
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));
        
        // Verify current password
        if (!passwordEncoder.matches(request.getCurrentPassword(), user.getPassword())) {
            log.warn("Invalid current password for user: {}", userId);
            throw new RuntimeException("Current password is incorrect");
        }
        
        // Check if new password is same as current
        if (passwordEncoder.matches(request.getNewPassword(), user.getPassword())) {
            log.warn("New password same as current for user: {}", userId);
            throw new RuntimeException("New password must be different from current password");
        }
        
        // Encode and set new password
        user.setPassword(passwordEncoder.encode(request.getNewPassword()));
        userRepository.save(user);
        
        log.info("Password reset successful for user: {}", userId);
    }
    
    public AuthResponse login(LoginRequest request) {
        log.info("Login attempt for username: {}", request.getUsername());
        
        User user = userRepository.findByUsername(request.getUsername())
                .orElseThrow(() -> new RuntimeException("Invalid username or password"));
        
        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            log.warn("Invalid password for username: {}", request.getUsername());
            throw new RuntimeException("Invalid username or password");
        }
        
        if (!user.getIsActive()) {
            log.warn("Inactive user login attempt: {}", request.getUsername());
            throw new RuntimeException("Account is deactivated. Please contact administrator.");
        }
        
        // Get entity IDs based on role
        Long customerId = null;
        Long agentId = null;
        
        if (user.getRole() == Role.USER) {
            customerId = getCustomerIdForUser(user.getId());
        } else if (user.getRole() == Role.AGENT) {
            agentId = getAgentIdForUser(user.getId());
        }
        
        // Generate JWT with entity IDs
        String token = jwtUtil.generateTokenWithEntities(user, customerId, agentId);
        
        log.info("User {} logged in successfully with role: {}, customerId: {}, agentId: {}", 
                request.getUsername(), user.getRole(), customerId, agentId);
        
        return new AuthResponse(token, user.getUsername(), 
                               user.getRole().name(), user.getId());
    }
    
    private Long getCustomerIdForUser(Long userId) {
        try {
            log.debug("Attempting to fetch customerId for userId: {}", userId);
            ResponseEntity<Object> response = customerServiceClient.getCustomerByUserId(userId);
            log.debug("Customer service response: status={}, body={}", 
                    response.getStatusCode(), response.getBody());
            
            if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null) {
                // Extract customerId from response
                java.util.Map<String, Object> customerData = (java.util.Map<String, Object>) response.getBody();
                Long customerId = Long.valueOf(customerData.get("customerId").toString());
                log.debug("Successfully resolved customerId: {} for userId: {}", customerId, userId);
                return customerId;
            } else {
                log.warn("No customer data found for userId: {}", userId);
            }
        } catch (Exception e) {
            log.error("Failed to get customerId for userId {}: {}", userId, e.getMessage(), e);
        }
        return null;
    }
    
    private Long getAgentIdForUser(Long userId) {
        try {
            log.debug("Attempting to fetch agentId for userId: {}", userId);
            ResponseEntity<Object> response = agentServiceClient.getAgentByUserId(userId);
            log.debug("Agent service response: status={}, body={}", 
                    response.getStatusCode(), response.getBody());
            
            if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null) {
                // Extract agentId from response
                java.util.Map<String, Object> agentData = (java.util.Map<String, Object>) response.getBody();
                Long agentId = Long.valueOf(agentData.get("agentId").toString());
                log.debug("Successfully resolved agentId: {} for userId: {}", agentId, userId);
                return agentId;
            } else {
                log.warn("No agent data found for userId: {}", userId);
            }
        } catch (Exception e) {
            log.error("Failed to get agentId for userId {}: {}", userId, e.getMessage(), e);
        }
        return null;
    }
}

package com.insurance.customer.service;

import com.insurance.customer.client.AgentServiceClient;
import com.insurance.customer.client.NotificationServiceClient;
import com.insurance.customer.client.PolicyServiceClient;
import com.insurance.customer.dto.CustomerProfileUpdateRequest;
import com.insurance.customer.dto.CustomerRequest;
import com.insurance.customer.dto.CustomerResponse;
import com.insurance.customer.entity.Customer;
import com.insurance.customer.repository.CustomerRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

class CustomerServiceTest {
    @Mock
    private CustomerRepository customerRepository;
    @Mock
    private NotificationServiceClient notificationServiceClient;
    @Mock
    private PolicyServiceClient policyServiceClient;
    @Mock
    private AgentServiceClient agentServiceClient;
    @InjectMocks
    private CustomerService customerService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testCreateCustomer_Success() {
        CustomerRequest request = new CustomerRequest();
        request.setEmail("test@example.com");
        request.setName("Test Customer");
        request.setPhone("1234567890");
        request.setAddress("123 Street");
        when(customerRepository.existsByEmail(anyString())).thenReturn(false);
        Customer customer = new Customer();
        customer.setCustomerId(1L);
        customer.setEmail(request.getEmail());
        when(customerRepository.save(any(Customer.class))).thenReturn(customer);
        when(notificationServiceClient.createNotification(any(), any(), any()))
                .thenReturn(ResponseEntity.ok().build());
        CustomerResponse response = customerService.createCustomer(request, 100L);
        assertNotNull(response);
        assertEquals("test@example.com", response.getEmail());
    }

    @Test
    void testCreateCustomer_EmailExists() {
        CustomerRequest request = new CustomerRequest();
        request.setEmail("test@example.com");
        when(customerRepository.existsByEmail(anyString())).thenReturn(true);
        RuntimeException ex = assertThrows(RuntimeException.class, () -> customerService.createCustomer(request, 100L));
        assertEquals("Customer with this email already exists", ex.getMessage());
    }

    @Test
    void testGetCustomerById_Found() {
        Customer customer = new Customer();
        customer.setCustomerId(1L);
        customer.setEmail("test@example.com");
        when(customerRepository.findById(1L)).thenReturn(Optional.of(customer));
        CustomerResponse response = customerService.getCustomerById(1L);
        assertNotNull(response);
        assertEquals(1L, response.getCustomerId());
    }

    @Test
    void testGetCustomerById_NotFound() {
        when(customerRepository.findById(anyLong())).thenReturn(Optional.empty());
        RuntimeException ex = assertThrows(RuntimeException.class, () -> customerService.getCustomerById(1L));
        assertEquals("Customer not found", ex.getMessage());
    }

    @Test
    void testGetCustomerByUserId_Found() {
        Customer customer = new Customer();
        customer.setUserId(100L);
        customer.setCustomerId(1L);
        when(customerRepository.findByUserId(100L)).thenReturn(Optional.of(customer));
        CustomerResponse response = customerService.getCustomerByUserId(100L);
        assertNotNull(response);
        assertEquals(1L, response.getCustomerId());
    }

    @Test
    void testGetCustomerByUserId_NotFound() {
        when(customerRepository.findByUserId(anyLong())).thenReturn(Optional.empty());
        RuntimeException ex = assertThrows(RuntimeException.class, () -> customerService.getCustomerByUserId(100L));
        assertEquals("Customer not found for userId: 100", ex.getMessage());
    }

    @Test
    void testGetAllCustomers_Paginated() {
        Customer customer1 = new Customer();
        customer1.setCustomerId(1L);
        Customer customer2 = new Customer();
        customer2.setCustomerId(2L);
        List<Customer> customers = Arrays.asList(customer1, customer2);
        Page<Customer> page = new PageImpl<>(customers);
        when(customerRepository.findAll(any(Pageable.class))).thenReturn(page);
        List<CustomerResponse> responses = customerService.getAllCustomers(PageRequest.of(0, 10));
        assertEquals(2, responses.size());
    }

    @Test
    void testUpdateCustomer_Success_Admin() {
        CustomerProfileUpdateRequest request = new CustomerProfileUpdateRequest();
        request.setName("Updated Name");
        request.setPhone("9876543210");
        request.setAddress("New Address");
        Customer customer = new Customer();
        customer.setCustomerId(1L);
        customer.setUserId(100L);
        when(customerRepository.findById(1L)).thenReturn(Optional.of(customer));
        when(customerRepository.save(any(Customer.class))).thenReturn(customer);
        CustomerResponse response = customerService.updateCustomer(1L, request, 100L, "ADMIN");
        assertNotNull(response);
        assertEquals("Updated Name", response.getName());
    }

    @Test
    void testUpdateCustomer_Unauthorized() {
        CustomerProfileUpdateRequest request = new CustomerProfileUpdateRequest();
        Customer customer = new Customer();
        customer.setCustomerId(1L);
        customer.setUserId(200L); // Different user
        when(customerRepository.findById(1L)).thenReturn(Optional.of(customer));
        RuntimeException ex = assertThrows(RuntimeException.class, () -> customerService.updateCustomer(1L, request, 100L, "USER"));
        assertEquals("Unauthorized to update this customer", ex.getMessage());
    }

    @Test
    void testUpdateCustomer_NotFound() {
        CustomerProfileUpdateRequest request = new CustomerProfileUpdateRequest();
        when(customerRepository.findById(anyLong())).thenReturn(Optional.empty());
        RuntimeException ex = assertThrows(RuntimeException.class, () -> customerService.updateCustomer(1L, request, 100L, "ADMIN"));
        assertEquals("Customer not found", ex.getMessage());
    }

    @Test
    void testUpdateCustomerByUserId_Success() {
        CustomerProfileUpdateRequest request = new CustomerProfileUpdateRequest();
        request.setName("Updated Name");
        request.setPhone("9876543210");
        request.setAddress("New Address");
        Customer customer = new Customer();
        customer.setUserId(100L);
        customer.setCustomerId(1L);
        when(customerRepository.findByUserId(100L)).thenReturn(Optional.of(customer));
        when(customerRepository.save(any(Customer.class))).thenReturn(customer);
        CustomerResponse response = customerService.updateCustomerByUserId(100L, request);
        assertNotNull(response);
        assertEquals("Updated Name", response.getName());
    }

    @Test
    void testUpdateCustomerByUserId_NotFound() {
        CustomerProfileUpdateRequest request = new CustomerProfileUpdateRequest();
        when(customerRepository.findByUserId(anyLong())).thenReturn(Optional.empty());
        RuntimeException ex = assertThrows(RuntimeException.class, () -> customerService.updateCustomerByUserId(100L, request));
        assertEquals("Customer not found for user", ex.getMessage());
    }
}


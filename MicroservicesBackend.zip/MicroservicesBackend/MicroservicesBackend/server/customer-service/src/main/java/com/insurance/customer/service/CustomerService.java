package com.insurance.customer.service;

import com.insurance.customer.client.AgentServiceClient;
import com.insurance.customer.client.NotificationServiceClient;
import com.insurance.customer.client.PolicyServiceClient;
import com.insurance.customer.dto.CustomerProfileUpdateRequest;
import com.insurance.customer.dto.CustomerRequest;
import com.insurance.customer.dto.CustomerResponse;
import com.insurance.customer.dto.NotificationRequest;
import com.insurance.customer.entity.Customer;
import com.insurance.customer.repository.CustomerRepository;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import org.springframework.http.ResponseEntity;

@Service
@RequiredArgsConstructor
@Slf4j
public class CustomerService {
    
    private final CustomerRepository customerRepository;
    private final NotificationServiceClient notificationServiceClient;
    private final PolicyServiceClient policyServiceClient;
    private final AgentServiceClient agentServiceClient;
    
    public CustomerResponse createCustomer(CustomerRequest request, Long userId) {
        log.info("Creating customer for user ID: {}", userId);
        
        if (customerRepository.existsByEmail(request.getEmail())) {
            log.error("Customer with email {} already exists", request.getEmail());
            throw new RuntimeException("Customer with this email already exists");
        }
        
        Customer customer = new Customer();
        customer.setName(request.getName());
        customer.setEmail(request.getEmail());
        customer.setPhone(request.getPhone());
        customer.setAddress(request.getAddress());
        customer.setUserId(userId);
        customer.setIsActive(true);  // Default to active when creating
        
        Customer savedCustomer = customerRepository.save(customer);
        log.info("Customer created successfully with ID: {}", savedCustomer.getCustomerId());
        
        // Send welcome notification
        try {
            var notification = new NotificationRequest();
            notification.setCustomerId(savedCustomer.getCustomerId());
            notification.setTargetRole("USER");
            notification.setTitle("Welcome to Insurance Portal");
            notification.setMessage("Welcome! Your customer account has been created successfully.");
            notification.setType("WELCOME_MESSAGE");
            notification.setCategory("SUCCESS");
            notification.setPriority("MEDIUM");
            notification.setSendEmail(false); // Disabled - SMTP blocked by company network
            notification.setSendSms(false);
            
            notificationServiceClient.createNotification(notification, "2", "ADMIN");
            log.info("Welcome notification sent to customer: {}", savedCustomer.getCustomerId());
        } catch (Exception e) {
            log.error("Failed to send welcome notification to customer: {}", savedCustomer.getCustomerId(), e);
        }
        
        return mapToResponse(savedCustomer);
    }
    
    private void sendWelcomeNotification(Customer customer) {
        try {
            NotificationRequest notification = new NotificationRequest();
            notification.setCustomerId(customer.getCustomerId());
            notification.setTargetRole("USER");
            notification.setTitle("Welcome to Our Insurance Family!");
            notification.setMessage("Welcome " + customer.getName() + "! Your customer profile has been created successfully. " +
                "You can now purchase insurance policies and manage your account through our platform.");
            notification.setType("WELCOME_MESSAGE");
            notification.setCategory("SUCCESS");
            notification.setPriority("MEDIUM");
            notification.setSendEmail(false);
            notification.setSendSms(false);
            
            notificationServiceClient.createNotification(notification, "2", "ADMIN");
            log.info("Welcome notification sent for customer: {}", customer.getCustomerId());
        } catch (Exception e) {
            log.error("Failed to send welcome notification for customer: {}", customer.getCustomerId(), e);
        }
    }
    
    public CustomerResponse getCustomerById(Long customerId) {
        log.debug("Fetching customer with ID: {}", customerId);
        Customer customer = customerRepository.findById(customerId)
                .orElseThrow(() -> new RuntimeException("Customer not found"));
        return mapToResponse(customer);
    }
    
    public CustomerResponse getCustomerByUserId(Long userId) {
        log.debug("Fetching customer with userId: {}", userId);
        Customer customer = customerRepository.findByUserId(userId)
                .orElseThrow(() -> new RuntimeException("Customer not found for userId: " + userId));
        return mapToResponse(customer);
    }
    
    public List<CustomerResponse> getAllCustomers(Pageable pageable) {
        log.debug("Fetching all customers with pagination");
        Page<Customer> customers = customerRepository.findAll(pageable);
        return customers.getContent().stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }
    
    public CustomerResponse updateCustomer(Long customerId, @Valid CustomerProfileUpdateRequest request, Long userId, String role) {
        log.info("Updating customer with ID: {} for user: {}", customerId, userId);
        
        Customer customer = customerRepository.findById(customerId)
                .orElseThrow(() -> new RuntimeException("Customer not found"));
        
        // Check if the customer belongs to the user (for USER role)
        if (!customer.getUserId().equals(userId) && !role.equals("ADMIN")) {
            log.error("User {} attempted to update customer {} without permission", userId, customerId);
            throw new RuntimeException("Unauthorized to update this customer");
        }
        
        customer.setName(request.getName());
        customer.setPhone(request.getPhone());
        customer.setAddress(request.getAddress());
        
        Customer updatedCustomer = customerRepository.save(customer);
        log.info("Customer updated successfully with ID: {}", updatedCustomer.getCustomerId());
        
        return mapToResponse(updatedCustomer);
    }
    
    public CustomerResponse updateCustomerByUserId(Long userId, CustomerProfileUpdateRequest request) {
        log.info("Updating customer profile for user ID: {}", userId);
        
        Customer customer = customerRepository.findByUserId(userId)
                .orElseThrow(() -> new RuntimeException("Customer not found for user"));
        
        // Only update allowed fields (name, phone, address) - email should not be changed
        if (request.getName() != null) {
            customer.setName(request.getName());
        }
        if (request.getPhone() != null) {
            customer.setPhone(request.getPhone());
        }
        if (request.getAddress() != null) {
            customer.setAddress(request.getAddress());
        }
        // Note: email is NOT updated to prevent changes
        
        Customer updatedCustomer = customerRepository.save(customer);
        log.info("Customer profile updated successfully for user ID: {}", userId);
        
        return mapToResponse(updatedCustomer);
    }
    
    public void deleteCustomer(Long customerId) {
        log.info("Deleting customer with ID: {}", customerId);
        if (!customerRepository.existsById(customerId)) {
            throw new RuntimeException("Customer not found");
        }
        customerRepository.deleteById(customerId);
        log.info("Customer deleted successfully with ID: {}", customerId);
    }
    
    public CustomerResponse activateCustomer(Long customerId) {
        log.info("Activating customer with ID: {}", customerId);
        Customer customer = customerRepository.findById(customerId)
                .orElseThrow(() -> new RuntimeException("Customer not found"));
        
        if (customer.getIsActive()) {
            log.warn("Customer {} is already active", customerId);
            throw new RuntimeException("Customer is already active");
        }
        
        customer.setIsActive(true);
        Customer savedCustomer = customerRepository.save(customer);
        log.info("Customer activated successfully with ID: {}", customerId);
        
        return mapToResponse(savedCustomer);
    }
    
    public CustomerResponse deactivateCustomer(Long customerId) {
        log.info("Deactivating customer with ID: {}", customerId);
        Customer customer = customerRepository.findById(customerId)
                .orElseThrow(() -> new RuntimeException("Customer not found"));
        
        if (!customer.getIsActive()) {
            log.warn("Customer {} is already inactive", customerId);
            throw new RuntimeException("Customer is already inactive");
        }
        
        customer.setIsActive(false);
        Customer savedCustomer = customerRepository.save(customer);
        log.info("Customer deactivated successfully with ID: {}", customerId);
        
        return mapToResponse(savedCustomer);
    }
    
    public boolean isCustomerActive(Long customerId) {
        Customer customer = customerRepository.findById(customerId)
                .orElseThrow(() -> new RuntimeException("Customer not found"));
        return customer.getIsActive();
    }
    
    private CustomerResponse mapToResponse(Customer customer) {
        return new CustomerResponse(
                customer.getCustomerId(),
                customer.getName(),
                customer.getEmail(),
                customer.getPhone(),
                customer.getAddress(),
                customer.getUserId(),
                customer.getIsActive(),
                customer.getCreatedAt(),
                customer.getUpdatedAt()
        );
    }

    // Dummy data - Mock responses
    private List<Object> generateDummyPolicies() {
        // Mock policy data for frontend development
        return List.of(
            new Object() {
                public Long id = 1L;
                public String policyNumber = "POL-2024-001";
                public String name = "Life Insurance Premium";
                public String type = "LIFE";
                public Double coverageAmount = 1000000.0;
                public Double premiumAmount = 15000.0;
                public String status = "ACTIVE";
                public String startDate = "2024-01-01";
                public String endDate = "2025-01-01";
            },
            new Object() {
                public Long id = 2L;
                public String policyNumber = "POL-2024-002";
                public String name = "Health Insurance";
                public String type = "HEALTH";
                public Double coverageAmount = 500000.0;
                public Double premiumAmount = 8000.0;
                public String status = "ACTIVE";
                public String startDate = "2024-02-01";
                public String endDate = "2025-02-01";
            }
        );
    }
    
    /**
     * Get the assigned agent for a customer
     */
    public Object getCustomerAgent(Long userId) {
        log.info("Getting agent for customer with user ID: {}", userId);
        
        try {
            // Get customer info
            Customer customer = customerRepository.findByUserId(userId)
                    .orElseThrow(() -> new RuntimeException("Customer not found"));
            
            log.info("Found customer with ID: {} for user: {}", customer.getCustomerId(), userId);
            
            // Get customer's policies to find agent
            ResponseEntity<Object> policiesResponse = policyServiceClient.getPoliciesByCustomerId(
                    customer.getCustomerId(), userId.toString(), "USER", customer.getCustomerId().toString()
            );
            
            log.info("Policy service response status: {}", policiesResponse.getStatusCode());
            
            if (policiesResponse.getStatusCode().is2xxSuccessful() && policiesResponse.getBody() != null) {
                List<Map<String, Object>> policies = (List<Map<String, Object>>) policiesResponse.getBody();
                log.info("Found {} policies for customer: {}", policies.size(), customer.getCustomerId());
                
                if (!policies.isEmpty()) {
                    Map<String, Object> firstPolicy = policies.get(0);
                    log.info("First policy data: {}", firstPolicy);
                    
                    // Get agentId from the first policy (assuming all policies have same agent)
                    Object agentIdObj = firstPolicy.get("agentId");
                    log.info("Agent ID from policy: {}", agentIdObj);
                    
                    if (agentIdObj != null) {
                        Long agentId = Long.valueOf(agentIdObj.toString());
                        log.info("Fetching agent with ID: {}", agentId);
                        
                        // Fetch agent details using admin privileges to bypass restrictions
                        ResponseEntity<Object> agentResponse = agentServiceClient.getAgentById(
                                agentId, "1", "ADMIN"
                        );
                        
                        log.info("Agent service response status: {}", agentResponse.getStatusCode());
                        
                        if (agentResponse.getStatusCode().is2xxSuccessful()) {
                            log.info("Successfully retrieved agent data");
                            return agentResponse.getBody();
                        } else {
                            log.warn("Agent service returned non-success status: {}", agentResponse.getStatusCode());
                        }
                    } else {
                        log.warn("No agentId found in policy for customer: {}", customer.getCustomerId());
                    }
                } else {
                    log.warn("No policies found for customer: {}", customer.getCustomerId());
                }
            } else {
                log.warn("Policy service call failed. Status: {}, Body: {}", 
                        policiesResponse.getStatusCode(), policiesResponse.getBody());
            }
            
            return null;
        } catch (Exception e) {
            log.error("Error getting agent for customer user ID {}: {}", userId, e.getMessage(), e);
            return null;
        }
    }
} 

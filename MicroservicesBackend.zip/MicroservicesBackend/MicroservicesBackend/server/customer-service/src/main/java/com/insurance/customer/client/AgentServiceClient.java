package com.insurance.customer.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;

@FeignClient(name = "agent-service", path = "/api/agents")
public interface AgentServiceClient {
    
    @GetMapping("/{agentId}")
    ResponseEntity<Object> getAgentById(
            @PathVariable Long agentId,
            @RequestHeader("X-User-Id") String userId,
            @RequestHeader("X-User-Role") String role
    );
} 
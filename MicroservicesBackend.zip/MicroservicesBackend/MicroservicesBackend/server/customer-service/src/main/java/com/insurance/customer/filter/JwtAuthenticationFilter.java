package com.insurance.customer.filter;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

@Component
@Slf4j
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, 
                                  FilterChain filterChain) throws ServletException, IOException {
        
        String path = request.getRequestURI();
        String method = request.getMethod();
        log.debug("JWT Filter processing request: {} {}", method, path);
        
        // Health check endpoints are public
        if (isPublicEndpoint(path, method)) {
            log.debug("Public endpoint detected, skipping JWT validation: {}", path);
            filterChain.doFilter(request, response);
            return;
        }

        // Check for required headers from API Gateway
        String userId = request.getHeader("X-User-Id");
        String userRole = request.getHeader("X-User-Role");
        
        // Extract optional entity headers
        String customerId = request.getHeader("X-Customer-Id");
        String agentId = request.getHeader("X-Agent-Id");
        
        if (userId == null || userRole == null) {
            log.warn("Missing required headers for secured endpoint: {}", path);
            log.warn("X-User-Id: {}, X-User-Role: {}", userId, userRole);
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            response.getWriter().write("{\"error\":\"Missing authentication headers\"}");
            response.setContentType("application/json");
            return;
        }

        try {
            log.debug("JWT headers validation successful - User ID: {}, Role: {}, Customer ID: {}, Agent ID: {}", 
                    userId, userRole, customerId, agentId);
            
            // Set authentication in security context
            List<SimpleGrantedAuthority> authorities = Arrays.asList(
                new SimpleGrantedAuthority("ROLE_" + userRole)
            );
            
            UsernamePasswordAuthenticationToken authentication = 
                new UsernamePasswordAuthenticationToken(userId, null, authorities);
            
            SecurityContextHolder.getContext().setAuthentication(authentication);
            
            // Add user info to request attributes for easy access
            request.setAttribute("userId", Long.parseLong(userId));
            request.setAttribute("userRole", userRole);
            
            // Add entity IDs to request attributes if present
            if (customerId != null && !customerId.isEmpty()) {
                request.setAttribute("customerId", Long.parseLong(customerId));
            }
            if (agentId != null && !agentId.isEmpty()) {
                request.setAttribute("agentId", Long.parseLong(agentId));
            }
            
            log.debug("Security context set for user: {} with role: {}", userId, userRole);
            
        } catch (Exception e) {
            log.error("Error processing authentication headers: {}", e.getMessage());
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            response.getWriter().write("{\"error\":\"Invalid authentication headers\"}");
            response.setContentType("application/json");
            return;
        }
        
        filterChain.doFilter(request, response);
    }
    
    private boolean isPublicEndpoint(String path, String method) {
        // Health check endpoints
        if ("GET".equals(method) && (path.equals("/actuator/health") || path.contains("/health"))) {
            return true;
        }
        
        // Resolution endpoints for AuthService (no JWT required)
        if ("GET".equals(method) && path.matches(".*/api/customers/by-user/\\d+")) {
            return true;
        }
        
        return false;
    }
} 

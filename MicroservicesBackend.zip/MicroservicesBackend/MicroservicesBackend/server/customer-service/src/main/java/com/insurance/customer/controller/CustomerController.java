package com.insurance.customer.controller;

import com.insurance.customer.dto.CustomerProfileUpdateRequest;
import com.insurance.customer.dto.CustomerRequest;
import com.insurance.customer.dto.CustomerResponse;
import com.insurance.customer.service.CustomerService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/customers")
@RequiredArgsConstructor
@Slf4j
public class CustomerController {
    
    private final CustomerService customerService;
    
    @PostMapping
    public ResponseEntity<CustomerResponse> createCustomer(
            @Valid @RequestBody CustomerRequest request,
            @RequestHeader("X-User-Id") Long userId,
            @RequestHeader("X-User-Role") String role) {
        
        log.info("Creating customer request from user: {} with role: {}", userId, role);
        
        try {
            CustomerResponse response = customerService.createCustomer(request, userId);
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        } catch (RuntimeException e) {
            log.error("Error creating customer: {}", e.getMessage());
            return ResponseEntity.badRequest().body(null);
        }
    }
    
    @GetMapping("/{customerId}")
    public ResponseEntity<CustomerResponse> getCustomerById(
            @PathVariable Long customerId,
            @RequestHeader("X-User-Id") Long userId,
            @RequestHeader("X-User-Role") String role) {
        
        log.debug("Getting customer {} by user {} with role {}", customerId, userId, role);
        
        try {
            if (role.equals("USER") || role.equals("AGENT")){
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(null);
            }
            CustomerResponse response = customerService.getCustomerById(customerId);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            log.error("Error fetching customer {}: {}", customerId, e.getMessage());
            return ResponseEntity.notFound().build();
        }
    }
    
    @GetMapping("/me")
    public ResponseEntity<CustomerResponse> getMyProfile(
            @RequestHeader("X-User-Id") Long userId) {
        
        log.debug("Getting profile for user: {}", userId);
        
        try {
            CustomerResponse response = customerService.getCustomerByUserId(userId);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            log.error("Error fetching profile for user {}: {}", userId, e.getMessage());
            return ResponseEntity.notFound().build();
        }
    }
    
    @PutMapping("/me")
    public ResponseEntity<CustomerResponse> updateMyProfile(
            @Valid @RequestBody CustomerProfileUpdateRequest request,
            @RequestHeader("X-User-Id") Long userId) {
        
        log.info("Updating profile for user: {}", userId);
        
        try {
            CustomerResponse response = customerService.updateCustomerByUserId(userId, request);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            log.error("Error updating profile for user {}: {}", userId, e.getMessage());
            return ResponseEntity.badRequest().body(null);
        }
    }
    
    @GetMapping("/my-agent")
    public ResponseEntity<Object> getMyAgent(
            @RequestHeader("X-User-Id") Long userId) {
        
        log.info("Getting assigned agent for user: {}", userId);
        
        try {
            Object agentInfo = customerService.getCustomerAgent(userId);
            if (agentInfo != null) {
                return ResponseEntity.ok(agentInfo);
            } else {
                return ResponseEntity.ok(Map.of("message", "No agent assigned"));
            }
        } catch (RuntimeException e) {
            log.error("Error fetching agent for user {}: {}", userId, e.getMessage());
            return ResponseEntity.notFound().build();
        }
    }
    
    @GetMapping
    public ResponseEntity<List<CustomerResponse>> getAllCustomers(
            Pageable pageable,
            @RequestHeader("X-User-Role") String role) {
        
        log.debug("Getting all customers by user with role: {}", role);
        
        // Only ADMIN and AGENT can view all customers
        if (!"ADMIN".equals(role) && !"AGENT".equals(role)) {
            log.warn("Unauthorized access attempt to view all customers by role: {}", role);
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(null);
        }
        
        List<CustomerResponse> customers = customerService.getAllCustomers(pageable);
        return ResponseEntity.ok(customers);
    }
    
    @PutMapping("/{customerId}")
    public ResponseEntity<CustomerResponse> updateCustomer(
            @PathVariable Long customerId,
            @Valid @RequestBody CustomerProfileUpdateRequest request,
            @RequestHeader("X-User-Id") Long userId,
            @RequestHeader("X-User-Role") String role) {
        
        log.info("Updating customer {} by user {} with role {}", customerId, userId, role);
        
        try {
            CustomerResponse response = customerService.updateCustomer(customerId, request, userId, role);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            log.error("Error updating customer {}: {}", customerId, e.getMessage());
            return ResponseEntity.badRequest().body(null);
        }
    }
    
    @DeleteMapping("/{customerId}")
    public ResponseEntity<Void> deleteCustomer(
            @PathVariable Long customerId,
            @RequestHeader("X-User-Role") String role) {
        
        log.info("Deleting customer {} by user with role {}", customerId, role);
        
        // Only ADMIN can delete customers
        if (!"ADMIN".equals(role)) {
            log.warn("Unauthorized delete attempt by role: {}", role);
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }
        
        try {
            customerService.deleteCustomer(customerId);
            return ResponseEntity.noContent().build();
        } catch (RuntimeException e) {
            log.error("Error deleting customer {}: {}", customerId, e.getMessage());
            return ResponseEntity.notFound().build();
        }
    }
    
    @PostMapping("/{customerId}/activate")
    public ResponseEntity<CustomerResponse> activateCustomer(
            @PathVariable Long customerId,
            @RequestHeader("X-User-Role") String role) {
        
        log.info("Activating customer {} by user with role {}", customerId, role);
        
        // Only ADMIN can activate customers
        if (!"ADMIN".equals(role)) {
            log.warn("Unauthorized activation attempt by role: {}", role);
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }
        
        try {
            CustomerResponse response = customerService.activateCustomer(customerId);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            log.error("Error activating customer {}: {}", customerId, e.getMessage());
            if (e.getMessage().contains("not found")) {
                return ResponseEntity.notFound().build();
            }
            return ResponseEntity.badRequest().build();
        }
    }
    
    @PostMapping("/{customerId}/deactivate")
    public ResponseEntity<CustomerResponse> deactivateCustomer(
            @PathVariable Long customerId,
            @RequestHeader("X-User-Role") String role) {
        
        log.info("Deactivating customer {} by user with role {}", customerId, role);
        
        // Only ADMIN can deactivate customers
        if (!"ADMIN".equals(role)) {
            log.warn("Unauthorized deactivation attempt by role: {}", role);
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }
        
        try {
            CustomerResponse response = customerService.deactivateCustomer(customerId);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            log.error("Error deactivating customer {}: {}", customerId, e.getMessage());
            if (e.getMessage().contains("not found")) {
                return ResponseEntity.notFound().build();
            }
            return ResponseEntity.badRequest().build();
        }
    }
    
    @GetMapping("/{customerId}/status")
    public ResponseEntity<Boolean> getCustomerStatus(
            @PathVariable Long customerId,
            @RequestHeader("X-User-Role") String role) {
        
        log.info("Getting customer {} status by user with role {}", customerId, role);
        
        // ADMIN and AGENT can check customer status
        if (!"ADMIN".equals(role) && !"AGENT".equals(role)) {
            log.warn("Unauthorized status check attempt by role: {}", role);
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }
        
        try {
            boolean isActive = customerService.isCustomerActive(customerId);
            return ResponseEntity.ok(isActive);
        } catch (RuntimeException e) {
            log.error("Error getting customer {} status: {}", customerId, e.getMessage());
            return ResponseEntity.notFound().build();
        }
    }
    
    @GetMapping("/by-user/{userId}")
    public ResponseEntity<CustomerResponse> getCustomerByUserId(@PathVariable Long userId) {
        log.debug("Getting customer by userId: {}", userId);
        
        try {
            CustomerResponse customer = customerService.getCustomerByUserId(userId);
            return ResponseEntity.ok(customer);
        } catch (RuntimeException e) {
            log.error("Customer not found for userId {}: {}", userId, e.getMessage());
            return ResponseEntity.notFound().build();
        }
    }
} 

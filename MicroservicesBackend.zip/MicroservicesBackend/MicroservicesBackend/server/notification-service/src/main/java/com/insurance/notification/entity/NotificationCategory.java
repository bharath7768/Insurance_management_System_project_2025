package com.insurance.notification.entity;

public enum NotificationCategory {
    SUCCESS,
    WARNING,
    INFO,
    ERROR
} 

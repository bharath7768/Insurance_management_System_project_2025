package com.insurance.notification.service;

import com.insurance.notification.dto.NotificationRequest;
import com.insurance.notification.dto.NotificationResponse;
import com.insurance.notification.entity.Notification;
import com.insurance.notification.entity.NotificationStatus;
import com.insurance.notification.entity.NotificationCategory;
import com.insurance.notification.entity.NotificationPriority;
import com.insurance.notification.entity.NotificationType;
import com.insurance.notification.entity.TargetRole;
import com.insurance.notification.repository.NotificationRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class NotificationService {
    
    private final NotificationRepository notificationRepository;
    // private final EmailService emailService; // DISABLED - SMTP blocked by company network
    
    public NotificationResponse createNotification(NotificationRequest request) {
        log.debug("Creating notification for customer ID: {} with role: {}", request.getCustomerId(), request.getTargetRole());
        
        Notification notification = new Notification();
        notification.setCustomerId(request.getCustomerId());
        
        // Safe conversion of string to enum with fallback
        notification.setTargetRole(parseTargetRole(request.getTargetRole()));
        notification.setTitle(request.getTitle());
        notification.setMessage(request.getMessage());
        notification.setType(parseNotificationType(request.getType()));
        notification.setCategory(parseNotificationCategory(request.getCategory()));
        notification.setPriority(parseNotificationPriority(request.getPriority()));
        notification.setStatus(NotificationStatus.PENDING);
        notification.setEmailSent(false); // Always false since email is disabled
        notification.setSmsSent(false);
        
        Notification savedNotification = notificationRepository.save(notification);
        log.info("Notification created successfully with ID: {}", savedNotification.getNotificationId());
        
        // Send email if requested (DISABLED - SMTP blocked by company network)
        if (request.getSendEmail() != null && request.getSendEmail()) {
            try {
                // TODO: Email sending disabled - SMTP blocked by company network
                log.info("Email sending disabled for notification: {} (SMTP blocked by company)", savedNotification.getNotificationId());
                savedNotification.setEmailSent(false); // Mark as not sent since SMTP is blocked
                savedNotification.setStatus(NotificationStatus.SENT); // But mark notification as successfully processed
            } catch (Exception e) {
                log.error("Failed to send email notification: {}", e.getMessage());
                savedNotification.setEmailSent(false);
                savedNotification.setStatus(NotificationStatus.FAILED);
            }
            notificationRepository.save(savedNotification);
        } else {
            // If email not requested, mark as sent
            savedNotification.setEmailSent(false); // No email was sent
            savedNotification.setStatus(NotificationStatus.SENT);
            notificationRepository.save(savedNotification);
        }
        
        return mapToResponse(savedNotification);
    }
    
    public NotificationResponse getNotificationById(Long notificationId) {
        Notification notification = notificationRepository.findById(notificationId)
                .orElseThrow(() -> new RuntimeException("Notification not found"));
        return mapToResponse(notification);
    }
    
    public List<NotificationResponse> getNotificationsByCustomerId(Long customerId) {
        List<Notification> notifications = notificationRepository.findByCustomerIdOrderByCreatedAtDesc(customerId);
        return notifications.stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }
    
    public List<NotificationResponse> getAllNotifications(Pageable pageable) {
        Page<Notification> notifications = notificationRepository.findAll(pageable);
        return notifications.getContent().stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }
    
    public List<NotificationResponse> getUnreadNotifications(Long customerId) {
        List<Notification> notifications = notificationRepository.findByCustomerIdAndStatus(customerId, NotificationStatus.SENT);
        return notifications.stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }
    
    public Long getUnreadCount(Long customerId) {
        return notificationRepository.countByCustomerIdAndStatus(customerId, NotificationStatus.SENT);
    }
    
    public NotificationResponse markAsRead(Long notificationId, Long customerId) {
        Notification notification = notificationRepository.findById(notificationId)
                .orElseThrow(() -> new RuntimeException("Notification not found"));
        
        if (!notification.getCustomerId().equals(customerId)) {
            throw new RuntimeException("Unauthorized to access this notification");
        }
        
        notification.setReadAt(LocalDateTime.now());
        
        Notification updatedNotification = notificationRepository.save(notification);
        return mapToResponse(updatedNotification);
    }
    
    public void markAllAsRead(Long customerId) {
        List<Notification> notifications = notificationRepository.findByCustomerIdAndStatus(customerId, NotificationStatus.SENT);
        notifications.forEach(notification -> {
            notification.setReadAt(LocalDateTime.now());
        });
        notificationRepository.saveAll(notifications);
    }
    
    // New role-based methods
    public List<NotificationResponse> getNotificationsByUserIdAndRole(Long userId, TargetRole targetRole) {
        if (targetRole == TargetRole.ADMIN) {
            // For admin, get both personal and system-wide notifications
            List<Notification> notifications = notificationRepository.findAdminNotifications(targetRole, userId);
            return notifications.stream()
                    .map(this::mapToResponse)
                    .collect(Collectors.toList());
        } else {
            // For users and agents, get notifications for their specific ID
            List<Notification> notifications = notificationRepository.findByCustomerIdAndTargetRoleOrderByCreatedAtDesc(userId, targetRole);
            return notifications.stream()
                    .map(this::mapToResponse)
                    .collect(Collectors.toList());
        }
    }
    
    public List<NotificationResponse> getUnreadNotificationsByUserIdAndRole(Long userId, TargetRole targetRole) {
        List<Notification> notifications = notificationRepository.findUnreadByCustomerIdAndTargetRole(userId, targetRole);
        return notifications.stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }
    
    public Long getUnreadCountByUserIdAndRole(Long userId, TargetRole targetRole) {
        return notificationRepository.countUnreadByCustomerIdAndTargetRole(userId, targetRole);
    }
    

    
    public void markAllAsReadByRole(Long userId, TargetRole targetRole) {
        List<Notification> notifications = notificationRepository.findByCustomerIdAndTargetRoleOrderByCreatedAtDesc(userId, targetRole);
        notifications.forEach(notification -> {
            if (notification.getReadAt() == null) {
                notification.setReadAt(LocalDateTime.now());
            }
        });
        notificationRepository.saveAll(notifications);
    }
    
    private NotificationResponse mapToResponse(Notification notification) {
        return new NotificationResponse(
                notification.getNotificationId(),
                notification.getCustomerId(),
                notification.getTargetRole(),
                notification.getTitle(),
                notification.getMessage(),
                notification.getType(),
                notification.getCategory(),
                notification.getPriority(),
                notification.getStatus(),
                notification.getEmailSent(),
                notification.getSmsSent(),
                notification.getReadAt(),
                notification.getCreatedAt()
        );
    }

    // Safe enum parsing methods with fallbacks
    private TargetRole parseTargetRole(Object targetRole) {
        if (targetRole == null) return TargetRole.USER;
        try {
            if (targetRole instanceof TargetRole) return (TargetRole) targetRole;
            String roleStr = targetRole.toString().toUpperCase();
            return TargetRole.valueOf(roleStr);
        } catch (Exception e) {
            log.warn("Invalid target role: {}, defaulting to USER", targetRole);
            return TargetRole.USER;
        }
    }
    
    private NotificationType parseNotificationType(Object type) {
        if (type == null) return NotificationType.GENERAL_ALERT;
        try {
            if (type instanceof NotificationType) return (NotificationType) type;
            String typeStr = type.toString().toUpperCase();
            return NotificationType.valueOf(typeStr);
        } catch (Exception e) {
            log.warn("Invalid notification type: {}, defaulting to GENERAL_ALERT", type);
            return NotificationType.GENERAL_ALERT;
        }
    }
    
    private NotificationCategory parseNotificationCategory(Object category) {
        if (category == null) return NotificationCategory.INFO;
        try {
            if (category instanceof NotificationCategory) return (NotificationCategory) category;
            String categoryStr = category.toString().toUpperCase();
            return NotificationCategory.valueOf(categoryStr);
        } catch (Exception e) {
            log.warn("Invalid notification category: {}, defaulting to INFO", category);
            return NotificationCategory.INFO;
        }
    }
    
    private NotificationPriority parseNotificationPriority(Object priority) {
        if (priority == null) return NotificationPriority.MEDIUM;
        try {
            if (priority instanceof NotificationPriority) return (NotificationPriority) priority;
            String priorityStr = priority.toString().toUpperCase();
            return NotificationPriority.valueOf(priorityStr);
        } catch (Exception e) {
            log.warn("Invalid notification priority: {}, defaulting to MEDIUM", priority);
            return NotificationPriority.MEDIUM;
        }
    }
}

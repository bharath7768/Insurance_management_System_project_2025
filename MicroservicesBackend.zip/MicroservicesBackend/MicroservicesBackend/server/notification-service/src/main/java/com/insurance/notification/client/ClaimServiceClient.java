package com.insurance.notification.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@FeignClient(name = "claim-service", path = "/api/claims")
public interface ClaimServiceClient {
    
    @GetMapping
    ResponseEntity<List<Object>> getAllClaims(
            @RequestHeader("X-User-Id") String userId,
            @RequestHeader("X-User-Role") String role
    );
    
    @GetMapping("/stats/daily")
    ResponseEntity<Map<String, Object>> getDailyStats(
            @RequestParam("date") String date,
            @RequestHeader("X-User-Id") String userId,
            @RequestHeader("X-User-Role") String role
    );
} 

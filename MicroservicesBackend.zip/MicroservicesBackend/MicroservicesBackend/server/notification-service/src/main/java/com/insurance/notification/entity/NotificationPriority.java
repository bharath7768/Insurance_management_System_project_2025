package com.insurance.notification.entity;

public enum NotificationPriority {
    HIGH,
    MEDIUM,
    LOW
} 

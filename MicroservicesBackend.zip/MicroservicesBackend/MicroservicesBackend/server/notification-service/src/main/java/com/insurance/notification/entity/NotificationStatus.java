package com.insurance.notification.entity;

public enum NotificationStatus {
    PENDING, SENT, FAILED, READ
}

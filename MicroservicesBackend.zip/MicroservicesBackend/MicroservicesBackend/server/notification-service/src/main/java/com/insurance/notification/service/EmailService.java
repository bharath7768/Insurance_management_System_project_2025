package com.insurance.notification.service;

import com.insurance.notification.client.CustomerServiceClient;
import com.insurance.notification.entity.Notification;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

//@Service // DISABLED - SMTP blocked by company network
@RequiredArgsConstructor  
@Slf4j
public class EmailService {
    
    private final JavaMailSender mailSender; // DISABLED - SMTP blocked by company network
    private final CustomerServiceClient customerServiceClient;  
    
    @Value("${spring.mail.from:noreply@insurance.com}") // Default value since mail config is disabled
    private String fromEmail;
    
    // DISABLED - All email functionality commented out due to SMTP being blocked by company network
    @Async
    public void sendNotificationEmail(Notification notification) {
        try {
            log.info("Attempting to send email for notification: {}", notification.getNotificationId());
            
            // Get customer email from customer service
            String customerEmail = getCustomerEmail(notification.getCustomerId());
            log.info("Sending email to: {} for notification: {}", customerEmail, notification.getNotificationId());
            
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom(fromEmail);
            message.setTo(customerEmail);
            message.setSubject(notification.getTitle());
            message.setText(notification.getMessage());
            
            mailSender.send(message);
            log.info("Email sent successfully for notification: {}", notification.getNotificationId());
        } catch (Exception e) {
            log.error("Failed to send email for notification: {}", notification.getNotificationId(), e);
            throw e;
        }
    }
    
    private String getCustomerEmail(Long customerId) {
        try {
            log.debug("Fetching email for customer ID: {}", customerId);
            var customerResponse = customerServiceClient.getCustomerById(customerId, "2", "ADMIN");
            if (customerResponse.getStatusCode().is2xxSuccessful() && customerResponse.getBody() != null) {
                String email = customerResponse.getBody().getEmail();
                log.debug("Found email for customer {}: {}", customerId, email);
                return email;
            }
        } catch (Exception e) {
            log.warn("Failed to fetch customer email for customer {}: {}", customerId, e.getMessage());
        }
        log.warn("Using fallback email for customer: {}", customerId);
        return "noreply@insurance.com"; // Fallback email
    }
}

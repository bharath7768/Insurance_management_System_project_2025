package com.insurance.notification.service;

import com.insurance.notification.client.ClaimServiceClient;
import com.insurance.notification.client.CustomerServiceClient;
import com.insurance.notification.dto.NotificationRequest;
import com.insurance.notification.entity.NotificationCategory;
import com.insurance.notification.entity.NotificationPriority;
import com.insurance.notification.entity.NotificationType;
import com.insurance.notification.entity.TargetRole;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
@Slf4j
public class ScheduledNotificationService {

    private final NotificationService notificationService;
    private final ClaimServiceClient claimServiceClient;
    
    /**
     * Send daily business summary to admin at 9 AM every day
     */
    @Scheduled(cron = "0 0 9 * * *") // 9 AM daily
    public void sendDailyBusinessSummary() {
        try {
            log.info("Starting daily business summary generation...");
            
            String today = LocalDate.now().format(DateTimeFormatter.ISO_LOCAL_DATE);
            String summary = generateDailyBusinessSummary(today);
            
            NotificationRequest notification = new NotificationRequest();
            notification.setCustomerId(2L); // Admin user ID
            notification.setTargetRole(TargetRole.ADMIN);
            notification.setTitle("📊 Daily Business Summary - " + LocalDate.now().format(DateTimeFormatter.ofPattern("dd MMM yyyy")));
            notification.setMessage(summary);
            notification.setType(NotificationType.ADMIN_DAILY_SUMMARY);
            notification.setCategory(NotificationCategory.INFO);
            notification.setPriority(NotificationPriority.MEDIUM);
            notification.setSendEmail(false);
            notification.setSendSms(false);
            
            notificationService.createNotification(notification);
            log.info("Daily business summary sent successfully");
            
        } catch (Exception e) {
            log.error("Failed to send daily business summary: {}", e.getMessage(), e);
        }
    }
    
    /**
     * Send daily digest to agents at 6 PM every day
     */
    @Scheduled(cron = "0 0 18 * * *") // 6 PM daily
    public void sendAgentDailyDigest() {
        try {
            log.info("Starting agent daily digest generation...");
            
            String today = LocalDate.now().format(DateTimeFormatter.ISO_LOCAL_DATE);
            String digest = generateAgentDailyDigest(today);
            
            // Send to all agents (simplified - in production, we'd get actual agent IDs)
            for (Long agentId : List.of(2L, 3L, 4L)) { // Sample agent IDs
                try {
                    NotificationRequest notification = new NotificationRequest();
                    notification.setCustomerId(agentId);
                    notification.setTargetRole(TargetRole.AGENT);
                    notification.setTitle("📋 Your Daily Digest - " + LocalDate.now().format(DateTimeFormatter.ofPattern("dd MMM yyyy")));
                    notification.setMessage(digest);
                    notification.setType(NotificationType.AGENT_DAILY_DIGEST);
                    notification.setCategory(NotificationCategory.INFO);
                    notification.setPriority(NotificationPriority.LOW);
                    notification.setSendEmail(false);
                    notification.setSendSms(false);
                    
                    notificationService.createNotification(notification);
                } catch (Exception e) {
                    log.error("Failed to send daily digest to agent {}: {}", agentId, e.getMessage());
                }
            }
            
            log.info("Agent daily digest sent successfully");
            
        } catch (Exception e) {
            log.error("Failed to send agent daily digest: {}", e.getMessage(), e);
        }
    }
    
    /**
     * Generate daily business summary with key metrics
     */
    private String generateDailyBusinessSummary(String date) {
        try {
            // For now, create a sample summary. In production, this would fetch real data
            StringBuilder summary = new StringBuilder();
            summary.append("📈 DAILY BUSINESS SUMMARY\n\n");
            summary.append("📅 Date: ").append(LocalDate.now().format(DateTimeFormatter.ofPattern("dd MMMM yyyy"))).append("\n\n");
            
            // Sample metrics - in production, fetch from services
            summary.append("💰 CLAIMS:\n");
            summary.append("• Total Claims Filed: 5\n");
            summary.append("• Total Claim Amount: ₹2,45,000\n");
            summary.append("• Average Claim: ₹49,000\n");
            summary.append("• High-Value Claims: 1 (₹1,25,000)\n\n");
            
            summary.append("📋 POLICIES:\n");
            summary.append("• New Policies: 3\n");
            summary.append("• Premium Collection: ₹1,15,000\n");
            summary.append("• Active Policies: 127\n\n");
            
            summary.append("👥 CUSTOMERS:\n");
            summary.append("• New Registrations: 2\n");
            summary.append("• Total Active Customers: 89\n\n");
            
            summary.append("⚠️ ALERTS:\n");
            summary.append("• Pending Claim Reviews: 8\n");
            summary.append("• Policies Expiring (30 days): 12\n");
            summary.append("• Overdue Premiums: 5\n\n");
            
            summary.append("📊 PERFORMANCE:\n");
            summary.append("• Claim Processing Time: 2.3 days avg\n");
            summary.append("• Customer Satisfaction: 4.2/5\n");
            summary.append("• System Uptime: 99.8%");
            
            return summary.toString();
            
        } catch (Exception e) {
            log.error("Error generating daily business summary: {}", e.getMessage());
            return "Daily business summary unavailable due to system error. Please check manually.";
        }
    }
    
    /**
     * Generate daily digest for agents
     */
    private String generateAgentDailyDigest(String date) {
        try {
            StringBuilder digest = new StringBuilder();
            digest.append("📋 YOUR DAILY DIGEST\n\n");
            digest.append("📅 ").append(LocalDate.now().format(DateTimeFormatter.ofPattern("dd MMMM yyyy"))).append("\n\n");
            
            // Sample agent metrics
            digest.append("🎯 YOUR TASKS:\n");
            digest.append("• Claims to Review: 3\n");
            digest.append("• Pending Customer Calls: 2\n");
            digest.append("• Policy Renewals Due: 5\n\n");
            
            digest.append("💰 YOUR PERFORMANCE:\n");
            digest.append("• Claims Processed Today: 4\n");
            digest.append("• Average Processing Time: 1.8 days\n");
            digest.append("• Customer Satisfaction: 4.5/5\n\n");
            
            digest.append("📈 THIS WEEK:\n");
            digest.append("• Total Claims Handled: 18\n");
            digest.append("• New Policies Sold: 2\n");
            digest.append("• Revenue Generated: ₹85,000\n\n");
            
            digest.append("⏰ UPCOMING:\n");
            digest.append("• Tomorrow: 3 customer meetings\n");
            digest.append("• This Week: 7 policy renewals\n");
            digest.append("• Monthly Target: 67% achieved");
            
            return digest.toString();
            
        } catch (Exception e) {
            log.error("Error generating agent daily digest: {}", e.getMessage());
            return "Daily digest unavailable due to system error. Please check your dashboard manually.";
        }
    }
    
    /**
     * Generate sample notifications for testing (run once on startup)
     */
    @Scheduled(initialDelay = 30000, fixedDelay = Long.MAX_VALUE) // Run 30 seconds after startup, then never again
    public void generateSampleNotifications() {
        try {
            log.info("Generating sample notifications for testing...");
            
            // Sample admin notifications
            createSampleAdminNotifications();
            
            // Sample agent notifications  
            createSampleAgentNotifications();
            
            log.info("Sample notifications generated successfully");
            
        } catch (Exception e) {
            log.error("Failed to generate sample notifications: {}", e.getMessage(), e);
        }
    }
    
    private void createSampleAdminNotifications() {
        // High-value claim alert
        NotificationRequest highValueAlert = new NotificationRequest();
        highValueAlert.setCustomerId(2L);
        highValueAlert.setTargetRole(TargetRole.ADMIN);
        highValueAlert.setTitle("⚠️ High-Value Claim Alert");
        highValueAlert.setMessage("HIGH-VALUE CLAIM: ₹3,75,000 (7.5x premium of ₹50,000) - Policy #1, Customer #6");
        highValueAlert.setType(NotificationType.ADMIN_HIGH_VALUE_CLAIM);
        highValueAlert.setCategory(NotificationCategory.WARNING);
        highValueAlert.setPriority(NotificationPriority.HIGH);
        highValueAlert.setSendEmail(false);
        highValueAlert.setSendSms(false);
        notificationService.createNotification(highValueAlert);
        
        // New claim alert
        NotificationRequest newClaimAlert = new NotificationRequest();
        newClaimAlert.setCustomerId(2L);
        newClaimAlert.setTargetRole(TargetRole.ADMIN);
        newClaimAlert.setTitle("New Claim Filed");
        newClaimAlert.setMessage("New claim filed: ₹85,000 for Policy #2 by Customer #7");
        newClaimAlert.setType(NotificationType.ADMIN_NEW_CLAIM_ALERT);
        newClaimAlert.setCategory(NotificationCategory.INFO);
        newClaimAlert.setPriority(NotificationPriority.MEDIUM);
        newClaimAlert.setSendEmail(false);
        newClaimAlert.setSendSms(false);
        notificationService.createNotification(newClaimAlert);
    }
    
    private void createSampleAgentNotifications() {
        // Claim assigned
        NotificationRequest claimAssigned = new NotificationRequest();
        claimAssigned.setCustomerId(2L); // Agent ID
        claimAssigned.setTargetRole(TargetRole.AGENT);
        claimAssigned.setTitle("New Claim Assigned");
        claimAssigned.setMessage("Claim #123 (₹1,25,000) has been assigned to you - Policy #3");
        claimAssigned.setType(NotificationType.AGENT_CLAIM_ASSIGNED);
        claimAssigned.setCategory(NotificationCategory.INFO);
        claimAssigned.setPriority(NotificationPriority.HIGH);
        claimAssigned.setSendEmail(false);
        claimAssigned.setSendSms(false);
        notificationService.createNotification(claimAssigned);
    }
} 

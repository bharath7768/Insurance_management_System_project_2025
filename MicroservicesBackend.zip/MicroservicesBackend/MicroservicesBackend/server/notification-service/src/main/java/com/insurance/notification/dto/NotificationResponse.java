package com.insurance.notification.dto;

import com.insurance.notification.entity.NotificationStatus;
import com.insurance.notification.entity.NotificationType;
import com.insurance.notification.entity.NotificationCategory;
import com.insurance.notification.entity.NotificationPriority;
import com.insurance.notification.entity.TargetRole;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class NotificationResponse {
    private Long notificationId;
    private Long customerId;      // Acts as targetId
    private TargetRole targetRole;
    private String title;
    private String message;
    private NotificationType type;
    private NotificationCategory category;
    private NotificationPriority priority;
    private NotificationStatus status;
    private Boolean emailSent;
    private Boolean smsSent;
    private LocalDateTime readAt;
    private LocalDateTime createdAt;
}

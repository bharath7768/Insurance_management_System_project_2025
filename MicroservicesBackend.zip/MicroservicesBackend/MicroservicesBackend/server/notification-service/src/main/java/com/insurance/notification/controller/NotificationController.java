package com.insurance.notification.controller;

import com.insurance.notification.dto.NotificationRequest;
import com.insurance.notification.dto.NotificationResponse;
import com.insurance.notification.entity.TargetRole;
import com.insurance.notification.service.NotificationService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/notifications")
@RequiredArgsConstructor
@Slf4j
public class NotificationController {

    private final NotificationService notificationService;

    @PostMapping
    public ResponseEntity<NotificationResponse> createNotification(
            @Valid @RequestBody NotificationRequest request,
            @RequestHeader("X-User-Role") String role) {
        // Only ADMIN and AGENT can create notifications
        if ("USER".equals(role)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(null);
        }

        try {
            NotificationResponse response = notificationService.createNotification(request);
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        } catch (RuntimeException e) {
            log.error("Error creating notification: {}", e.getMessage());
            return ResponseEntity.badRequest().body(null);
        }
    }

    @GetMapping("/{notificationId}")
    public ResponseEntity<NotificationResponse> getNotificationById(@PathVariable Long notificationId) {
        try {
            NotificationResponse response = notificationService.getNotificationById(notificationId);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping
    public ResponseEntity<List<NotificationResponse>> getAllNotifications(
            Pageable pageable,
            @RequestHeader("X-User-Role") String role) {
        // Only ADMIN can view all notifications
        if (!"ADMIN".equals(role)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(null);
        }

        List<NotificationResponse> notifications = notificationService.getAllNotifications(pageable);
        return ResponseEntity.ok(notifications);
    }

    @GetMapping("/customer/{customerId}")
    public ResponseEntity<List<NotificationResponse>> getNotificationsByCustomerId(
            @PathVariable Long customerId,
            @RequestHeader("X-User-Id") Long userId,
            @RequestHeader("X-User-Role") String role,
            @RequestHeader(value = "X-Customer-Id", required = false) String userCustomerIdStr) {
        // Users can only view their own notifications
        if ("USER".equals(role)) {
            if (userCustomerIdStr == null || userCustomerIdStr.isEmpty()) {
                return ResponseEntity.status(HttpStatus.FORBIDDEN).body(null);
            }
            Long userCustomerId = Long.parseLong(userCustomerIdStr);
            if (!customerId.equals(userCustomerId)) {
                return ResponseEntity.status(HttpStatus.FORBIDDEN).body(null);
            }
        }

        List<NotificationResponse> notifications = notificationService.getNotificationsByCustomerId(customerId);
        return ResponseEntity.ok(notifications);
    }

    @GetMapping("/customer/{customerId}/unread")
    public ResponseEntity<List<NotificationResponse>> getUnreadNotifications(
            @PathVariable Long customerId,
            @RequestHeader("X-User-Id") Long userId,
            @RequestHeader("X-User-Role") String role,
            @RequestHeader(value = "X-Customer-Id", required = false) String userCustomerIdStr) {
        // Users can only view their own notifications
        if ("USER".equals(role)) {
            if (userCustomerIdStr == null || userCustomerIdStr.isEmpty()) {
                return ResponseEntity.status(HttpStatus.FORBIDDEN).body(null);
            }
            Long userCustomerId = Long.parseLong(userCustomerIdStr);
            if (!customerId.equals(userCustomerId)) {
                return ResponseEntity.status(HttpStatus.FORBIDDEN).body(null);
            }
        }

        List<NotificationResponse> notifications = notificationService.getUnreadNotifications(customerId);
        return ResponseEntity.ok(notifications);
    }

    @GetMapping("/customer/{customerId}/unread/count")
    public ResponseEntity<Long> getUnreadCount(
            @PathVariable Long customerId,
            @RequestHeader("X-User-Id") Long userId,
            @RequestHeader("X-User-Role") String role,
            @RequestHeader(value = "X-Customer-Id", required = false) String userCustomerIdStr) {
        // Users can only view their own notifications
        if ("USER".equals(role)) {
            if (userCustomerIdStr == null || userCustomerIdStr.isEmpty()) {
                return ResponseEntity.status(HttpStatus.FORBIDDEN).body(null);
            }
            Long userCustomerId = Long.parseLong(userCustomerIdStr);
            if (!customerId.equals(userCustomerId)) {
                return ResponseEntity.status(HttpStatus.FORBIDDEN).body(null);
            }
        }

        Long count = notificationService.getUnreadCount(customerId);
        return ResponseEntity.ok(count);
    }

    @PutMapping("/{notificationId}/read")
    public ResponseEntity<Void> markAsRead(
            @PathVariable Long notificationId,
            @RequestHeader("X-User-Id") Long userId,
            @RequestHeader("X-User-Role") String role,
            @RequestHeader(value = "X-Customer-Id", required = false) String userCustomerIdStr,
            @RequestHeader(value = "X-Agent-Id", required = false) String userAgentIdStr) {

        // Verify ownership before allowing update
        NotificationResponse notification = notificationService.getNotificationById(notificationId);
        if (notification == null) {
            return ResponseEntity.notFound().build();
        }

        Long customerId = notification.getCustomerId();

        // Authorization check based on role
        switch (role) {
            case "ADMIN":
                // Admins can mark any notification as read
                break;

            case "USER":
                // Users can only mark their own notifications as read
                if (userCustomerIdStr == null || userCustomerIdStr.isEmpty()) {
                    log.warn("USER {} attempted to mark notification {} as read without customer ID", userId, notificationId);
                    return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
                }
                Long userCustomerId = Long.parseLong(userCustomerIdStr);
                if (!customerId.equals(userCustomerId)) {
                    log.warn("USER {} (customer {}) attempted to mark notification {} for customer {} as read",
                            userId, userCustomerId, notificationId, customerId);
                    return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
                }
                break;

            case "AGENT":
                // Agents can mark notifications for their assigned customers
                if (userAgentIdStr == null || userAgentIdStr.isEmpty()) {
                    log.warn("AGENT {} attempted to mark notification {} as read without agent ID", userId, notificationId);
                    return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
                }
                // For now, allow agents to mark any notification as read
                log.debug("AGENT {} marking notification {} as read for customer {}", userId, notificationId, customerId);
                break;

            default:
                log.warn("Unknown role {} attempted to mark notification {} as read", role, notificationId);
                return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }

        try {
            // For ADMIN users, use the customerId from the notification itself
            // For other users, use their respective IDs for ownership verification
            Long userIdForVerification;
            if ("ADMIN".equals(role)) {
                userIdForVerification = customerId; // Use the notification's customer ID
            } else if ("USER".equals(role)) {
                userIdForVerification = Long.parseLong(userCustomerIdStr);
            } else { // AGENT
                userIdForVerification = Long.parseLong(userAgentIdStr);
            }

            notificationService.markAsRead(notificationId, userIdForVerification);
            log.info("Notification {} marked as read by user {} with role {}", notificationId, userIdForVerification, role);
            return ResponseEntity.ok().build();
        } catch (RuntimeException e) {
            log.error("Error marking notification {} as read: {}", notificationId, e.getMessage());
            return ResponseEntity.badRequest().build();
        }
    }

    @PutMapping("/customer/{customerId}/read-all")
    public ResponseEntity<Void> markAllAsRead(
            @PathVariable Long customerId,
            @RequestHeader("X-User-Id") Long userId,
            @RequestHeader("X-User-Role") String role) {
        // Users can only mark their own notifications as read
        if ("USER".equals(role) && !customerId.equals(userId)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }

        notificationService.markAllAsRead(customerId);
        return ResponseEntity.noContent().build();
    }

    // NEW UNIVERSAL ENDPOINTS

    @GetMapping("/my")
    public ResponseEntity<List<NotificationResponse>> getMyNotifications(
            @RequestHeader(value = "X-Customer-Id", required = false) Long userId,
            @RequestHeader(value = "X-User-Id", required = false) Long adminId,
            @RequestHeader("X-User-Role") String role,
            @RequestHeader(value = "X-Agent-Id", required = false) String id) {

        TargetRole targetRole = mapStringRoleToEnum(role);

        // Determine the effective user ID based on role
        Long effectiveUserId;
        if ("ADMIN".equals(role)) {
            effectiveUserId = adminId; // Use admin's user ID
        } else if ("USER".equals(role)) {
            effectiveUserId = userId; // Use customer ID
        } else { // AGENT
            if (id == null) {
                return ResponseEntity.badRequest().build();
            }
            effectiveUserId = Long.valueOf(id); // Use agent ID
        }

        List<NotificationResponse> notifications = notificationService
                .getNotificationsByUserIdAndRole(effectiveUserId, targetRole);
        return ResponseEntity.ok(notifications);
    }

    @GetMapping("/my/unread")
    public ResponseEntity<List<NotificationResponse>> getMyUnreadNotifications(
            @RequestHeader(value = "X-Customer-Id", required = false) Long userId,
            @RequestHeader(value = "X-User-Id", required = false) Long adminId,
            @RequestHeader("X-User-Role") String role,
            @RequestHeader(value = "X-Agent-Id", required = false) String id){

        TargetRole targetRole = mapStringRoleToEnum(role);

        // Determine the effective user ID based on role
        Long effectiveUserId;
        if ("ADMIN".equals(role)) {
            effectiveUserId = adminId; // Use admin's user ID
        } else if ("USER".equals(role)) {
            effectiveUserId = userId; // Use customer ID
        } else { // AGENT
            if (id == null) {
                return ResponseEntity.badRequest().build();
            }
            effectiveUserId = Long.valueOf(id); // Use agent ID
        }

        List<NotificationResponse> notifications = notificationService
                .getUnreadNotificationsByUserIdAndRole(effectiveUserId, targetRole);
        return ResponseEntity.ok(notifications);
    }

    @GetMapping("/my/unread/count")
    public ResponseEntity<Long> getMyUnreadCount(
            @RequestHeader(value = "X-Customer-Id", required = false) Long userId,
            @RequestHeader(value = "X-User-Id", required = false) Long adminId,
            @RequestHeader("X-User-Role") String role,
            @RequestHeader(value = "X-Agent-Id", required = false) String id){

        TargetRole targetRole = mapStringRoleToEnum(role);

        // Determine the effective user ID based on role
        Long effectiveUserId;
        if ("ADMIN".equals(role)) {
            effectiveUserId = adminId; // Use admin's user ID
        } else if ("USER".equals(role)) {
            effectiveUserId = userId; // Use customer ID
        } else { // AGENT
            if (id == null) {
                return ResponseEntity.badRequest().build();
            }
            effectiveUserId = Long.valueOf(id); // Use agent ID
        }

        Long count = notificationService.getUnreadCountByUserIdAndRole(effectiveUserId, targetRole);
        return ResponseEntity.ok(count);
    }

    @PutMapping("/my/read-all")
    public ResponseEntity<Void> markAllMyNotificationsAsRead(
            @RequestHeader(value = "X-Customer-Id", required = false) Long userId,
            @RequestHeader(value = "X-User-Id", required = false) Long adminId,
            @RequestHeader("X-User-Role") String role,
            @RequestHeader(value = "X-Agent-Id", required = false) String id){

        TargetRole targetRole = mapStringRoleToEnum(role);

        // Determine the effective user ID based on role
        Long effectiveUserId;
        if ("ADMIN".equals(role)) {
            effectiveUserId = adminId; // Use admin's user ID
        } else if ("USER".equals(role)) {
            effectiveUserId = userId; // Use customer ID
        } else { // AGENT
            if (id == null) {
                return ResponseEntity.badRequest().build();
            }
            effectiveUserId = Long.valueOf(id); // Use agent ID
        }

        notificationService.markAllAsReadByRole(effectiveUserId, targetRole);
        return ResponseEntity.noContent().build();
    }

    // Helper method to map string role to enum
    private TargetRole mapStringRoleToEnum(String role) {
        switch (role.toUpperCase()) {
            case "USER":
                return TargetRole.USER;
            case "AGENT":
                return TargetRole.AGENT;
            case "ADMIN":
                return TargetRole.ADMIN;
            default:
                throw new IllegalArgumentException("Invalid role: " + role);
        }
    }
}

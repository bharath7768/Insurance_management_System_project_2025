package com.insurance.notification.repository;

import com.insurance.notification.entity.Notification;
import com.insurance.notification.entity.NotificationStatus;
import com.insurance.notification.entity.TargetRole;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface NotificationRepository extends JpaRepository<Notification, Long> {
    // Legacy methods (keep for backward compatibility)
    List<Notification> findByCustomerIdOrderByCreatedAtDesc(Long customerId);
    List<Notification> findByStatus(NotificationStatus status);
    List<Notification> findByCustomerIdAndStatus(Long customerId, NotificationStatus status);
    Long countByCustomerIdAndStatus(Long customerId, NotificationStatus status);
    
    // New role-based methods
    List<Notification> findByCustomerIdAndTargetRoleOrderByCreatedAtDesc(Long customerId, TargetRole targetRole);
    List<Notification> findByCustomerIdAndTargetRoleAndStatus(Long customerId, TargetRole targetRole, NotificationStatus status);
    Long countByCustomerIdAndTargetRoleAndStatus(Long customerId, TargetRole targetRole, NotificationStatus status);
    
    // Admin system notifications (targetId can be null for system-wide admin notifications)
    @Query("SELECT n FROM Notification n WHERE n.targetRole = :targetRole AND (n.customerId IS NULL OR n.customerId = :customerId) ORDER BY n.createdAt DESC")
    List<Notification> findAdminNotifications(@Param("targetRole") TargetRole targetRole, @Param("customerId") Long customerId);
    
    // Get unread notifications for role-based queries
    @Query("SELECT n FROM Notification n WHERE n.customerId = :customerId AND n.targetRole = :targetRole AND n.readAt IS NULL ORDER BY n.createdAt DESC")
    List<Notification> findUnreadByCustomerIdAndTargetRole(@Param("customerId") Long customerId, @Param("targetRole") TargetRole targetRole);
    
    // Count unread notifications
    @Query("SELECT COUNT(n) FROM Notification n WHERE n.customerId = :customerId AND n.targetRole = :targetRole AND n.readAt IS NULL")
    Long countUnreadByCustomerIdAndTargetRole(@Param("customerId") Long customerId, @Param("targetRole") TargetRole targetRole);
}

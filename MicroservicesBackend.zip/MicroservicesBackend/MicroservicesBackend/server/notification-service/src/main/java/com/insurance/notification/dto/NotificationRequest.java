package com.insurance.notification.dto;

import com.insurance.notification.entity.NotificationType;
import com.insurance.notification.entity.NotificationCategory;
import com.insurance.notification.entity.NotificationPriority;
import com.insurance.notification.entity.TargetRole;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class NotificationRequest {
    @NotNull(message = "Customer ID is required")
    private Long customerId;  // Acts as targetId
    
    @NotNull(message = "Target role is required")
    private TargetRole targetRole = TargetRole.USER;
    
    @NotBlank(message = "Title is required")
    private String title;
    
    @NotBlank(message = "Message is required")
    private String message;
    
    @NotNull(message = "Notification type is required")
    private NotificationType type;
    
    @NotNull(message = "Category is required")
    private NotificationCategory category = NotificationCategory.INFO;
    
    @NotNull(message = "Priority is required")
    private NotificationPriority priority = NotificationPriority.MEDIUM;
    
    private Boolean sendEmail = false;
    
    private Boolean sendSms = false;
}

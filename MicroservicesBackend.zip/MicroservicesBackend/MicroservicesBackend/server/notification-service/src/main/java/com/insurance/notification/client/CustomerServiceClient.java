package com.insurance.notification.client;

import com.insurance.notification.dto.CustomerResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;

@FeignClient(name = "customer-service", path = "/api/customers")
public interface CustomerServiceClient {
    
    @GetMapping("/{customerId}")
    ResponseEntity<CustomerResponse> getCustomerById(
            @PathVariable Long customerId,
            @RequestHeader("X-User-Id") String userId,
            @RequestHeader("X-User-Role") String role
    );
} 

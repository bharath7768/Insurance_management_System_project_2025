package com.insurance.notification.entity;

public enum TargetRole {
    USER,    // Customer
    AGENT,   // Insurance Agent  
    ADMIN    // Administrator
} 

package com.insurance.gateway.filter;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.auth0.jwt.interfaces.DecodedJWT;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;
import org.springframework.core.io.buffer.DataBuffer;

@Component
@Slf4j
public class JwtAuthenticationFilter extends AbstractGatewayFilterFactory<JwtAuthenticationFilter.Config> {

    @Value("${jwt.secret}")
    private String jwtSecret;

    public JwtAuthenticationFilter() {
        super(Config.class);
    }

    @Override
    public GatewayFilter apply(Config config) {
        return (exchange, chain) -> {
            ServerHttpRequest request = exchange.getRequest();
            
            if (!request.getHeaders().containsKey(HttpHeaders.AUTHORIZATION)) {
                return onError(exchange, "Missing authorization header", HttpStatus.UNAUTHORIZED);
            }

            String authHeader = request.getHeaders().get(HttpHeaders.AUTHORIZATION).get(0);
            if (!authHeader.startsWith("Bearer ")) {
                return onError(exchange, "Invalid authorization header", HttpStatus.UNAUTHORIZED);
            }

            String token = authHeader.substring(7);
            
            try {
                DecodedJWT decodedJWT = JWT.require(Algorithm.HMAC256(jwtSecret))
                        .build()
                        .verify(token);
                
                String userId = decodedJWT.getSubject();
                String username = decodedJWT.getClaim("username").asString();
                String role = decodedJWT.getClaim("role").asString();
                
                // Extract entity IDs from JWT
                String customerId = getClaim(decodedJWT, "customerId");
                String agentId = getClaim(decodedJWT, "agentId");
                
                log.debug("JWT validation successful - User: {}, Role: {}, CustomerId: {}, AgentId: {}", 
                        username, role, customerId, agentId);

                System.out.println("JWT validation successful - User: " + username + ", Role: " + role + ", CustomerId: " + customerId + ", AgentId: " + agentId);
                
                // Build modified request with all headers
                ServerHttpRequest.Builder requestBuilder = request.mutate()
                        .header("X-User-Id", userId)
                        .header("X-User-Role", role);
                
                // Add entity headers if present
                if (customerId != null && !customerId.isEmpty()) {
                    requestBuilder.header("X-Customer-Id", customerId);
                }
                if (agentId != null && !agentId.isEmpty()) {
                    requestBuilder.header("X-Agent-Id", agentId);
                }
                
                ServerHttpRequest modifiedRequest = requestBuilder.build();
                
                log.debug("Headers added - X-User-Id: {}, X-User-Role: {}, X-Customer-Id: {}, X-Agent-Id: {}", 
                        userId, role, customerId, agentId);
                
                return chain.filter(exchange.mutate().request(modifiedRequest).build());
                
            } catch (JWTVerificationException e) {
                log.error("JWT verification failed: {}", e.getMessage());
                return onError(exchange, "Invalid JWT token", HttpStatus.UNAUTHORIZED);
            }
        };
    }
    
    private String getClaim(DecodedJWT jwt, String claimName) {
        var claim = jwt.getClaim(claimName);
        return claim.isNull() ? null : claim.asString();
    }

    private Mono<Void> onError(ServerWebExchange exchange, String err, HttpStatus httpStatus) {
        ServerHttpResponse response = exchange.getResponse();
        response.setStatusCode(httpStatus);
        return response.setComplete();
    }

    public static class Config {
        // Configuration properties if needed
    }
} 

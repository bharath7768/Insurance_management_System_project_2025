package com.insurance.gateway.config;

import com.insurance.gateway.filter.JwtAuthenticationFilter;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class GatewayConfig {

    private final JwtAuthenticationFilter jwtAuthenticationFilter;

    public GatewayConfig(JwtAuthenticationFilter jwtAuthenticationFilter) {
        this.jwtAuthenticationFilter = jwtAuthenticationFilter;
    }

    @Bean
    public RouteLocator customRouteLocator(RouteLocatorBuilder builder) {
        return builder.routes()
                // Auth Service - Public endpoints (no JWT required)
                .route("auth-public", r -> r
                        .path("/api/auth/login", "/api/auth/health")
                        .uri("lb://auth-service"))

                 // Auth Service - Secured endpoints (require JWT)
                .route("auth-secured", r -> r
                        .path("/api/auth/**")
                        .filters(f -> f.filter(jwtAuthenticationFilter.apply(new JwtAuthenticationFilter.Config())))
                        .uri("lb://auth-service"))
                
                // Customer Service
                .route("customer-service", r -> r.path("/api/customers/**")
                        .filters(f -> f.filter(jwtAuthenticationFilter.apply(new JwtAuthenticationFilter.Config())))
                        .uri("lb://customer-service"))
                
                // Policy Service
                .route("policy-service", r -> r.path("/api/policies/**")
                        .filters(f -> f.filter(jwtAuthenticationFilter.apply(new JwtAuthenticationFilter.Config())))
                        .uri("lb://policy-service"))
                
                // Claim Service
                .route("claim-service", r -> r.path("/api/claims/**")
                        .filters(f -> f.filter(jwtAuthenticationFilter.apply(new JwtAuthenticationFilter.Config())))
                        .uri("lb://claim-service"))
                
                // Agent Service
                .route("agent-service", r -> r.path("/api/agents/**")
                        .filters(f -> f.filter(jwtAuthenticationFilter.apply(new JwtAuthenticationFilter.Config())))
                        .uri("lb://agent-service"))
                
                // Notification Service
                .route("notification-service", r -> r.path("/api/notifications/**")
                        .filters(f -> f.filter(jwtAuthenticationFilter.apply(new JwtAuthenticationFilter.Config())))
                        .uri("lb://notification-service"))
                        
                .build();
    }
} 

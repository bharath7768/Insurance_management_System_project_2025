package com.insurance.policy.service;

import com.insurance.policy.client.ClaimServiceClient;
import com.insurance.policy.client.CustomerServiceClient;
import com.insurance.policy.client.NotificationServiceClient;
import com.insurance.policy.dto.PolicyRequest;
import com.insurance.policy.dto.PolicyResponse;
import com.insurance.policy.entity.Policy;
import com.insurance.policy.entity.PolicyStatus;
import com.insurance.policy.repository.PolicyRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

class PolicyServiceTest {
    @Mock
    private PolicyRepository policyRepository;
    @Mock
    private NotificationServiceClient notificationServiceClient;
    @Mock
    private CustomerServiceClient customerServiceClient;
    @Mock
    private ClaimServiceClient claimServiceClient;
    @InjectMocks
    private PolicyService policyService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testCreatePolicy_Success() {
        PolicyRequest request = new PolicyRequest();
        request.setName("Health Policy");
        request.setPremiumAmount(BigDecimal.valueOf(1000));
        request.setCoverageAmount(BigDecimal.valueOf(50000));
        request.setCoverageDetails("Covers hospitalization");
        request.setValidityPeriod(12);
        request.setCustomerId(1L);
        request.setAgentId(2L);
        request.setStartDate(LocalDate.now());
        when(customerServiceClient.getCustomerById(anyLong(), any(), any())).thenReturn(ResponseEntity.ok(Collections.emptyMap()));
        Policy policy = new Policy();
        policy.setPolicyId(10L);
        policy.setName(request.getName());
        policy.setPremiumAmount(request.getPremiumAmount());
        policy.setCoverageAmount(request.getCoverageAmount());
        policy.setCoverageDetails(request.getCoverageDetails());
        policy.setValidityPeriod(request.getValidityPeriod());
        policy.setCustomerId(request.getCustomerId());
        policy.setAgentId(request.getAgentId());
        policy.setStartDate(request.getStartDate());
        policy.setEndDate(request.getStartDate().plusMonths(request.getValidityPeriod()));
        policy.setStatus(PolicyStatus.ACTIVE);
        when(policyRepository.save(any(Policy.class))).thenReturn(policy);
        when(notificationServiceClient.createNotification(any(), any(), any())).thenReturn(ResponseEntity.ok().build());
        PolicyResponse response = policyService.createPolicy(request);
        assertNotNull(response);
        assertEquals("Health Policy", response.getName());
        assertEquals(PolicyStatus.ACTIVE, response.getStatus());
    }

    @Test
    void testCreatePolicy_CustomerNotFound() {
        PolicyRequest request = new PolicyRequest();
        request.setCustomerId(999L);
        when(customerServiceClient.getCustomerById(anyLong(), any(), any())).thenReturn(ResponseEntity.status(404).body(null));
        RuntimeException ex = assertThrows(RuntimeException.class, () -> policyService.createPolicy(request));
        assertTrue(ex.getMessage().contains("Customer not found"));
    }

    @Test
    void testGetPolicyById_Found() {
        Policy policy = new Policy();
        policy.setPolicyId(10L);
        policy.setName("Health Policy");
        when(policyRepository.findById(10L)).thenReturn(Optional.of(policy));
        PolicyResponse response = policyService.getPolicyById(10L);
        assertNotNull(response);
        assertEquals(10L, response.getPolicyId());
    }

    @Test
    void testGetPolicyById_NotFound() {
        when(policyRepository.findById(anyLong())).thenReturn(Optional.empty());
        RuntimeException ex = assertThrows(RuntimeException.class, () -> policyService.getPolicyById(10L));
        assertEquals("Policy not found", ex.getMessage());
    }

    @Test
    void testGetAllPolicies_Paginated() {
        Policy policy1 = new Policy();
        policy1.setPolicyId(1L);
        Policy policy2 = new Policy();
        policy2.setPolicyId(2L);
        List<Policy> policies = Arrays.asList(policy1, policy2);
        Page<Policy> page = new PageImpl<>(policies);
        when(policyRepository.findAll(any(Pageable.class))).thenReturn(page);
        List<PolicyResponse> responses = policyService.getAllPolicies(PageRequest.of(0, 10));
        assertEquals(2, responses.size());
    }

    @Test
    void testGetPoliciesByCustomerId() {
        Policy policy1 = new Policy();
        policy1.setPolicyId(1L);
        Policy policy2 = new Policy();
        policy2.setPolicyId(2L);
        List<Policy> policies = Arrays.asList(policy1, policy2);
        when(policyRepository.findByCustomerId(1L)).thenReturn(policies);
        List<PolicyResponse> responses = policyService.getPoliciesByCustomerId(1L);
        assertEquals(2, responses.size());
    }

    @Test
    void testGetPoliciesByAgentId() {
        Policy policy1 = new Policy();
        policy1.setPolicyId(1L);
        Policy policy2 = new Policy();
        policy2.setPolicyId(2L);
        List<Policy> policies = Arrays.asList(policy1, policy2);
        when(policyRepository.findByAgentId(2L)).thenReturn(policies);
        List<PolicyResponse> responses = policyService.getPoliciesByAgentId(2L);
        assertEquals(2, responses.size());
    }

    @Test
    void testUpdatePolicy_Success() {
        PolicyRequest request = new PolicyRequest();
        request.setName("Updated Policy");
        request.setPremiumAmount(BigDecimal.valueOf(2000));
        request.setCoverageAmount(BigDecimal.valueOf(100000));
        request.setCoverageDetails("Updated coverage");
        request.setValidityPeriod(24);
        Policy policy = new Policy();
        policy.setPolicyId(10L);
        policy.setName("Old Policy");
        policy.setPremiumAmount(BigDecimal.valueOf(1000));
        policy.setCoverageAmount(BigDecimal.valueOf(50000));
        policy.setCoverageDetails("Old coverage");
        policy.setValidityPeriod(12);
        policy.setStartDate(LocalDate.now());
        when(policyRepository.findById(10L)).thenReturn(Optional.of(policy));
        when(policyRepository.save(any(Policy.class))).thenReturn(policy);
        PolicyResponse response = policyService.updatePolicy(10L, request);
        assertNotNull(response);
        assertEquals("Updated Policy", response.getName());
        assertEquals(BigDecimal.valueOf(2000), response.getPremiumAmount());
    }

    @Test
    void testUpdatePolicy_NotFound() {
        PolicyRequest request = new PolicyRequest();
        when(policyRepository.findById(anyLong())).thenReturn(Optional.empty());
        RuntimeException ex = assertThrows(RuntimeException.class, () -> policyService.updatePolicy(10L, request));
        assertEquals("Policy not found", ex.getMessage());
    }
}


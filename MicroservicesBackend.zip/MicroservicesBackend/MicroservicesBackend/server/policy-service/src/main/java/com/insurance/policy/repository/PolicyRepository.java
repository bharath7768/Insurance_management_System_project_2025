package com.insurance.policy.repository;

import com.insurance.policy.entity.Policy;
import com.insurance.policy.entity.PolicyStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface PolicyRepository extends JpaRepository<Policy, Long> {
    List<Policy> findByCustomerId(Long customerId);
    List<Policy> findByAgentId(Long agentId);
    List<Policy> findByStatus(PolicyStatus status);
    List<Policy> findByEndDateBeforeAndStatus(LocalDate date, PolicyStatus status);
}


package com.insurance.policy.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(name = "claim-service", path = "/api/claims")
public interface ClaimServiceClient {
    
    @PostMapping("/policy/{policyId}/inactive")
    ResponseEntity<Void> handlePolicyInactiveClaims(
            @PathVariable Long policyId,
            @RequestParam String reason,
            @RequestHeader("X-User-Role") String role
    );
} 

package com.insurance.policy.controller;

import com.insurance.policy.dto.PolicyRequest;
import com.insurance.policy.dto.PolicyResponse;
import com.insurance.policy.service.PolicyService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/policies")
@RequiredArgsConstructor
@Slf4j
public class PolicyController {
    
    private final PolicyService policyService;
    
    @PostMapping
    public ResponseEntity<PolicyResponse> createPolicy(
            @Valid @RequestBody PolicyRequest request,
            @RequestHeader("X-User-Id") Long userId,
            @RequestHeader("X-User-Role") String role) {
        
        log.info("Creating policy request from user: {} with role: {}", userId, role);
        
        // Only ADMIN can create policies
        if (!"ADMIN".equals(role) && !"AGENT".equals(role)) {
            log.warn("Unauthorized policy creation attempt by role: {}", role);
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(null);
        }
        
        try {
            PolicyResponse response = policyService.createPolicy(request);
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        } catch (RuntimeException e) {
            log.error("Error creating policy: {}", e.getMessage());
            return ResponseEntity.badRequest().body(null);
        }
    }
    
    @GetMapping("/{policyId}")
    public ResponseEntity<PolicyResponse> getPolicyById(
            @PathVariable Long policyId,
            @RequestHeader("X-User-Id") Long userId,
            @RequestHeader("X-User-Role") String role) {
        
        log.debug("Getting policy {} by user {} with role {}", policyId, userId, role);
        
        try {
            PolicyResponse response = policyService.getPolicyById(policyId);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            log.error("Error fetching policy {}: {}", policyId, e.getMessage());
            return ResponseEntity.notFound().build();
        }
    }
    
    @GetMapping
    public ResponseEntity<List<PolicyResponse>> getAllPolicies(
            Pageable pageable,
            @RequestHeader("X-User-Role") String role) {
        
        log.debug("Getting all policies by user with role: {}", role);
        
        // Only ADMIN can view all policies
        if (!"ADMIN".equals(role)) {
            log.warn("Unauthorized access attempt to view all policies by role: {}", role);
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(null);
        }
        
        List<PolicyResponse> policies = policyService.getAllPolicies(pageable);
        return ResponseEntity.ok(policies);
    }
    
    @GetMapping("/customer/{customerId}")
    public ResponseEntity<List<PolicyResponse>> getPoliciesByCustomerId(
            @PathVariable Long customerId,
            @RequestHeader("X-User-Id") Long userId,
            @RequestHeader("X-User-Role") String role,
            @RequestHeader(value = "X-Customer-Id", required = false) String userCustomerIdStr) {
        
        log.debug("Getting policies for customer {} by user {} with role {}", customerId, userId, role);
        log.debug("value of userCustomerIdStr: {}", userCustomerIdStr);
        
        // Users can only view their own policies, agents and admin can view any
        if ("USER".equals(role)) {
            if (userCustomerIdStr == null || userCustomerIdStr.isEmpty()) {
                log.warn("User {} attempted to view policies without customer ID", userId);
                return ResponseEntity.status(HttpStatus.FORBIDDEN).body(null);
            }
            Long userCustomerId = Long.parseLong(userCustomerIdStr);
            if (!customerId.equals(userCustomerId)) {
                log.warn("User {} (customer {}) attempted to view policies for customer {} without permission", 
                        userId, userCustomerId, customerId);
                return ResponseEntity.status(HttpStatus.FORBIDDEN).body(null);
            }
        }
        
        List<PolicyResponse> policies = policyService.getPoliciesByCustomerId(customerId);
        return ResponseEntity.ok(policies);
    }
    
    @GetMapping("/agent/{agentId}")
    public ResponseEntity<List<PolicyResponse>> getPoliciesByAgentId(
            @PathVariable Long agentId,
            @RequestHeader("X-User-Id") Long userId,
            @RequestHeader("X-User-Role") String role) {
        
        log.debug("Getting policies for agent {} by user {} with role {}", agentId, userId, role);
        
        // Agents can only view their own policies, admin can view any
//        if ("AGENT".equals(role) && !agentId.equals(userId)) {
//            log.warn("Agent {} attempted to view policies for agent {} without permission", userId, agentId);
//            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(null);
//        }
        if ("USER".equals(role)) {
            log.warn("User {} attempted to view agent policies without permission", userId);
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(null);
        }
        
        List<PolicyResponse> policies = policyService.getPoliciesByAgentId(agentId);
        return ResponseEntity.ok(policies);
    }
    
    @PutMapping("/{policyId}")
    public ResponseEntity<PolicyResponse> updatePolicy(
            @PathVariable Long policyId,
            @Valid @RequestBody PolicyRequest request,
            @RequestHeader("X-User-Role") String role) {
        
        log.info("Updating policy {} by user with role {}", policyId, role);
        
        // Only ADMIN  can update policies
        if (!"ADMIN".equals(role) && !"AGENT".equals(role)) {
            log.warn("Unauthorized policy update attempt by role: {}", role);
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(null);
        }
        
        try {
            PolicyResponse response = policyService.updatePolicy(policyId, request);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            log.error("Error updating policy {}: {}", policyId, e.getMessage());
            return ResponseEntity.badRequest().body(null);
        }
    }
    
    @DeleteMapping("/{policyId}")
    public ResponseEntity<Void> cancelPolicy(
            @PathVariable Long policyId,
            @RequestHeader("X-User-Role") String role) {
        
        log.info("Cancelling policy {} by user with role {}", policyId, role);
        
        // Only ADMIN  can cancel policies
        if (!"ADMIN".equals(role) && !"AGENT".equals(role)) {
            log.warn("Unauthorized policy cancellation attempt by role: {}", role);
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }
        
        try {
            policyService.cancelPolicy(policyId);
            return ResponseEntity.noContent().build();
        } catch (RuntimeException e) {
            log.error("Error cancelling policy {}: {}", policyId, e.getMessage());
            return ResponseEntity.notFound().build();
        }
    }
    
    @PutMapping("/{policyId}/inactive")
    public ResponseEntity<PolicyResponse> markPolicyInactive(
            @PathVariable Long policyId,
            @RequestBody String reason,
            @RequestHeader("X-User-Role") String role) {
        
        log.info("Marking policy {} as inactive by user with role {}", policyId, role);
        
        // Only ADMIN can mark policies as inactive
        if (!"ADMIN".equals(role) && !"AGENT".equals(role)) {
            log.warn("Unauthorized policy inactive attempt by role: {}", role);
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(null);
        }
        
        try {
            PolicyResponse response = policyService.markPolicyInactive(policyId, reason, role);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            log.error("Error marking policy {} as inactive: {}", policyId, e.getMessage());
            return ResponseEntity.badRequest().body(null);
        }
    }

    @GetMapping("/expiring")
    public ResponseEntity<List<PolicyResponse>> getExpiringPolicies(
            @RequestHeader("X-User-Role") String role) {
        
        log.debug("Getting expiring policies by user with role: {}", role);
        
        // Only ADMIN and AGENT can view expiring policies
        if (!"ADMIN".equals(role) && !"AGENT".equals(role)) {
            log.warn("Unauthorized access to expiring policies by role: {}", role);
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(null);
        }
        
        List<PolicyResponse> policies = policyService.getExpiringPolicies();
        return ResponseEntity.ok(policies);
    }
} 

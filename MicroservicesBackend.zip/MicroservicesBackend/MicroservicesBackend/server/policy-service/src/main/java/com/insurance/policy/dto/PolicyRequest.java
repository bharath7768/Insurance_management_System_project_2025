package com.insurance.policy.dto;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
public class PolicyRequest {
    @NotBlank(message = "Policy name is required")
    private String name;
    
    @NotNull(message = "Premium amount is required")
    @DecimalMin(value = "0.0", inclusive = false, message = "Premium amount must be greater than 0")
    private BigDecimal premiumAmount;
    
    @NotNull(message = "Coverage amount is required")
    @DecimalMin(value = "0.0", inclusive = false, message = "Coverage amount must be greater than 0")
    private BigDecimal coverageAmount;
    
    @NotBlank(message = "Coverage details are required")
    private String coverageDetails;
    
    @NotNull(message = "Validity period is required")
    @Min(value = 1, message = "Validity period must be at least 1 month")
    private Integer validityPeriod;
    
    @NotNull(message = "Customer ID is required")
    private Long customerId;
    
    private Long agentId;
    
    @NotNull(message = "Start date is required")
    private LocalDate startDate;
} 

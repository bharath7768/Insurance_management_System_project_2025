package com.insurance.policy.dto;

import com.insurance.policy.entity.PolicyStatus;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PolicyResponse {
    private Long policyId;
    private String name;
    private BigDecimal premiumAmount;
    private BigDecimal coverageAmount;
    private String coverageDetails;
    private Integer validityPeriod;
    private Long customerId;
    private Long agentId;
    private LocalDate startDate;
    private LocalDate endDate;
    private PolicyStatus status;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
} 

package com.insurance.policy.service;

import com.insurance.policy.client.ClaimServiceClient;
import com.insurance.policy.client.CustomerServiceClient;
import com.insurance.policy.client.NotificationServiceClient;
import com.insurance.policy.dto.NotificationRequest;
import com.insurance.policy.dto.PolicyRequest;
import com.insurance.policy.dto.PolicyResponse;
import com.insurance.policy.entity.Policy;
import com.insurance.policy.entity.PolicyStatus;
import com.insurance.policy.repository.PolicyRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Slf4j
public class PolicyService {
    
    private final PolicyRepository policyRepository;
    private final NotificationServiceClient notificationServiceClient;
    private final CustomerServiceClient customerServiceClient;
    private final ClaimServiceClient claimServiceClient;
    
    public PolicyResponse createPolicy(PolicyRequest request) {
        log.info("Creating policy: {}", request.getName());
        
        // Validate customer exists
        validateCustomerExists(request.getCustomerId());
        
        Policy policy = new Policy();
        policy.setName(request.getName());
        policy.setPremiumAmount(request.getPremiumAmount());
        policy.setCoverageAmount(request.getCoverageAmount());
        policy.setCoverageDetails(request.getCoverageDetails());
        policy.setValidityPeriod(request.getValidityPeriod());
        policy.setCustomerId(request.getCustomerId());
        policy.setAgentId(request.getAgentId());
        policy.setStartDate(request.getStartDate());
        policy.setEndDate(request.getStartDate().plusMonths(request.getValidityPeriod()));
        policy.setStatus(PolicyStatus.ACTIVE);
        
        Policy savedPolicy = policyRepository.save(policy);
        log.info("Policy created successfully with ID: {}", savedPolicy.getPolicyId());
        
        // Send policy creation notification
        sendPolicyCreationNotification(savedPolicy);
        
        return mapToResponse(savedPolicy);
    }
    
    private void validateCustomerExists(Long customerId) {
        try {
            var customerResponse = customerServiceClient.getCustomerById(customerId, "2", "ADMIN");
            if (!customerResponse.getStatusCode().is2xxSuccessful()) {
                throw new RuntimeException("Customer not found with ID: " + customerId);
            }
        } catch (Exception e) {
            log.error("Failed to validate customer existence: {}", e.getMessage());
            throw new RuntimeException("Failed to validate customer: " + e.getMessage());
        }
    }
    
    private void sendPolicyCreationNotification(Policy policy) {
        try {
            NotificationRequest notification = new NotificationRequest();
            notification.setCustomerId(policy.getCustomerId());
            notification.setTargetRole("USER");
            notification.setTitle("New Policy Created Successfully");
            notification.setMessage("Congratulations! Your new " + policy.getName() + " policy is now active. " +
                "Policy ID: " + policy.getPolicyId() + ". Premium: ₹" + policy.getPremiumAmount() + 
                ". Coverage: " + policy.getCoverageDetails());
            notification.setType("WELCOME_MESSAGE");
            notification.setCategory("SUCCESS");
            notification.setPriority("HIGH");
            notification.setSendEmail(false);
            notification.setSendSms(false);
            
            notificationServiceClient.createNotification(notification, "2", "ADMIN");
            log.info("Policy creation notification sent for policy: {}", policy.getPolicyId());
        } catch (Exception e) {
            log.error("Failed to send policy creation notification for policy: {}", policy.getPolicyId(), e);
        }
    }

    public PolicyResponse getPolicyById(Long policyId) {
        log.debug("Fetching policy with ID: {}", policyId);
        Policy policy = policyRepository.findById(policyId)
                .orElseThrow(() -> new RuntimeException("Policy not found"));
        return mapToResponse(policy);
    }
    
    public List<PolicyResponse> getAllPolicies(Pageable pageable) {
        log.debug("Fetching all policies with pagination");
        Page<Policy> policies = policyRepository.findAll(pageable);
        return policies.getContent().stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }
    
    public List<PolicyResponse> getPoliciesByCustomerId(Long customerId) {
        log.debug("Fetching policies for customer ID: {}", customerId);
        List<Policy> policies = policyRepository.findByCustomerId(customerId);
        return policies.stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }
    
    public List<PolicyResponse> getPoliciesByAgentId(Long agentId) {
        log.debug("Fetching policies for agent ID: {}", agentId);
        List<Policy> policies = policyRepository.findByAgentId(agentId);
        return policies.stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }
    
    @Transactional
    public PolicyResponse updatePolicy(Long policyId, PolicyRequest request) {
        log.info("Updating policy with ID: {}", policyId);
        
        Policy policy = policyRepository.findById(policyId)
                .orElseThrow(() -> new RuntimeException("Policy not found"));
        
        // Update policy fields
        policy.setName(request.getName());
        policy.setPremiumAmount(request.getPremiumAmount());
        policy.setCoverageAmount(request.getCoverageAmount());
        policy.setCoverageDetails(request.getCoverageDetails());
        policy.setValidityPeriod(request.getValidityPeriod());
        
        // Calculate new end date based on updated validity period
        policy.setEndDate(policy.getStartDate().plusMonths(request.getValidityPeriod()));
        
        Policy updatedPolicy = policyRepository.save(policy);
        log.info("Policy updated successfully with ID: {}", updatedPolicy.getPolicyId());
        
        // Send policy update notification
        try {
            NotificationRequest notification = new NotificationRequest();
            notification.setCustomerId(policy.getCustomerId());
            notification.setTargetRole("USER");
            notification.setTitle("Policy Updated");
            notification.setMessage(String.format("Your policy %s has been updated successfully.", policy.getName()));
            notification.setType("GENERAL_ALERT");
            notification.setCategory("INFO");
            notification.setPriority("MEDIUM");
            notification.setSendEmail(false);
            notification.setSendSms(false);
            
            notificationServiceClient.createNotification(notification, "2", "ADMIN");
            log.info("Policy update notification sent for policy: {}", policy.getPolicyId());
        } catch (Exception e) {
            log.error("Failed to send policy update notification for policy: {}", policy.getPolicyId(), e);
        }
        
        return mapToResponse(updatedPolicy);
    }
    
    @Transactional
    public void cancelPolicy(Long policyId) {
        var policy = policyRepository.findById(policyId)
                .orElseThrow(() -> new RuntimeException("Policy not found with ID: " + policyId));
        
        if (policy.getStatus() == PolicyStatus.CANCELLED) {
            throw new RuntimeException("Policy is already cancelled");
        }
        
        policy.setStatus(PolicyStatus.CANCELLED);
        policy.setUpdatedAt(LocalDateTime.now());
        policyRepository.save(policy);
        
        log.info("Policy cancelled successfully with ID: {}", policyId);
        
        // Send policy cancellation notification
        try {
            var notification = new NotificationRequest();
            notification.setCustomerId(policy.getCustomerId());
            notification.setTargetRole("USER");
            notification.setTitle("Policy Cancelled");
            notification.setMessage(String.format("Your policy %s has been cancelled.", policy.getName()));
            notification.setType("GENERAL_ALERT");
            notification.setCategory("WARNING");
            notification.setPriority("HIGH");
            notification.setSendEmail(false);
            notification.setSendSms(false);
            
            notificationServiceClient.createNotification(notification, "2", "ADMIN");
            log.info("Policy cancellation notification sent for policy: {}", policy.getPolicyId());
        } catch (Exception e) {
            log.error("Failed to send policy cancellation notification for policy: {}", policy.getPolicyId(), e);
        }
    }
    
    // NEW METHOD: Mark policy as inactive and handle related claims
    public PolicyResponse markPolicyInactive(Long policyId, String reason, String userRole) {
        log.info("Marking policy {} as inactive by {} role. Reason: {}", policyId, userRole, reason);
        
        Policy policy = policyRepository.findById(policyId)
                .orElseThrow(() -> new RuntimeException("Policy not found"));
        
        policy.setStatus(PolicyStatus.INACTIVE);
        Policy inactivePolicy = policyRepository.save(policy);
        
        // Send policy inactive notification
        sendPolicyInactiveNotification(inactivePolicy, reason);
        
        // Notify claim service to handle existing claims for this policy
        try {
            claimServiceClient.handlePolicyInactiveClaims(policyId, reason, userRole);
            log.info("Notified claim service about inactive policy: {} by role: {}", policyId, userRole);
        } catch (Exception e) {
            log.error("Failed to notify claim service about inactive policy {}: {}", policyId, e.getMessage());
        }
        
        log.info("Policy marked as inactive with ID: {} by role: {}", policyId, userRole);
        return mapToResponse(inactivePolicy);
    }
    
    private void sendPolicyInactiveNotification(Policy policy, String reason) {
        try {
            NotificationRequest notification = new NotificationRequest();
            notification.setCustomerId(policy.getCustomerId());
            notification.setTargetRole("USER");
            notification.setTitle("Policy Status Changed to Inactive");
            notification.setMessage("Your " + policy.getName() + " policy has been marked as INACTIVE. " +
                "Reason: " + reason + ". " +
                "This means no new claims can be filed under this policy. " +
                "Existing claims will continue to be processed. " +
                "Please contact your agent for more information.");
            notification.setType("GENERAL_ALERT");
            notification.setCategory("WARNING");
            notification.setPriority("HIGH");
            notification.setSendEmail(false);
            notification.setSendSms(false);
            
            notificationServiceClient.createNotification(notification, "2", "ADMIN");
            log.info("Policy inactive notification sent for policy: {}", policy.getPolicyId());
        } catch (Exception e) {
            log.error("Failed to send policy inactive notification for policy: {}", policy.getPolicyId(), e);
        }
    }
    
    public List<PolicyResponse> getExpiringPolicies() {
        log.debug("Fetching expiring policies");
        LocalDate thirtyDaysFromNow = LocalDate.now().plusDays(30);
        List<Policy> policies = policyRepository.findByEndDateBeforeAndStatus(thirtyDaysFromNow, PolicyStatus.ACTIVE);
        return policies.stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }
    
    private PolicyResponse mapToResponse(Policy policy) {
        return new PolicyResponse(
                policy.getPolicyId(),
                policy.getName(),
                policy.getPremiumAmount(),
                policy.getCoverageAmount(),
                policy.getCoverageDetails(),
                policy.getValidityPeriod(),
                policy.getCustomerId(),
                policy.getAgentId(),
                policy.getStartDate(),
                policy.getEndDate(),
                policy.getStatus(),
                policy.getCreatedAt(),
                policy.getUpdatedAt()
        );
    }

    // Helper method to check if policy is expired  
    private boolean isPolicyExpired(Policy policy) {
        return LocalDate.now().isAfter(policy.getEndDate());
    }
    
    // Send policy expiration warning
    private void sendPolicyExpirationWarning(Policy policy) {
        try {
            var notification = new NotificationRequest();
            notification.setCustomerId(policy.getCustomerId());
            notification.setTargetRole("USER");
            notification.setTitle("Policy Expiring Soon");
            notification.setMessage(String.format("Your policy %s is expiring on %s. Please renew to avoid coverage gaps.", 
                    policy.getName(), policy.getEndDate()));
            notification.setType("POLICY_RENEWAL");
            notification.setCategory("WARNING");
            notification.setPriority("HIGH");
            notification.setSendEmail(false);
            notification.setSendSms(false);
            
            notificationServiceClient.createNotification(notification, "2", "ADMIN");
            log.info("Policy expiration warning sent for policy: {}", policy.getPolicyId());
        } catch (Exception e) {
            log.error("Failed to send policy expiration warning for policy: {}", policy.getPolicyId(), e);
        }
    }
} 

package com.insurance.policy.entity;

public enum PolicyStatus {
    ACTIVE, INACTIVE, EXPIRED, CANCELLED
} 

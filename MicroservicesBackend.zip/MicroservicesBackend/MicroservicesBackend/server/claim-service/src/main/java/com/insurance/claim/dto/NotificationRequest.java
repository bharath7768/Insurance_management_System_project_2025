package com.insurance.claim.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class NotificationRequest {
    private Long customerId;           // Acts as targetId
    private String targetRole = "USER"; // USER/AGENT/ADMIN
    private String title;
    private String message;
    private NotificationType type;
    private String category = "INFO";   // success/warning/info/error
    private String priority = "MEDIUM"; // HIGH/MEDIUM/LOW
    private Boolean sendEmail = false;
    private Boolean sendSms = false;
} 

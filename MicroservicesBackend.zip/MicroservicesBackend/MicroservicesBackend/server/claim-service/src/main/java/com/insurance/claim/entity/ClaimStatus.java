package com.insurance.claim.entity;

public enum ClaimStatus {
    FILED, UNDER_REVIEW, APPROVED, REJECTED
}

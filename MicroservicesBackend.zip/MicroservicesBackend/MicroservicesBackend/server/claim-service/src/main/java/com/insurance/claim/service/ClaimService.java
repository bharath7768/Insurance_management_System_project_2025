package com.insurance.claim.service;

import com.insurance.claim.client.CustomerServiceClient;
import com.insurance.claim.client.NotificationServiceClient;
import com.insurance.claim.client.PolicyServiceClient;
import com.insurance.claim.dto.ClaimProcessRequest;
import com.insurance.claim.dto.ClaimRequest;
import com.insurance.claim.dto.ClaimResponse;
import com.insurance.claim.dto.NotificationRequest;
import com.insurance.claim.dto.NotificationType;
import com.insurance.claim.entity.Claim;
import com.insurance.claim.entity.ClaimStatus;
import com.insurance.claim.repository.ClaimRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.math.BigDecimal;

@Service
@RequiredArgsConstructor
@Slf4j
public class ClaimService {
    
    private final ClaimRepository claimRepository;
    private final NotificationServiceClient notificationServiceClient;
    private final PolicyServiceClient policyServiceClient;
    private final CustomerServiceClient customerServiceClient;
    
    public ClaimResponse fileClaim(ClaimRequest request) {
        log.info("Filing claim for policy ID: {} by customer ID: {}", request.getPolicyId(), request.getCustomerId());
        
        // Validate policy exists and is active
        validatePolicyForClaim(request.getPolicyId());
        
        // Validate claim amount against total coverage limit
        validateClaimAmountAgainstCoverage(request.getPolicyId(), request.getClaimAmount());
        
        Claim claim = new Claim();
        claim.setPolicyId(request.getPolicyId());
        claim.setCustomerId(request.getCustomerId());
        claim.setClaimAmount(request.getClaimAmount());
        claim.setDescription(request.getDescription());
        claim.setStatus(ClaimStatus.FILED);
        claim.setAgentId(request.getAgentId());  // Set agent if provided
        
        Claim savedClaim = claimRepository.save(claim);
        log.info("Claim filed successfully with ID: {}", savedClaim.getClaimId());
        
        // Send notifications for claim filing
        sendClaimFilingNotifications(savedClaim);
        
        return mapToResponse(savedClaim);
    }
    
    private void validatePolicyForClaim(Long policyId) {
        try {
            var policyResponse = policyServiceClient.getPolicyById(policyId, "2", "ADMIN");
            if (!policyResponse.getStatusCode().is2xxSuccessful()) {
                throw new RuntimeException("Policy not found with ID: " + policyId);
            }
            // Note: In a real implementation, we would check if the policy status is ACTIVE
            // For now, we just check if it exists
        } catch (Exception e) {
            log.error("Failed to validate policy for claim: {}", e.getMessage());
            throw new RuntimeException("Failed to validate policy: " + e.getMessage());
        }
    }
    
    private void validateClaimAmountAgainstCoverage(Long policyId, BigDecimal newClaimAmount) {
        try {
            log.debug("Validating claim amount against coverage for policy ID: {}", policyId);
            
            // Get policy details
            var policyResponse = policyServiceClient.getPolicyById(policyId, "2", "ADMIN");
            if (!policyResponse.getStatusCode().is2xxSuccessful() || policyResponse.getBody() == null) {
                throw new RuntimeException("Failed to retrieve policy details for validation");
            }
            
            // Extract policy coverage amount from response
            Map<String, Object> policyData = (Map<String, Object>) policyResponse.getBody();
            BigDecimal coverageAmount = new BigDecimal(policyData.get("coverageAmount").toString());
            
            // Get existing claims for this policy (only approved and pending claims count towards limit)
            List<Claim> existingClaims = claimRepository.findByPolicyIdAndStatusIn(
                policyId, 
                List.of(ClaimStatus.APPROVED, ClaimStatus.FILED, ClaimStatus.UNDER_REVIEW)
            );
            
            // Calculate total of existing claims
            BigDecimal totalExistingClaims = existingClaims.stream()
                .map(Claim::getClaimAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
            
            // Check if new claim would exceed coverage
            BigDecimal totalWithNewClaim = totalExistingClaims.add(newClaimAmount);
            if (totalWithNewClaim.compareTo(coverageAmount) > 0) {
                BigDecimal remainingCoverage = coverageAmount.subtract(totalExistingClaims);
                log.warn("Claim amount validation failed - Policy ID: {}, Coverage: {}, Existing claims: {}, New claim: {}, Remaining: {}", 
                    policyId, coverageAmount, totalExistingClaims, newClaimAmount, remainingCoverage);
                throw new RuntimeException(String.format(
                    "Claim amount ₹%s exceeds remaining coverage. Total coverage: ₹%s, Existing claims: ₹%s, Remaining coverage: ₹%s",
                    newClaimAmount, coverageAmount, totalExistingClaims, remainingCoverage
                ));
            }
            
            log.debug("Claim amount validation passed - Policy ID: {}, Coverage: {}, Existing claims: {}, New claim: {}", 
                policyId, coverageAmount, totalExistingClaims, newClaimAmount);
                
        } catch (Exception e) {
            log.error("Failed to validate claim amount against coverage for policy {}: {}", policyId, e.getMessage());
            throw new RuntimeException("Failed to validate claim amount: " + e.getMessage());
        }
    }
    
    private void sendClaimFilingNotifications(Claim claim) {
        // 1. Send notification to customer (existing functionality)
        sendCustomerClaimFiledNotification(claim);
        
        // 2. Send notification to admin about new claim
        sendAdminNewClaimNotification(claim);
        
        // 3. Check if high-value claim and notify admin
        checkAndNotifyHighValueClaim(claim);
        
        // 4. If claim has agent assigned, notify agent
        if (claim.getAgentId() != null) {
            sendAgentClaimAssignedNotification(claim);
        }
    }
    
    /**
     * Send notification to customer about successful claim filing
     */
    private void sendCustomerClaimFiledNotification(Claim claim) {
        try {
            var notification = new NotificationRequest();
            notification.setCustomerId(claim.getCustomerId());
            notification.setTargetRole("USER");
            notification.setTitle("Claim Filed Successfully");
            notification.setMessage("Your claim has been filed successfully and is under review.");
            notification.setType(NotificationType.CLAIM_STATUS_UPDATE);
            notification.setCategory("SUCCESS");
            notification.setPriority("HIGH");
            notification.setSendEmail(false);
            notification.setSendSms(false);
            
            notificationServiceClient.createNotification(notification, "2", "ADMIN");
            log.info("Customer claim filing notification sent for claim: {}", claim.getClaimId());
        } catch (Exception e) {
            log.error("Failed to send customer claim filing notification for claim: {}", claim.getClaimId(), e);
        }
    }
    
    /**
     * Send notification to admin about new claim
     */
    private void sendAdminNewClaimNotification(Claim claim) {
        try {
            var notification = new NotificationRequest();
            notification.setCustomerId(2L); // Admin user ID
            notification.setTargetRole("ADMIN");
            notification.setTitle("New Claim Filed");
            notification.setMessage(String.format("New claim filed: ₹%s for Policy #%d by Customer #%d", 
                    claim.getClaimAmount(), claim.getPolicyId(), claim.getCustomerId()));
            notification.setType(NotificationType.ADMIN_NEW_CLAIM_ALERT);
            notification.setCategory("INFO");
            notification.setPriority("MEDIUM");
            notification.setSendEmail(false);
            notification.setSendSms(false);
            
            notificationServiceClient.createNotification(notification, "2", "ADMIN");
            log.info("Admin new claim notification sent for claim: {}", claim.getClaimId());
        } catch (Exception e) {
            log.error("Failed to send admin new claim notification for claim: {}", claim.getClaimId(), e);
        }
    }
    
    /**
     * Check if claim is high-value and notify admin
     */
    private void checkAndNotifyHighValueClaim(Claim claim) {
        try {
            // Get policy details to calculate threshold
            var policyResponse = policyServiceClient.getPolicyById(claim.getPolicyId(), "2", "ADMIN");
            if (!policyResponse.getStatusCode().is2xxSuccessful() || policyResponse.getBody() == null) {
                log.warn("Could not fetch policy details for high-value check, claim: {}", claim.getClaimId());
                return;
            }
            
            Map<String, Object> policyData = (Map<String, Object>) policyResponse.getBody();
            
            if (isHighValueClaim(claim, policyData)) {
                sendAdminHighValueClaimNotification(claim, policyData);
            }
        } catch (Exception e) {
            log.error("Failed to check high-value claim for claim: {}", claim.getClaimId(), e);
        }
    }
    
    /**
     * Determine if claim is high-value based on business rules
     */
    private boolean isHighValueClaim(Claim claim, Map<String, Object> policyData) {
        BigDecimal claimAmount = claim.getClaimAmount();
        BigDecimal premiumAmount = new BigDecimal(policyData.get("premiumAmount").toString());
        
        // Business rules for high-value claims:
        // 1. Claims > ₹5,00,000 are automatically high-value
        // 2. Claims > 3x annual premium are high-value
        // 3. Use minimum threshold of ₹50,000 for small premiums
        
        BigDecimal absoluteHighThreshold = new BigDecimal("500000"); // ₹5 Lakhs
        BigDecimal premiumMultiplier = premiumAmount.multiply(new BigDecimal("3")); // 3x premium
        BigDecimal minimumThreshold = new BigDecimal("50000"); // ₹50,000
        
        // Use the appropriate threshold
        BigDecimal threshold = premiumMultiplier.max(minimumThreshold);
        
        return claimAmount.compareTo(absoluteHighThreshold) > 0 || 
               claimAmount.compareTo(threshold) > 0;
    }
    
    /**
     * Send high-value claim alert to admin
     */
    private void sendAdminHighValueClaimNotification(Claim claim, Map<String, Object> policyData) {
        try {
            BigDecimal premiumAmount = new BigDecimal(policyData.get("premiumAmount").toString());
            BigDecimal ratio = claim.getClaimAmount().divide(premiumAmount, 2, BigDecimal.ROUND_HALF_UP);
            
            var notification = new NotificationRequest();
            notification.setCustomerId(2L); // Admin user ID
            notification.setTargetRole("ADMIN");
            notification.setTitle("⚠️ High-Value Claim Alert");
            notification.setMessage(String.format("HIGH-VALUE CLAIM: ₹%s (%.1fx premium of ₹%s) - Policy #%d, Customer #%d", 
                    claim.getClaimAmount(), ratio, premiumAmount, 
                    claim.getPolicyId(), claim.getCustomerId()));
            notification.setType(NotificationType.ADMIN_HIGH_VALUE_CLAIM);
            notification.setCategory("WARNING");
            notification.setPriority("HIGH");
            notification.setSendEmail(false);
            notification.setSendSms(false);
            
            notificationServiceClient.createNotification(notification, "2", "ADMIN");
            log.info("Admin high-value claim notification sent for claim: {} (Amount: ₹{})", 
                    claim.getClaimId(), claim.getClaimAmount());
        } catch (Exception e) {
            log.error("Failed to send admin high-value claim notification for claim: {}", claim.getClaimId(), e);
        }
    }
    
    /**
     * Send notification to agent when claim is assigned
     */
    private void sendAgentClaimAssignedNotification(Claim claim) {
        try {
            var notification = new NotificationRequest();
            notification.setCustomerId(claim.getAgentId()); // Agent user ID
            notification.setTargetRole("AGENT");
            notification.setTitle("New Claim Assigned");
            notification.setMessage(String.format("Claim #%d (₹%s) has been assigned to you - Policy #%d", 
                    claim.getClaimId(), claim.getClaimAmount(), claim.getPolicyId()));
            notification.setType(NotificationType.AGENT_CLAIM_ASSIGNED);
            notification.setCategory("INFO");
            notification.setPriority("HIGH");
            notification.setSendEmail(false);
            notification.setSendSms(false);
            
            notificationServiceClient.createNotification(notification, "2", "ADMIN");
            log.info("Agent claim assigned notification sent for claim: {} to agent: {}", 
                    claim.getClaimId(), claim.getAgentId());
        } catch (Exception e) {
            log.error("Failed to send agent claim assigned notification for claim: {}", claim.getClaimId(), e);
        }
    }

    public ClaimResponse getClaimById(Long claimId) {
        log.debug("Fetching claim with ID: {}", claimId);
        Claim claim = claimRepository.findById(claimId)
                .orElseThrow(() -> new RuntimeException("Claim not found"));
        return mapToResponse(claim);
    }
    
    public List<ClaimResponse> getAllClaims(Pageable pageable) {
        log.debug("Fetching all claims with pagination");
        Page<Claim> claims = claimRepository.findAll(pageable);
        return claims.getContent().stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    public List<ClaimResponse> getClaimsByCustomerId(Long requestedCustomerId, Long userId, String role) {
        log.debug("Fetching claims for customer ID: {}", requestedCustomerId);

        ResponseEntity<Object> profileResponse = customerServiceClient.getMyProfile(userId.toString(), role);
        System.out.println(profileResponse.getBody());
        System.out.println(requestedCustomerId);

        if (profileResponse.getStatusCode().is2xxSuccessful() && profileResponse.getBody() != null) {
            Map<String, Object> profile = (Map<String, Object>) profileResponse.getBody();
            Long actualCustomerId = Long.valueOf(profile.get("customerId").toString());

            if ("USER".equals(role) && !requestedCustomerId.equals(actualCustomerId)) {
                log.warn("User {} attempted to access claims for customer {} without permission", userId, requestedCustomerId);
                throw new AccessDeniedException("You are not authorized to view these claims.");
            }
        }
        List<Claim> claims = claimRepository.findByCustomerId(requestedCustomerId);
        return claims.stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    public List<ClaimResponse> getClaimsByPolicyId(Long policyId) {
        log.debug("Fetching claims for policy ID: {}", policyId);
        List<Claim> claims = claimRepository.findByPolicyId(policyId);
        return claims.stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }
    
    public List<ClaimResponse> getClaimsByAgentId(Long agentId) {
        log.debug("Fetching claims for agent ID: {}", agentId);
        List<Claim> claims = claimRepository.findByAgentId(agentId);
        return claims.stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }
    
    public List<ClaimResponse> getClaimsByStatus(ClaimStatus status) {
        log.debug("Fetching claims with status: {}", status);
        List<Claim> claims = claimRepository.findByStatus(status);
        return claims.stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }
    
    public ClaimResponse processClaim(Long claimId, ClaimProcessRequest request, Long agentId) {
        log.info("Processing claim ID: {} with status: {} by agent ID: {}", claimId, request.getStatus(), agentId);
        
        Claim claim = claimRepository.findById(claimId)
                .orElseThrow(() -> new RuntimeException("Claim not found"));
        
        ClaimStatus oldStatus = claim.getStatus();
        Long oldAgentId = claim.getAgentId();
        claim.setStatus(request.getStatus());
        claim.setAgentId(agentId);
        
        if (request.getStatus() == ClaimStatus.REJECTED && request.getRejectionReason() != null) {
            claim.setRejectionReason(request.getRejectionReason());
        }
        
        Claim updatedClaim = claimRepository.save(claim);
        log.info("Claim processed successfully with ID: {}", updatedClaim.getClaimId());
        
        // Send claim status update notification
        sendClaimStatusUpdateNotification(updatedClaim, oldStatus);
        
        // If agent was newly assigned, send assignment notification
        if (oldAgentId == null && agentId != null) {
            sendAgentClaimAssignedNotification(updatedClaim);
        }
        
        return mapToResponse(updatedClaim);
    }
    
    private void sendClaimStatusUpdateNotification(Claim claim, ClaimStatus oldStatus) {
        try {
            String message = getClaimStatusMessage(claim, oldStatus);
            
            NotificationRequest notification = new NotificationRequest();
            notification.setCustomerId(claim.getCustomerId());
            notification.setTargetRole("USER");
            notification.setTitle("Claim Status Update");
            notification.setMessage(message);
            notification.setType(NotificationType.CLAIM_STATUS_UPDATE);
            notification.setCategory("INFO");
            notification.setPriority("HIGH");
            notification.setSendEmail(false); // Disabled - SMTP blocked by company network
            notification.setSendSms(false);
            
            notificationServiceClient.createNotification(notification, "2", "ADMIN");
            log.info("Claim status update notification sent for claim: {}", claim.getClaimId());
        } catch (Exception e) {
            log.error("Failed to send claim status update notification for claim: {}", claim.getClaimId(), e);
        }
    }
    
    private String getClaimStatusMessage(Claim claim, ClaimStatus oldStatus) {
        String baseMessage = "Your claim #" + claim.getClaimId() + " for amount ₹" + claim.getClaimAmount();
        
        switch (claim.getStatus()) {
            case UNDER_REVIEW:
                return baseMessage + " is now under review. Our claims team is carefully examining your case. " +
                       "We will update you once the review is complete.";
            case APPROVED:
                return "Great news! " + baseMessage + " has been APPROVED! " +
                       "The reimbursement will be processed within 3-5 business days. " +
                       "You will receive the amount in your registered bank account.";
            case REJECTED:
                String reason = claim.getRejectionReason() != null ? 
                    " Reason: " + claim.getRejectionReason() : "";
                return "We regret to inform you that " + baseMessage + " has been REJECTED." + reason + 
                       " If you believe this is an error, please contact our customer service.";
            default:
                return baseMessage + " status has been updated to " + claim.getStatus();
        }
    }
    
    // Method to handle claims when policy becomes inactive
    public void handlePolicyInactiveClaims(Long policyId, String reason) {
        log.info("Handling claims for inactive policy: {}", policyId);
        
        // Get all pending/under review claims for this policy
        List<Claim> activeClaims = claimRepository.findByPolicyIdAndStatusIn(
            policyId, 
            List.of(ClaimStatus.FILED, ClaimStatus.UNDER_REVIEW)
        );
        
        for (Claim claim : activeClaims) {
            // Notify customers about claim status due to policy inactivity
            sendPolicyInactiveClaimNotification(claim, reason);
        }
        
        log.info("Processed {} claims for inactive policy {}", activeClaims.size(), policyId);
    }
    
    private void sendPolicyInactiveClaimNotification(Claim claim, String reason) {
        try {
            NotificationRequest notification = new NotificationRequest();
            notification.setCustomerId(claim.getCustomerId());
            notification.setTargetRole("USER");
            notification.setTitle("Important: Claim Processing Update");
            notification.setMessage("Your claim #" + claim.getClaimId() + " is being processed under a policy that has been marked inactive. " +
                "Reason: " + reason + ". " +
                "This claim will continue to be processed normally, but no new claims can be filed under this policy. " +
                "Please contact your agent for more information.");
            notification.setType(NotificationType.CLAIM_STATUS_UPDATE);
            notification.setCategory("WARNING");
            notification.setPriority("HIGH");
            notification.setSendEmail(false);
            notification.setSendSms(false);
            
            notificationServiceClient.createNotification(notification, "2", "ADMIN");
            log.info("Policy inactive claim notification sent for claim: {}", claim.getClaimId());
        } catch (Exception e) {
            log.error("Failed to send policy inactive claim notification for claim: {}", claim.getClaimId(), e);
        }
    }
    
    public void deleteClaim(Long claimId) {
        log.info("Deleting claim with ID: {}", claimId);
        if (!claimRepository.existsById(claimId)) {
            throw new RuntimeException("Claim not found");
        }
        claimRepository.deleteById(claimId);
        log.info("Claim deleted successfully with ID: {}", claimId);
    }

    public boolean hasExistingClaim(Long customerId, Long policyId) {
        return claimRepository.existsByCustomerIdAndPolicyId(customerId, policyId);
    }
    
    private ClaimResponse mapToResponse(Claim claim) {
        return new ClaimResponse(
                claim.getClaimId(),
                claim.getPolicyId(),
                claim.getCustomerId(),
                claim.getClaimAmount(),
                claim.getDescription(),
                claim.getStatus(),
                claim.getAgentId(),
                claim.getRejectionReason(),
                claim.getCreatedAt(),
                claim.getUpdatedAt()
        );
    }
} 

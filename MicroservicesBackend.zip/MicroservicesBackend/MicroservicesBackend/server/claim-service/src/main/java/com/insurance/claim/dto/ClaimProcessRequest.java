package com.insurance.claim.dto;

import com.insurance.claim.entity.ClaimStatus;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class ClaimProcessRequest {
    @NotNull(message = "Status is required")
    private ClaimStatus status;
    
    private String rejectionReason;
}

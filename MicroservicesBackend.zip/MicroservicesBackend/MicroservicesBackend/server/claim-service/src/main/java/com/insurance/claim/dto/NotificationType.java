package com.insurance.claim.dto;

public enum NotificationType {
    POLICY_RENEWAL,
    CLAIM_STATUS_UPDATE,
    PAYMENT_REMINDER,
    GENERAL_ALERT,
    WELCOME_MESSAGE,
    
    // Admin Notifications
    ADMIN_NEW_CLAIM_ALERT,
    ADMIN_HIGH_VALUE_CLAIM,
    ADMIN_DAILY_SUMMARY,
    
    // Agent Notifications
    AGENT_CLAIM_ASSIGNED,
    AGENT_DAILY_DIGEST
} 

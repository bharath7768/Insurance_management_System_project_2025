package com.insurance.claim.controller;

import com.insurance.claim.dto.ClaimProcessRequest;
import com.insurance.claim.dto.ClaimRequest;
import com.insurance.claim.dto.ClaimResponse;
import com.insurance.claim.entity.ClaimStatus;
import com.insurance.claim.service.ClaimService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/claims")
@RequiredArgsConstructor
@Slf4j
public class ClaimController {
    
    private final ClaimService claimService;
    
    @PostMapping
    public ResponseEntity<ClaimResponse> fileClaim(
            @Valid @RequestBody ClaimRequest request,
            @RequestHeader("X-User-Id") Long userId,
            @RequestHeader("X-User-Role") String role,
            @RequestHeader(value = "X-Customer-Id", required = false) String userCustomerIdStr) {
        
        log.info("Filing claim request from user: {} with role: {}", userId, role);
        
        // Users can only file claims for themselves
        if ("USER".equals(role)) {
            if (userCustomerIdStr == null || userCustomerIdStr.isEmpty()) {
                log.warn("User {} attempted to file claim without customer ID", userId);
                return ResponseEntity.status(HttpStatus.FORBIDDEN).body(null);
            }
            Long userCustomerId = Long.parseLong(userCustomerIdStr);
            if (!request.getCustomerId().equals(userCustomerId)) {
                log.warn("User {} (customer {}) attempted to file claim for customer {} without permission", 
                        userId, userCustomerId, request.getCustomerId());
                return ResponseEntity.status(HttpStatus.FORBIDDEN).body(null);
            }
        }
        
        try {
            ClaimResponse response = claimService.fileClaim(request);
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        } catch (RuntimeException e) {
            log.error("Error filing claim: {}", e.getMessage());
            return ResponseEntity.badRequest().body(null);
        }
    }
    
    @PostMapping("/policy/{policyId}/inactive")
    public ResponseEntity<Void> handlePolicyInactiveClaims(
            @PathVariable Long policyId,
            @RequestParam String reason,
            @RequestHeader("X-User-Role") String role) {
        
        log.info("Handling claims for inactive policy {} by user with role {}", policyId, role);
        
        // Only ADMIN and AGENT can handle policy inactive claims
        if (!"ADMIN".equals(role) && !"AGENT".equals(role)) {
            log.warn("Unauthorized attempt to handle policy inactive claims by role: {}", role);
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }
        
        try {
            claimService.handlePolicyInactiveClaims(policyId, reason);
            return ResponseEntity.ok().build();
        } catch (Exception e) {
            log.error("Error handling claims for inactive policy {}: {}", policyId, e.getMessage());
            return ResponseEntity.badRequest().build();
        }
    }

    @GetMapping("/{claimId}")
    public ResponseEntity<ClaimResponse> getClaimById(@PathVariable Long claimId) {
        log.debug("Getting claim with ID: {}", claimId);
        
        try {
            ClaimResponse response = claimService.getClaimById(claimId);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            log.error("Error fetching claim {}: {}", claimId, e.getMessage());
            return ResponseEntity.notFound().build();
        }
    }
    
    @GetMapping
    public ResponseEntity<List<ClaimResponse>> getAllClaims(
            Pageable pageable,
            @RequestHeader("X-User-Role") String role) {
        
        log.debug("Getting all claims by user with role: {}", role);
        
        // Only ADMIN can view all claims
        if (!"ADMIN".equals(role)) {
            log.warn("Unauthorized access attempt to view all claims by role: {}", role);
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(null);
        }
        
        List<ClaimResponse> claims = claimService.getAllClaims(pageable);
        return ResponseEntity.ok(claims);
    }
    
    @GetMapping("/customer/{customerId}")
    public ResponseEntity<List<ClaimResponse>> getClaimsByCustomerId(
            @PathVariable Long customerId,
            @RequestHeader("X-User-Id") Long userId,
            @RequestHeader("X-User-Role") String role) {
        
        log.debug("Getting claims for customer {} by user {} with role {}", customerId, userId, role);
        
        // Users can only view their own claims
//        if (!"USER".equals(role)) {
//            log.warn("User {} attempted to view claims for customer {} without permission", userId, customerId);
//            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(null);
//        }
        
        List<ClaimResponse> claims = claimService.getClaimsByCustomerId(customerId, userId, role);
        return ResponseEntity.ok(claims);
    }
    
    @GetMapping("/policy/{policyId}")
    public ResponseEntity<List<ClaimResponse>> getClaimsByPolicyId (
            @PathVariable Long policyId,
            @RequestHeader(value="X-Customer-Id", required = false) String customerId,
            @RequestHeader("X-User-Role") String role) {
        
        log.debug("Getting claims for policy {} by user with role {}", policyId, role);
        
        // Only ADMIN and AGENT can view claims by policy
        if ("USER".equals(role) && claimService.hasExistingClaim(policyId, Long.valueOf(customerId))) {
            log.warn("User attempted to view another user claims by policy without permission");
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(null);
        }
        
        List<ClaimResponse> claims = claimService.getClaimsByPolicyId(policyId);
        return ResponseEntity.ok(claims);
    }
    
    @GetMapping("/agent/{agentId}")
    public ResponseEntity<List<ClaimResponse>> getClaimsByAgentId(
            @PathVariable Long agentId,
            @RequestHeader("X-User-Id") Long userId,
            @RequestHeader("X-User-Role") String role) {
        
        log.debug("Getting claims for agent {} by user {} with role {}", agentId, userId, role);
        
        // Agents can only view their own claims, admin can view any
//        if ("AGENT".equals(role) && !agentId.equals(userId)) {
//            log.warn("Agent {} attempted to view claims for agent {} without permission", userId, agentId);
//            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(null);
//        }
        if ("USER".equals(role)) {
            log.warn("User attempted to view agent claims without permission");
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(null);
        }
        
        List<ClaimResponse> claims = claimService.getClaimsByAgentId(agentId);
        return ResponseEntity.ok(claims);
    }
    
    @GetMapping("/status/{status}")
    public ResponseEntity<List<ClaimResponse>> getClaimsByStatus(
            @PathVariable ClaimStatus status,
            @RequestHeader("X-User-Role") String role) {
        
        log.debug("Getting claims with status {} by user with role {}", status, role);
        
        // Only ADMIN and AGENT can view claims by status
        if ("USER".equals(role)) {
            log.warn("User attempted to view claims by status without permission");
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(null);
        }
        
        List<ClaimResponse> claims = claimService.getClaimsByStatus(status);
        return ResponseEntity.ok(claims);
    }
    
    @PutMapping("/{claimId}/process")
    public ResponseEntity<ClaimResponse> processClaim(
            @PathVariable Long claimId,
            @Valid @RequestBody ClaimProcessRequest request,
            @RequestHeader("X-User-Id") Long userId,
            @RequestHeader("X-User-Role") String role) {
        
        log.info("Processing claim {} with status {} by user {} with role {}", claimId, request.getStatus(), userId, role);
        
        // Only ADMIN and AGENT can process claims
        if ("USER".equals(role)) {
            log.warn("User attempted to process claim without permission");
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(null);
        }
        
        try {
            ClaimResponse response = claimService.processClaim(claimId, request, userId);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            log.error("Error processing claim {}: {}", claimId, e.getMessage());
            return ResponseEntity.badRequest().body(null);
        }
    }
    
    @DeleteMapping("/{claimId}")
    public ResponseEntity<Void> deleteClaim(
            @PathVariable Long claimId,
            @RequestHeader("X-User-Role") String role) {
        
        log.info("Deleting claim {} by user with role {}", claimId, role);
        
        // Only ADMIN can delete claims
        if (!"ADMIN".equals(role)) {
            log.warn("Unauthorized delete attempt by role: {}", role);
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }
        
        try {
            claimService.deleteClaim(claimId);
            return ResponseEntity.noContent().build();
        } catch (RuntimeException e) {
            log.error("Error deleting claim {}: {}", claimId, e.getMessage());
            return ResponseEntity.notFound().build();
        }
    }
} 
 

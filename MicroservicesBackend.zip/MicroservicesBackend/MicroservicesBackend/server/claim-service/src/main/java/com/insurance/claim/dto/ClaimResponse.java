package com.insurance.claim.dto;

import com.insurance.claim.entity.ClaimStatus;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ClaimResponse {
    private Long claimId;
    private Long policyId;
    private Long customerId;
    private BigDecimal claimAmount;
    private String description;
    private ClaimStatus status;
    private Long agentId;
    private String rejectionReason;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
} 

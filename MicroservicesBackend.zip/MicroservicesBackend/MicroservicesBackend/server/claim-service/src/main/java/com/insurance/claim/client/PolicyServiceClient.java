package com.insurance.claim.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;

@FeignClient(name = "policy-service", path = "/api/policies")
public interface PolicyServiceClient {
    
    @GetMapping("/{policyId}")
    ResponseEntity<Object> getPolicyById(
            @PathVariable Long policyId,
            @RequestHeader("X-User-Id") String userId,
            @RequestHeader("X-User-Role") String role
    );
} 

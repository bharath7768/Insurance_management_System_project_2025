package com.insurance.claim.repository;

import com.insurance.claim.entity.Claim;
import com.insurance.claim.entity.ClaimStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ClaimRepository extends JpaRepository<Claim, Long> {
    List<Claim> findByCustomerId(Long customerId);
    List<Claim> findByPolicyId(Long policyId);
    List<Claim> findByAgentId(Long agentId);
    List<Claim> findByStatus(ClaimStatus status);
    List<Claim> findByPolicyIdAndStatusIn(Long policyId, List<ClaimStatus> statuses);
    boolean existsByCustomerIdAndPolicyId(Long customerId, Long policyId);
} 

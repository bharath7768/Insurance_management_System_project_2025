import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import './App.css';
import { UserProvider, useUser } from './context/UserContext.jsx';

// components/index.js
import {
  Login,
  Dashboard,
  UserDashboard,
  AgentDashboard,
  CustomerManagement,
  PolicyManagement,
  AgentManagement,
  ClaimProcessing,
  Navbar,
  Notifications,
  Profile,
} from './components';

function AppContent() {
  const { currentUser, logout, isLoading } = useUser();

  // show loading while checking authentication
  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  // not logged in user
  if (!currentUser) {
    return (
        <div className="min-h-screen bg-gray-50 flex flex-col">
          <div className="flex-1">
            <Routes>
              <Route path="/login" element={<Login />} />
              <Route path="*" element={<Navigate to="/login" replace />} />
            </Routes>
          </div>
          <Toaster position="top-right" />
        </div>
    );
  }

  // logged in user
  return (
      <div className="min-h-screen bg-gray-50 flex flex-col">
        <Navbar currentUser={currentUser} onLogout={logout} />
        <main className="flex-1 container mx-auto px-4 py-8">
          <Routes>
            {/* show the dashboard */}
            <Route path="/" element={
              currentUser.role === 'admin' ? <Dashboard /> :
              currentUser.role === 'agent' ? <AgentDashboard currentUser={currentUser} /> :
              <UserDashboard currentUser={currentUser} />
            } />
            
            {/* admin routes */}
            {currentUser.role === 'admin' && (
              <>
                <Route path="/dashboard" element={<Dashboard />} />
                <Route path="/customers" element={<CustomerManagement />} />
                <Route path="/agents" element={<AgentManagement />} />
              </>
            )}

            {/* admin + agent routes */}
            {(currentUser.role === 'admin' || currentUser.role === 'agent') && (
              <>
                <Route path="/policies" element={<PolicyManagement currentUser={currentUser} />} />
                <Route path="/claims" element={<ClaimProcessing currentUser={currentUser} />} />
              </>
            )}

            {/* dashboard routes */}
            {currentUser.role === 'user' && (
              <Route path="/user-dashboard" element={<UserDashboard currentUser={currentUser} />} />
            )}
            {currentUser.role === 'agent' && (
              <Route path="/agent-dashboard" element={<AgentDashboard currentUser={currentUser} />} />
            )}

            {/* shared routes */}
            <Route path="/notifications" element={<Notifications currentUser={currentUser} />} />
            <Route path="/profile" element={<Profile />} />

            {/* fallback routes redirects to login */}
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </main>
        <Toaster position="top-right" />
      </div>
  );
}

// app component
function App() {
  return (
    <UserProvider>
      <Router>
        <AppContent />
      </Router>
    </UserProvider>
  );
}

export default App;

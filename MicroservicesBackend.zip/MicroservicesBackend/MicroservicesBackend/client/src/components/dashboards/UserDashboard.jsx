import { useState, useEffect } from 'react';
import { FileText, Plus, Eye, IndianRupee, AlertTriangle, CheckCircle, Clock, Phone, Mail } from 'lucide-react';
import customerService from '../../services/customerService';
import ClaimFilingModal from '../shared/ClaimFilingModal';
import policyService from '../../services/policyService';
import claimService  from '../../services/claimService';
import toast from 'react-hot-toast';

const UserDashboard = ({ currentUser }) => {
  const [customer, setCustomer] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showClaimModal, setShowClaimModal] = useState(false);
  const [showPolicyModal, setShowPolicyModal] = useState(false);
  const [selectedPolicy, setSelectedPolicy] = useState(null);
  const [claimsList, setClaimsList] = useState([]);
  const [customerPolicies, setCustomerPolicies] = useState({});
  const [customerClaims, setCustomerClaims] = useState([]);
  const [agentInfo, setAgentInfo] = useState(null);

  console.log(currentUser)

  // Load customer profile on component mount
  useEffect(() => {
    loadCustomerProfile();
  }, []);

  const loadCustomerProfile = async () => {
    try {
      setLoading(true);
      const customerData = await customerService.getProfile();
      const customerPoliciesData = await policyService.getByCustomer(customerData.customerId);
      const customerClaimsData = await claimService.getByCustomer(customerData.customerId);
      console.log(customerPoliciesData)
      // Fetch agent information
      try {
        const agentData = await customerService.getMyAgent();
        setAgentInfo(agentData.message ? null : agentData); // Only set if agent exists
      } catch (error) {
        console.log('No agent assigned or error fetching agent:', error);
        setAgentInfo(null);
      }

      setCustomerPolicies(customerPoliciesData[0]);
      setCustomerClaims(customerClaimsData);
      setClaimsList(customerClaimsData); 
      setCustomer(customerData);
    } catch (error) {
      console.error('Error loading customer profile:', error);
      toast.error(error.message || 'Failed to load customer profile');
    } finally {
      setLoading(false);
    }
  };


  // Calculate statistics
  const pendingClaims = customerClaims.filter(claim => claim.status === 'UNDER_REVIEW').length;
  const totalClaim = customerClaims.filter(claim => claim.status === 'APPROVED').length;

  const handleViewPolicy = () => {
    setSelectedPolicy(customerPolicies);
    setShowPolicyModal(true);
  };

  const handleFileNewClaim = () => {
    setShowClaimModal(true);
  };

  const handleSubmitClaim = async (claimData) => {
    try {
      const newClaim = await claimService.create(claimData);
      setClaimsList(prevClaims => [...prevClaims, newClaim]);
      setShowClaimModal(false);
      toast.success('Claim filed successfully');
    } catch (error) {
      console.error('Error filing claim:', error);
      toast.error('Failed to file claim');
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'Filed': return 'bg-blue-100 text-blue-800';
      case 'Under Review': return 'bg-yellow-100 text-yellow-800';
      case 'Approved': return 'bg-green-100 text-green-800';
      case 'Rejected': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'Filed': return <FileText size={16} className="text-blue-500" />;
      case 'Under Review': return <Clock size={16} className="text-yellow-500" />;
      case 'Approved': return <CheckCircle size={16} className="text-green-500" />;
      case 'Rejected': return <AlertTriangle size={16} className="text-red-500" />;
      default: return <AlertTriangle size={16} className="text-gray-500" />;
    }
  };

   if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!customer) {
    return <div className="p-8 text-center">Customer not found</div>;
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg p-6 text-white">
        <h1 className="text-3xl font-bold">Welcome back, {customer.name}!</h1>
        <p className="text-blue-100 mt-2">Manage your insurance policies and claims</p>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center space-x-3">
            <FileText className="w-8 h-8 text-blue-500" />
            <div>
              <p className="text-sm font-medium text-gray-600">Active Policies</p>
             <p className="text-3xl font-bold text-blue-600">{customerPolicies.status==='ACTIVE' ? '1' : '0'}</p>
 
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center space-x-3">
            <IndianRupee className="w-8 h-8 text-green-500" />
            <div>
              <p className="text-sm font-medium text-gray-600">Total Premiums</p>
              <p className="text-3xl font-bold text-green-600">₹{customerPolicies?.premiumAmount?.toLocaleString()|| '0'}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center space-x-3">
            <Clock className="w-8 h-8 text-yellow-500" />
            <div>
              <p className="text-sm font-medium text-gray-600">Pending Claims</p>
              <p className="text-3xl font-bold text-yellow-600">{pendingClaims}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center space-x-3">
            <CheckCircle className="w-8 h-8 text-purple-500" />
            <div>
              <p className="text-sm font-medium text-gray-600">Claims Approved</p>
              <p className="text-3xl font-bold text-purple-600">{totalClaim}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* My Policies */}
        <div className="bg-white rounded-lg shadow-md">
          <div className="p-6 border-b border-gray-200">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold text-gray-900">My Policies</h2>
              <button
                onClick={handleFileNewClaim}
                className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center space-x-2 transition-colors text-sm"
              >
                <Plus size={16} />
                <span>File Claim</span>
              </button>
            </div>
          </div>
          <div className="p-6">
            {customerPolicies ? (
                <div className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 transition-colors">
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <h3 className="font-medium text-gray-900">{customerPolicies.name}</h3>
                      <p className="text-sm text-gray-600 mt-1">{customerPolicies.coverageDetails}</p>
                      <div className="flex items-center space-x-4 mt-2 text-sm text-gray-500">
                            <span>Premium: ₹{customerPolicies?.premiumAmount?.toLocaleString()|| '0'}</span>
                            <span>•</span>
                            <span>Valid: {customerPolicies.validityPeriod} Months</span>
                          </div>
                        {agentInfo && (
                          <p className="text-xs text-gray-500 mt-2">
                            Agent: {agentInfo.name} - {agentInfo.phone}
                          </p>
                        )}
                        </div>
                        <button
                          onClick={handleViewPolicy}
                          className="text-blue-600 hover:text-blue-900 ml-4"
                        >
                          <Eye size={18} />
                        </button>
                      </div>
                    </div>
            ) : (
              <p className="text-gray-500 text-center py-4">No policies found</p>
            )}
          </div>
        </div>

        {/* My Claims */}
        <div className="bg-white rounded-lg shadow-md">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-xl font-semibold text-gray-900">My Claims</h2>
          </div>
          <div className="p-6 h-64 overflow-y-auto scrollbar-hide md:scrollbar-default">
            {customerClaims.length > 0 ? (
              <div className="space-y-4">
                {customerClaims.map((claim) => {
                  // Assuming customerPolicies is available or will be added
                  const policy = { name: customerPolicies.name, policyID: customerPolicies.policyId };
                  return (
                    <div key={claim.claimId} className="border border-gray-200 rounded-lg p-4">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-2">
                            {getStatusIcon(claim.status)}
                            <h3 className="font-medium text-gray-900">Claim #{claim.claimId}</h3>
                            <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(claim.status)}`}>
                              {claim.status}
                            </span>
                          </div>
                          <p className="text-sm text-gray-600 mb-2">{claim.description}</p>
                          <div className="flex items-center space-x-4 text-sm text-gray-500">
                            <span>Amount: ₹{claim.claimAmount.toLocaleString()}</span>
                            <span>•</span>
                            <span>Filed: {claim.createdAt.split("T")[0]}</span>
                          </div>
                          {policy && (
                            <p className="text-xs text-gray-500 mt-1">Policy: {policy.name}</p>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <p className="text-gray-500 text-center py-4">No claims filed</p>
            )}
          </div>
        </div>
      </div>

      {/* Profile Information */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Profile Information</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h3 className="font-medium text-gray-900 mb-2">Contact Details</h3>
            <div className="space-y-2 text-sm">
              <div className="flex items-center space-x-2">
                <Mail size={16} className="text-gray-400" />
                <span>{customer.email}</span>
              </div>
              <div className="flex items-center space-x-2">
                <Phone size={16} className="text-gray-400" />
                <span>{customer.phone}</span>
              </div>
            </div>
          </div>
          <div>
            <h3 className="font-medium text-gray-900 mb-2">Address</h3>
            <p className="text-sm text-gray-600">{customer.address}</p>
          </div>
          {agentInfo && (
            <div>
              <h3 className="font-medium text-gray-900 mb-2">Assigned Agent</h3>
              <div className="space-y-2 text-sm">
                <div className="flex items-center space-x-2">
                  <span className="font-medium text-gray-700">Name:</span>
                  <span>{agentInfo.name}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Phone size={16} className="text-gray-400" />
                  <span>{agentInfo.phone}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Mail size={16} className="text-gray-400" />
                  <span>{agentInfo.email}</span>
                </div>
                {agentInfo.specialization && (
                  <div className="flex items-center space-x-2">
                    <span className="font-medium text-gray-700">Specialization:</span>
                    <span>{agentInfo.specialization}</span>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Modals */}
      {showClaimModal && (
        <ClaimFilingModal
          isOpen={showClaimModal}
          onClose={() => setShowClaimModal(false)}
          onSubmit={handleSubmitClaim}
          currentUser={currentUser}
        />
      )}

      {/* Policy Modal - Inline ViewModal functionality */}
      {showPolicyModal && selectedPolicy && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50 overflow-y-auto scrollbar-hide md:scrollbar-default">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-2xl mx-auto lg:max-h-[90vh] overflow-y-auto scrollbar-hide md:scrollbar-default">
            <div className="px-6 pt-6 pb-4 border-b border-gray-100 sticky top-0 bg-white rounded-t-2xl">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-semibold text-gray-900">📋 Policy Details</h3>
                <button
                  onClick={() => setShowPolicyModal(false)}
                  className="p-2 rounded-full text-gray-500 hover:bg-gray-100 hover:text-gray-700 transition-colors"
                  aria-label="Close"
                >
                  ×
                </button>
              </div>
            </div>
            <div className="px-6 py-6">
              <div className="space-y-6">
                <div className="p-4 rounded-lg border border-gray-300">
                  <h4 className="font-medium text-gray-900 mb-2">
                    <span className="mr-2">📄</span>
                    Policy Information
                  </h4>
                  <h3 className="text-xl font-bold text-gray-900 mb-2">{selectedPolicy.name}</h3>
                  <p className="text-sm text-gray-700 p-4 bg-gray-50 rounded-lg border border-gray-200 leading-relaxed">
                    {selectedPolicy.coverageDetails}
                  </p>
                </div>

                <div className="p-4 rounded-lg border border-gray-300">
                  <h4 className="font-medium text-gray-900 mb-2">
                    <span className="mr-2">💰</span>
                    Financial Details
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Annual Premium</label>
                      <div className="text-sm text-gray-900 font-medium">
                        <p className="text-2xl font-bold text-blue-600">₹{selectedPolicy.premiumAmount.toLocaleString()}</p>
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Policy ID</label>
                      <div className="text-sm text-gray-900 font-medium">
                        <p className="text-sm text-gray-900 font-semibold">#{selectedPolicy.policyId}</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="p-4 rounded-lg border border-gray-300">
                  <h4 className="font-medium text-gray-900 mb-2">
                    <span className="mr-2">📅</span>
                    Validity Period
                  </h4>
                  <p className="text-lg text-gray-900 font-medium">{selectedPolicy.validityPeriod}</p>
                </div>

                {agentInfo && (
                  <div className="p-4 rounded-lg border border-gray-300">
                    <h4 className="font-medium text-gray-900 mb-2">
                      <span className="mr-2">👨‍💼</span>
                      Agent Information
                    </h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Agent Name</label>
                        <div className="text-sm text-gray-900 font-medium">{agentInfo.name}</div>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                        <div className="text-sm text-gray-900 font-medium">{agentInfo.email}</div>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Phone</label>
                        <div className="text-sm text-gray-900 font-medium">{agentInfo.phone}</div>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Address</label>
                        <div className="text-sm text-gray-900 font-medium">{agentInfo.address}</div>
                      </div>
                      {agentInfo.specialization && (
                        <div className="col-span-2">
                          <label className="block text-sm font-medium text-gray-700 mb-1">Specialization</label>
                          <div className="text-sm text-gray-900 font-medium">{agentInfo.specialization}</div>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </div>
            <div className="px-6 py-4 border-t border-gray-100">
              <div className="flex justify-end">
                <button
                  onClick={() => setShowPolicyModal(false)}
                  className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200 transition-colors"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};




export default UserDashboard; 
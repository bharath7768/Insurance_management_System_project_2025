import { useState, useEffect } from 'react';
import { Users, FileText, ClipboardCheck, AlertTriangle, RefreshCw } from 'lucide-react';
import { customerService, policyService, claimService } from '../../services/index.js';
import toast from 'react-hot-toast';

const Dashboard = () => {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [data, setData] = useState({
    customers: [],
    policies: [],
    claims: []
  });

  const fetchData = async (showToast = false) => {
    try {
      if (showToast) setRefreshing(true);
      
      const [customersData, policiesData, claimsData] = await Promise.all([
        customerService.getAll(),
        policyService.getAll(),
        claimService.getAll()
      ]);

      setData({
        customers: customersData || [],
        policies: policiesData || [],
        claims: claimsData || []
      });

      if (showToast) {
        toast.success('Dashboard data refreshed');
      }
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
      toast.error('Failed to load dashboard data');
    } finally {
      setLoading(false);
      if (showToast) setRefreshing(false);
    }
  };



  // get name for the user for the claims
  const getClaimUser = (id) => {
    const customer = data.customers.find((customer) => customer.customerId === id);
    return customer.name;
  }


  useEffect(() => {
    fetchData();
  }, []);

  // Calculate statistics
  const totalCustomers = data.customers.length;
  const activePolicies = data.policies.filter(policy => policy.status === 'ACTIVE').length;
  const totalClaims = data.claims.length;
  const pendingClaims = data.claims.filter(claim => 
    claim.status === 'SUBMITTED' || claim.status === 'UNDER_REVIEW'
  ).length;

  const stats = [
    {
      title: 'Total Customers',
      value: totalCustomers,
      icon: Users,
      color: 'bg-blue-500',
      textColor: 'text-blue-600',
    },
    {
      title: 'Active Policies',
      value: activePolicies,
      icon: FileText,
      color: 'bg-green-500',
      textColor: 'text-green-600',
    },
    {
      title: 'Total Claims',
      value: totalClaims,
      icon: ClipboardCheck,
      color: 'bg-purple-500',
      textColor: 'text-purple-600',
    },
    {
      title: 'Pending Claims',
      value: pendingClaims,
      icon: AlertTriangle,
      color: 'bg-orange-500',
      textColor: 'text-orange-600',
    }
  ];

  const recentClaims = data.claims.slice(0, 5).map(claim => {
    const customer = data.customers.find(c => c.id === claim.customerId);
    const policy = data.policies.find(p => p.id === claim.policyId);
    return { 
      ...claim, 
      customerName: customer?.name || 'Unknown Customer', 
      policyName: policy?.name || `Policy #${claim.policyId}`
    };
  });

  const recentCustomers = data.customers.slice(0, 4);

  if (loading) {
    return (
      <div className="space-y-8">
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Admin Dashboard</h1>
          <p className="text-gray-600 mt-1">Welcome back! Here's what's happening with your insurance business today.</p>
        </div>
        <button
          onClick={() => fetchData(true)}
          disabled={refreshing}
          className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:bg-blue-400"
        >
          <RefreshCw className={`w-4 h-4 ${refreshing ? 'animate-spin' : ''}`} />
          <span>{refreshing ? 'Refreshing...' : 'Refresh'}</span>
        </button>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <div key={stat.title} className="bg-white rounded-xl shadow-sm p-6 hover:shadow-md transition-shadow">
              <div className="flex items-center space-x-5">
                <div className={`p-4 rounded-full ${stat.color}`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                  <p className={`text-3xl font-bold ${stat.textColor} mt-2`}>{stat.value}</p>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Recent Activity & Customer Data */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Claims */}
        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="mb-6">
            <h2 className="text-xl font-semibold text-gray-900">Recent Claims</h2>
          </div>
          <div className="space-y-4">
            {recentClaims.length > 0 ? recentClaims.map((claim) => (
              <div key={claim.claimId} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-1">
                    <p className="font-medium text-gray-900">{getClaimUser(claim.customerId)}</p>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      claim.status === 'APPROVED' ? 'bg-green-100 text-green-800' :
                      claim.status === 'REJECTED' ? 'bg-red-100 text-red-800' :
                      claim.status === 'UNDER_REVIEW' ? 'bg-orange-100 text-orange-800' :
                      'bg-blue-100 text-blue-800'
                    }`}>
                      {claim.status}
                    </span>
                  </div>
                  <p className="text-sm text-gray-600 mb-1">{claim.description}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-gray-900">₹{claim.claimAmount?.toLocaleString()}</span>
                    <span className="text-xs text-gray-500">{claim.dateSubmitted}</span>
                  </div>
                </div>
              </div>
            )) : (
              <div className="text-center py-8 text-gray-500">
                <ClipboardCheck className="mx-auto h-12 w-12 text-gray-300 mb-4" />
                <p>No recent claims</p>
              </div>
            )}
          </div>
        </div>

        {/* Recent Customers */}
        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="mb-6">
            <h2 className="text-xl font-semibold text-gray-900">Recent Customers</h2>
          </div>
          <div className="space-y-4">
            {recentCustomers.length > 0 ? recentCustomers.map((customer) => (
              <div key={customer.customerId} className="flex items-center p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center mr-4">
                  <span className="text-white font-semibold text-sm">
                    {customer.name?.split(' ').map(n => n[0]).join('') || 'U'}
                  </span>
                </div>
                <div className="flex-1">
                  <p className="font-medium text-gray-900">{customer.name}</p>
                  <p className="text-sm text-gray-600">{customer.email}</p>
                  <div className="flex items-center justify-between mt-1">
                    <span className="text-xs text-gray-500">Joined: {customer.createdAt.split("T")[0]}</span>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      customer.status === 'ACTIVE' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                    }`}>
                      {customer.status?.toUpperCase() || 'Active'}
                    </span>
                  </div>
                </div>
              </div>
            )) : (
              <div className="text-center py-8 text-gray-500">
                <Users className="mx-auto h-12 w-12 text-gray-300 mb-4" />
                <p>No recent customers</p>
              </div>
            )}
          </div>
        </div>
       </div>
    </div>
  );
};

export default Dashboard; 

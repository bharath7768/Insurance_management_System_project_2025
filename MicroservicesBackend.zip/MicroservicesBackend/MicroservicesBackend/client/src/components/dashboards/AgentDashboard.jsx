import { useState, useEffect } from 'react';
import { Users, FileText, IndianRupee, TrendingUp, Eye, Phone, Mail, Calendar, CheckCircle } from 'lucide-react';
import { toast } from 'react-hot-toast';
import agentService from '../../services/agentService';
import policyService from '../../services/policyService';
import customerService from '../../services/customerService';
import claimService from '../../services/claimService';

const AgentDashboard = ({ currentUser }) => {
  const [agent, setAgent] = useState(null);
  const [agentPolicies, setAgentPolicies] = useState([]);
  const [agentCustomers, setAgentCustomers] = useState([]);
  const [agentClaims, setAgentClaims] = useState([]);
  const [loading, setLoading] = useState(true);
  
  const [showCustomerModal, setShowCustomerModal] = useState(false);
  const [showPolicyModal, setShowPolicyModal] = useState(false);
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [selectedPolicy, setSelectedPolicy] = useState(null);

  useEffect(() => {
    loadAgentData();
  }, [currentUser]);

  const loadAgentData = async () => {
    try {
      setLoading(true);
      
      // Get current agent profile
      const agentData = await agentService.getProfile();
      setAgent(agentData);
      
      // Get policies for this agent
      const policies = await policyService.getByAgent(agentData.agentId || agentData.id);
      const agentPoliciesData = policies.filter(policy => 
        policy.agentId === agentData.agentId || policy.agentId === agentData.id
      );
      setAgentPolicies(agentPoliciesData);
      console.log('Agent Policies:', agentPoliciesData);
      
      // Get customers for these policies
      const customers = await customerService.getAll();
      const agentCustomersData = agentPoliciesData.map(policy => {
        const customer = customers.find(c => c.customerId === policy.customerId);
        return customer ? { ...customer, policy } : null;
      }).filter(Boolean);
      setAgentCustomers(agentCustomersData);
      
      // Get claims for these policies
      const claims = await claimService.getByPolicy(agentPoliciesData[0].policyId);
      const agentClaimsData = claims.filter(claim => 
        agentPoliciesData.some(policy => policy.policyId === claim.policyId)
      );
      setAgentClaims(agentClaimsData);
      
    } catch (error) {
      console.error('Error loading agent data:', error);
      toast.error('Failed to load agent dashboard data');
    } finally {
      setLoading(false);
    }
  };

  // Calculate statistics
  const totalPremiums = agentPolicies.reduce((sum, policy) => sum + (policy.premiumAmount || 0), 0);

  const handleViewCustomer = (customer) => {
    setSelectedCustomer(customer);
    setShowCustomerModal(true);
  };

  const handleViewPolicy = (policy) => {
    setSelectedPolicy(policy);
    setShowPolicyModal(true);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  // Add safety check for agent
  if (!agent) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <h2 className="text-xl font-semibold text-gray-900">Agent not found</h2>
          <p className="text-gray-600 mt-2">Unable to load agent dashboard</p>
          <button 
            onClick={loadAgentData}
            className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-green-600 to-teal-600 rounded-lg p-6 text-white">
        <h1 className="text-3xl font-bold">Welcome, {agent.name}!</h1>
        <p className="text-green-100 mt-2">Manage your clients and track your performance</p>
        <div className="mt-4 flex items-center space-x-6 text-sm">
          <span>📧 {agent.email}</span>
          <span>📞 {agent.phone?.replace(/^\+1/, '')}</span>
          <span>🏢 {agent.address}</span>
        </div>
      </div>

      {/* Agent Performance */}
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Agent Performance</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-4 bg-blue-50 rounded-lg">
            <div className="flex space-x-3">
              <CheckCircle className="h-8 w-8 text-blue-600" />
              <div>
                <p className="text-sm text-gray-600">Specialization</p>
                <p className="font-semibold text-gray-900">{agent.specialization}</p>
              </div>
            </div>
          </div>
          <div className="p-4 bg-green-50 rounded-lg">
            <div className="flex space-x-3">
              <Calendar className="h-8 w-8 text-green-600" />
              <div>
                <p className="text-sm text-gray-600">Commission Rate</p>
                <p className="font-semibold text-gray-900">{agent.commissionRate}%</p>
              </div>
            </div>
          </div>
          <div className="p-4 bg-purple-50 rounded-lg">
            <div className="flex space-x-8">
              <IndianRupee className="h-8 w-8 text-purple-600" />
              <div>
                <p className="text-sm text-gray-600">Total Premiums</p>
                <p className="font-semibold text-gray-900">₹{totalPremiums.toLocaleString()}</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Customers */}
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold text-gray-900">My Clients</h2>
          <span className="text-sm text-gray-500">{agentCustomers.length} total</span>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {agentCustomers.slice(0, 6).map((customer) => (
            <div key={customer.customerId} className="p-4 border border-gray-200 rounded-lg hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-semibold text-gray-900">{customer.name}</h3>
                <button
                  onClick={() => handleViewCustomer(customer)}
                  className="text-blue-600 hover:text-blue-900"
                >
                  <Eye size={16} />
                </button>
              </div>
              <div className="space-y-1 text-sm text-gray-600">
                <div className="flex items-center">
                  <Mail size={12} className="mr-2" />
                  <span>{customer.email}</span>
                </div>
                <div className="flex items-center">
                  <Phone size={12} className="mr-2" />
                  <span>{customer.phone?.replace(/^\+1/, '')}</span>
                </div>
                <div className="flex items-center">
                  <FileText size={12} className="mr-2" />
                  <span>{customer.policy?.type} Policy</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Recent Policies */}
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold text-gray-900">My Policies</h2>
          <span className="text-sm text-gray-500">{agentPolicies.length} total</span>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200 border border-gray-200 ">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Policy</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Customer</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Premium</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Action</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {agentPolicies.slice(0, 5).map((policy) => {
                const customer = agentCustomers.find(c => c.policy?.policyId === policy.policyId);
                return (
                  <tr key={policy.policyId}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div>
                        <div className="text-sm font-medium text-gray-900">{policy.name}</div>
                        <div className="text-sm text-gray-500">{policy.type}</div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {customer?.name || 'Unknown'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      ₹{policy.premiumAmount?.toLocaleString()}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                        policy.status === 'ACTIVE' ? 'bg-green-100 text-green-800' :
                        policy.status === 'PENDING' ? 'bg-yellow-100 text-yellow-800' :
                        'bg-red-100 text-red-800'
                      }`}>
                        {policy.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      <button
                        onClick={() => handleViewPolicy(policy)}
                        className="text-blue-600 hover:text-blue-900 cursor-pointer"
                      >
                        View
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Customer Modal */}
      {showCustomerModal && selectedCustomer && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50 overflow-y-auto scrollbar-hide md:scrollbar-default">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-2xl lg:max-h-[90vh] overflow-y-auto scrollbar-hide md:scrollbar-default">
            <div className="px-6 pt-6 pb-4 border-b border-gray-100 sticky top-0 bg-white rounded-t-2xl">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-semibold text-gray-900">👤 Customer Details</h3>
                <button
                onClick={() => setShowCustomerModal(false)}
                className="w-8 h-8 rounded-full bg-blue-500 text-white hover:bg-blue-600 transition-colors cursor-pointer"
                >
                ×
              </button>
              </div>
            </div>
            <div className="px-6 py-6">
              <div className="space-y-6">
                {/* Basic Information */}
                <div className="p-4 rounded-lg border border-gray-300">
                  <h4 className="font-medium text-gray-900 mb-4">
                    👤 Basic Information
                  </h4>
                  <div className="grid grid-cols-1 gap-4">
                    <div className="bg-gray-50 p-3 rounded">
                      <label className="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
                      <p className="text-lg font-semibold text-gray-900">{selectedCustomer.name}</p>
                    </div>
                  </div>
                </div>

                {/* Contact Information */}
                <div className="p-4 rounded-lg border border-gray-300">
                  <h4 className="font-medium text-gray-900 mb-4">
                    📞 Contact Information
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="bg-gray-50 p-3 rounded">
                      <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                      <p className="text-sm text-gray-900">{selectedCustomer.email}</p>
                    </div>
                    <div className="bg-gray-50 p-3 rounded">
                      <label className="block text-sm font-medium text-gray-700 mb-1">Phone</label>
                      <p className="text-sm text-gray-900">{selectedCustomer.phone?.replace(/^\+1/, '')}</p>
                    </div>
                  </div>
                  <div className="mt-4 bg-gray-50 p-3 rounded">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Address</label>
                    <p className="text-sm text-gray-900">{selectedCustomer.address}</p>
                  </div>
                </div>

                {/* Policy Information */}
                {selectedCustomer.policy && (
                  <div className="p-4 rounded-lg border border-gray-300">
                    <h4 className="font-medium text-gray-900 mb-4">
                      📋 Policy Information
                    </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="bg-gray-50 p-3 rounded">
                      <label className="block text-sm font-medium text-gray-700 mb-1">Policy Name</label>
                      <p className="text-lg font-semibold text-gray-900">{selectedCustomer.name}</p>
                    </div>
                    <div className="bg-gray-50 p-3 rounded">
                      <label className="block text-sm font-medium text-gray-700 mb-1">Premium</label>
                      <p className="text-2xl font-bold text-green-600">₹{selectedCustomer.policy.premiumAmount?.toLocaleString()}</p>
                    </div>
                  </div>
                  </div>
                )}
              </div>
            </div>
            <div className="px-6 py-4 border-t border-gray-100">
              <div className="flex justify-end">
                <button
                  onClick={() => setShowCustomerModal(false)}
                  className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200 transition-colors"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Policy Modal */}
      {showPolicyModal && selectedPolicy && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50 overflow-y-auto scrollbar-hide md:scrollbar-default">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-2xl lg:max-h-[90vh] overflow-y-auto scrollbar-hide md:scrollbar-default">
            <div className="px-6 pt-6 pb-4 border-b border-gray-100 sticky top-0 bg-white rounded-t-2xl">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-semibold text-gray-900">📋 Policy Details</h3>
                <button
                onClick={() => setShowPolicyModal(false)}
                className="w-8 h-8 rounded-full bg-blue-500 text-white hover:bg-blue-600 transition-colors cursor-pointer"
                >
                ×
              </button>
              </div>
            </div>
            <div className="px-6 py-6">
              <div className="space-y-6">
                {/* Policy Information */}
                <div className="p-4 rounded-lg border border-gray-300">
                  <h4 className="font-medium text-gray-900 mb-4">
                    📄 Policy Information
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="bg-gray-50 p-3 rounded">
                      <label className="block text-sm font-medium text-gray-700 mb-1">Policy Name</label>
                      <p className="text-lg font-semibold text-gray-900">{selectedPolicy.name}</p>
                    </div>
                    <div className="bg-gray-50 p-3 rounded">
                      <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
                      <span className={`inline-flex px-3 py-1 text-sm font-semibold rounded-full ${
                        selectedPolicy.status === 'ACTIVE' ? 'bg-green-100 text-green-800' :
                        selectedPolicy.status === 'PENDING' ? 'bg-yellow-100 text-yellow-800' :
                         'bg-red-100 text-red-800'
                      }`}>
                        {selectedPolicy.status}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Financial Details */}
                <div className="p-4 rounded-lg border border-gray-300">
                  <h4 className="font-medium text-gray-900 mb-4">
                    💰 Financial Details
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="bg-gray-50 p-3 rounded">
                      <label className="block text-sm font-medium text-gray-700 mb-1">Premium</label>
                      <p className="text-2xl font-bold text-green-600">₹{selectedPolicy.premiumAmount?.toLocaleString()}</p>
                    </div>
                    <div className="bg-gray-50 p-3 rounded">
                      <label className="block text-sm font-medium text-gray-700 mb-1">Coverage Amount</label>
                      <p className="text-xl font-bold text-blue-600">₹{selectedPolicy.coverageAmount?.toLocaleString()}</p>
                    </div>
                  </div>
                </div>

                {/* Coverage Details */}
                <div className="p-4 rounded-lg border border-gray-300">
                  <h4 className="font-medium text-gray-900 mb-4">
                    🛡️ Coverage Details
                  </h4>
                  <div className="bg-gray-50 p-3 rounded">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Coverage Details</label>
                    <p className="text-sm text-gray-900 leading-relaxed">{selectedPolicy.coverageDetails}</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="px-6 py-4 border-t border-gray-100">
              <div className="flex justify-end">
                <button
                  onClick={() => setShowPolicyModal(false)}
                  className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200 transition-colors"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AgentDashboard; 
// Auth Components
export { default as Login } from './auth/Login';

// Dashboard Components
export { default as Dashboard } from './dashboards/Dashboard';
export { default as UserDashboard } from './dashboards/UserDashboard';
export { default as AgentDashboard } from './dashboards/AgentDashboard';

// Management Components
export { default as CustomerManagement } from './management/CustomerManagement';
export { default as PolicyManagement } from './management/PolicyManagement';
export { default as AgentManagement } from './management/AgentManagement';
export { default as ClaimProcessing } from './management/ClaimProcessing';

// Shared Components
export { default as Navbar } from './shared/Navbar';
export { default as PasswordInput } from './shared/PasswordInput';
export { default as Notifications } from './shared/Notifications';

// Pages
export { default as Profile } from './pages/Profile'; 
import { useState } from "react";
import PasswordInput from "../shared/PasswordInput.jsx";
import toast from "react-hot-toast";
import { Link } from "react-router-dom";
import { useUser } from "../../context/UserContext";
import { authService } from "../../services/index.js";

const Login = () => {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [isLoading, setIsLoading] = useState(false);
    const { login } = useUser();

    const handleLogin = async (e) => {
        e.preventDefault();

        if (!email || !password) {
            toast.error("Please enter email and password");
            return;
        }

        setIsLoading(true);

        try {
            // Use authService to login and get profile
            const { user } = await authService.loginWithProfile({
                email,
                password
            });

            // Update context with user data
            login(user);
            console.log(user);
            toast.success(`Welcome back, ${user.name}!`);

        } catch (error) {
            console.error('Login error:', error);
            toast.error(error.message || "Invalid email or password");
        } finally {
            setIsLoading(false);
        }
    }

    return (
        <div className="flex items-center justify-center min-h-screen bg-gray-50">
            <div className="flex w-full max-w-2xl mx-auto bg-white rounded-lg shadow-lg overflow-hidden">
                
                {/* Left Side - Blue with Insurance MS */}
                <div className="w-1/2 bg-blue-600 flex items-center justify-center p-6">
                    <div className="text-center text-white">
                        <h1 className="text-2xl font-bold mb-2">Insurance MS</h1>
                        <p className="text-blue-100 text-sm">Your trusted partner</p>
                    </div>
                </div>

                {/* Right Side - Login Form */}
                <div className="w-1/2 p-6">
                <div className="text-center">
                   <p className="font-bold text-blue-700">Login</p>
                   <p className="text-gray-500">Welcome back!</p>
                </div>
                
                    <div className="w-full">
                        {/* Login Form */}
                        <div className="space-y-4">
                            <form onSubmit={handleLogin} className="space-y-4">
                                <div>
                                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                                        Username
                                    </label>
                                    <input
                                        type="text"
                                        id="email"
                                        value={email}
                                        onChange={(e) => setEmail(e.target.value)}
                                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors text-sm"
                                        placeholder="Enter your username"
                                        required
                                        disabled={isLoading}
                                    />
                                </div>

                                <div>
                                    <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1">
                                        Password
                                    </label>
                                    <PasswordInput
                                        id="password"
                                        value={password}
                                        onChange={(e) => setPassword(e.target.value)}
                                        placeholder="Enter your password"
                                        required
                                        disabled={isLoading}
                                    />
                                </div>

                                <button
                                    type="submit"
                                    disabled={isLoading}
                                    className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors font-medium text-sm disabled:bg-blue-400 disabled:cursor-not-allowed"
                                >
                                    {isLoading ? "Signing In..." : "Sign In"}
                                </button>
                            </form>

                            {/* Demo Credentials */}
                            <div className="mt-4 p-3 bg-gray-50 rounded-lg">
                                <h3 className="text-xs font-medium text-gray-700 mb-2">Demo Credentials:</h3>
                                <div className="text-xs text-gray-600 space-y-1">
                                    <p><strong>Admin:</strong> admin / admin123</p>
                                    <p><strong>Agent:</strong> anup / anup123</p>
                                    <p><strong>Customer:</strong> chetan / chetan1234</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Login;
import { useState, useEffect } from 'react';
import { Search, Plus, Edit2, Eye, FileText, Calendar, DollarSign, User, Shield, UserCheck, Loader2, Ban, XCircle } from 'lucide-react';
import { toast } from 'react-hot-toast';
import policyService from '../../services/policyService';
import customerService from '../../services/customerService';
import agentService from '../../services/agentService';

const PolicyManagement = ({ currentUser }) => {
  const [policyList, setPolicyList] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [agents, setAgents] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [modalMode, setModalMode] = useState('add');
  const [selectedPolicy, setSelectedPolicy] = useState(null);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [policyToDelete, setPolicyToDelete] = useState(null);
  const [inactiveReason, setInactiveReason] = useState('');
  const [loading, setLoading] = useState(true);
  const [submitLoading, setSubmitLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    premiumAmount: '',
    coverageAmount: '',
    coverageDetails: '',
    validityPeriod: '',
    customerId: '',
    agentId: '',
    startDate: ''
  });

  // Load initial data
  useEffect(() => {
    loadInitialData();
  }, [currentUser]);

  const loadInitialData = async () => {
    try {
      setLoading(true);
      await Promise.all([
        loadPolicies(),
        loadCustomers(), 
        loadAgents()
      ]);
    } catch (error) {
      console.error('Error loading initial data:', error);
      toast.error('Failed to load data');
    } finally {
      setLoading(false);
    }
  };

  const loadPolicies = async () => {
    try {
      let policies = [];
      if (currentUser?.role === 'admin') {
        policies = await policyService.getAll();
      } else if (currentUser?.role === 'agent') {
        policies = await policyService.getByAgent(currentUser.id);
      } else if (currentUser?.role === 'user') {
        policies = await policyService.getByCustomer(currentUser.id);
      }
      setPolicyList(policies || []);
    } catch (error) {
      console.error('Error loading policies:', error);
      toast.error('Failed to load policies');
    }
  };

  const loadCustomers = async () => {
    try {
      if (currentUser?.role === 'admin' || currentUser?.role === 'agent') {
        const customersData = await customerService.getAll();
        setCustomers(customersData || []);
      }
    } catch (error) {
      console.error('Error loading customers:', error);
      toast.error('Failed to load customers');
    }
  };

  const loadAgents = async () => {
    try {
      if (currentUser?.role === 'admin') {
        const agentsData = await agentService.getAll();
        setAgents(agentsData || []);
      }
    } catch (error) {
      console.error('Error loading agents:', error);
      toast.error('Failed to load agents');
    }
  };

  // Get policies visible to the current user based on role
  const getVisiblePolicies = () => {
    if (currentUser?.role === 'user') {
      // Customer should not access policy management at all (handled in routing)
      return [];
    } else if (currentUser?.role === 'agent') {
      // Agent can see their assigned policies (already filtered by API)
      return policyList;
    } else if (currentUser?.role === 'admin') {
      // Admin can see all policies
      return policyList;
    }
    return [];
  };

  const filteredPolicies = getVisiblePolicies().filter(policy =>
    policy.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    policy.coverageDetails?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Check if current user can add/edit/delete policies
  const canAddPolicy = () => {
    return currentUser?.role === 'admin';
  };

  const canEditPolicy = () => {
    return currentUser?.role === 'admin';
  };

  const canDeletePolicy = () => {
    return currentUser?.role === 'admin';
  };

  const getCustomerName = (customerId) => {
    const customer = customers.find(c => c.id === customerId || c.customerId === customerId);
    return customer ? customer.customerName || customer.name : 'Unknown Customer';
  };

  const getAgentName = (agentId) => {
    const agent = agents.find(a => a.id === agentId || a.agentId === agentId);
    return agent ? agent.agentName || agent.name : 'Unknown Agent';
  };

  const handleAddPolicy = () => {
    if (!canAddPolicy()) return; // Prevent unauthorized access
    
    setModalMode('add');
    setFormData({
      name: '',
      premiumAmount: '',
      coverageAmount: '',
      coverageDetails: '',
      validityPeriod: '',
      customerId: '',
      agentId: '',
      startDate: ''
    });
    setShowModal(true);
  };

  const handleEditPolicy = (policy) => {
    if (!canEditPolicy()) return; // Prevent unauthorized access
    
    setModalMode('edit');
    setSelectedPolicy(policy);
    setFormData({
      name: policy.name || '',
      premiumAmount: policy.premiumAmount || '',
      coverageAmount: policy.coverageAmount || '',
      coverageDetails: policy.coverageDetails || '',
      validityPeriod: policy.validityPeriod || '',
      customerId: policy.customerId || '',
      agentId: policy.agentId || '',
      startDate: policy.startDate || ''
    });
    setShowModal(true);
  };

  const handleViewPolicy = (policy) => {
    setModalMode('view');
    setSelectedPolicy(policy);
    setShowModal(true);
  };

  const handleDeletePolicy = (policyId) => {
    if (!canDeletePolicy()) return; // Prevent unauthorized access
    
    const policy = policyList.find(p => p.policyId === policyId);
    setPolicyToDelete(policy);
    setInactiveReason('');
    setShowDeleteModal(true);
  };

  const confirmDeletePolicy = async () => {
    if (!policyToDelete) return;
    
    if (!inactiveReason.trim()) {
      toast.error('Please provide a reason for marking the policy as inactive');
      return;
    }
    
    try {
      await policyService.markInactive(policyToDelete.policyId, inactiveReason.trim());
      toast.success('Policy marked as inactive successfully');
      await loadPolicies(); // Reload policies
      setPolicyToDelete(null);
      setInactiveReason('');
      setShowDeleteModal(false);
    } catch (error) {
      console.error('Error marking policy inactive:', error);
      toast.error(error.message || 'Failed to mark policy as inactive');
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Prevent unauthorized modifications
    if (modalMode === 'add' && !canAddPolicy()) return;
    if (modalMode === 'edit' && !canEditPolicy()) return;
    
    try {
      setSubmitLoading(true);
      
      if (modalMode === 'add') {
        await policyService.create({
          ...formData,
          premiumAmount: parseFloat(formData.premiumAmount),
          coverageAmount: parseFloat(formData.coverageAmount),
          validityPeriod: parseInt(formData.validityPeriod),
          customerId: parseInt(formData.customerId),
          agentId: formData.agentId ? parseInt(formData.agentId) : null
        });
        toast.success('Policy created successfully');
      } else if (modalMode === 'edit') {
        await policyService.update(selectedPolicy.policyId, {
          ...formData,
          premiumAmount: parseFloat(formData.premiumAmount),
          coverageAmount: parseFloat(formData.coverageAmount),
          validityPeriod: parseInt(formData.validityPeriod),
          customerId: parseInt(formData.customerId),
          agentId: formData.agentId ? parseInt(formData.agentId) : null
        });
        toast.success('Policy updated successfully');
      }
      
      await loadPolicies(); // Reload policies
      setShowModal(false);
    } catch (error) {
      console.error('Error saving policy:', error);
      toast.error(error.message || 'Failed to save policy');
    } finally {
      setSubmitLoading(false);
    }
  };



  const getStatusColor = (status) => {
    switch (status?.toUpperCase()) {
      case 'ACTIVE': return 'bg-green-100 text-green-800';
      case 'INACTIVE': return 'bg-red-100 text-red-800';
      case 'EXPIRED': return 'bg-red-100 text-red-800';
      case 'CANCELLED': return 'bg-gray-100 text-gray-800';
      default: return 'bg-blue-100 text-blue-800';
    }
  };

  // Loading state
  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-center py-12">
          <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
          <span className="ml-2 text-gray-600">Loading policies...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <h1 className="text-2xl font-bold text-gray-900">Policy Management</h1>
            {currentUser?.role === 'agent' && (
              <div className="flex items-center gap-1 px-2 py-1 bg-purple-100 rounded-full">
                <UserCheck className="w-4 h-4 text-purple-600" />
                <span className="text-xs font-medium text-purple-700">Agent View</span>
              </div>
            )}
          </div>
          <p className="text-gray-600">
            {currentUser?.role === 'agent' 
              ? `Viewing your assigned policies (${getVisiblePolicies().length} assigned)`
              : 'Manage insurance policies and coverage details'
            }
          </p>
        </div>
        {canAddPolicy() && (
          <button
            onClick={handleAddPolicy}
            className="flex items-center space-x-2 bg-blue-600 text-white px-3 py-2 rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium cursor-pointer"
          >
            <Plus size={16} />
            <span>Add Policy</span>
          </button>
        )}
      </div>

      {/* Search and Filters */}
      <div className="bg-white p-6 rounded-xl shadow-sm">
        <div className="flex items-center space-x-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
            <input
              type="text"
              placeholder={currentUser?.role === 'agent' 
                ? "Search your assigned policies by name or coverage details..."
                : "Search policies by name or coverage details..."
              }
              className="w-full pl-10 pr-4 py-2 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none bg-gray-50"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
      </div>

      {/* Policy Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredPolicies.map((policy) => (
          <div key={policy.policyId} className="bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow p-6">
            {/* Header */}
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1 min-w-0">
                <h3 className="text-lg font-semibold text-gray-900 mb-2 truncate">{policy.name}</h3>
                <div className="flex items-center gap-2 mb-2">
                  <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(policy.status)}`}>
                    {policy.status}
                  </span>
                  <span className="inline-flex px-2 py-1 text-xs font-medium rounded-full bg-blue-100 text-blue-800">
                    {policy.validityPeriod} months
                  </span>
                </div>
                <p className="text-sm text-gray-500">Policy #{policy.policyId}</p>
              </div>
            </div>

            {/* Financial Info */}
            <div className="space-y-3 mb-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center text-sm text-gray-600">
                  <DollarSign size={14} className="mr-2 text-green-600" />
                  <span>Premium Amount</span>
                </div>
                <span className="font-semibold text-green-600">₹{policy.premiumAmount?.toLocaleString()}</span>
              </div>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center text-sm text-gray-600">
                  <Shield size={14} className="mr-2 text-blue-600" />
                  <span>Coverage Amount</span>
                </div>
                <span className="font-semibold text-blue-600">₹{policy.coverageAmount?.toLocaleString()}</span>
              </div>
            </div>

            {/* Policy Details */}
            <div className="space-y-3 mb-4 p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center text-sm text-gray-700">
                <User size={14} className="mr-2 text-purple-600" />
                <span className="font-medium">Customer:</span>
                <span className="ml-1 truncate">{getCustomerName(policy.customerId)}</span>
                {currentUser?.role === 'agent' && (
                  <span className="ml-1 text-xs text-purple-600 font-medium">(Your client)</span>
                )}
              </div>

              <div className="flex items-center text-sm text-gray-700">
                <Calendar size={14} className="mr-2 text-orange-600" />
                <span className="font-medium">Period:</span>
                <span className="ml-1 truncate">{policy.startDate} to {policy.endDate}</span>
              </div>
            </div>

            {/* Footer */}
            <div className="flex items-center justify-between pt-4 border-t border-gray-100">
              <div className="text-xs text-gray-500 truncate flex-1 mr-2">
                <span className="font-medium">Agent:</span> {getAgentName(policy.agentId)}
              </div>
              <div className="flex space-x-2">
                <button
                  onClick={() => handleViewPolicy(policy)}
                  className="text-blue-600 hover:text-blue-900 p-1 rounded hover:bg-blue-50 cursor-pointer"
                  title="View Details"
                >
                  <Eye size={16} />
                </button>
                {canEditPolicy() && (
                  <button
                    onClick={() => handleEditPolicy(policy)}
                    className="text-indigo-600 hover:text-indigo-900 p-1 rounded hover:bg-indigo-50 cursor-pointer"
                    title="Edit Policy"
                  >
                    <Edit2 size={16} />
                  </button>
                )}
                {policy.status === 'ACTIVE' && canDeletePolicy() && (
                  <button
                    onClick={() => handleDeletePolicy(policy.policyId)}
                    className="text-orange-600 hover:text-orange-900 p-1 rounded hover:bg-orange-50 cursor-pointer"
                    title="Mark Inactive"
                  >
                    <XCircle size={16} />
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredPolicies.length === 0 && (
        <div className="text-center py-12">
          <FileText className="mx-auto h-12 w-12 text-gray-400" />
          <h3 className="mt-2 text-sm font-medium text-gray-900">No policies found</h3>
          <p className="mt-1 text-sm text-gray-500">
            {searchTerm ? 'Try adjusting your search criteria.' : 
             currentUser?.role === 'agent' ? 'You have no assigned policies. Contact your administrator for policy assignments.' :
             'Get started by adding a new policy.'
            }
          </p>
          {currentUser?.role === 'agent' && getVisiblePolicies().length === 0 && (
            <p className="mt-2 text-xs text-gray-400">
              As an agent, you can only view policies assigned to you.
            </p>
          )}
        </div>
      )}

      {/* View Policy Details - Simple inline modal */}
      {showModal && modalMode === 'view' && selectedPolicy && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50 overflow-y-auto scrollbar-hide md:scrollbar-default">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-4xl mx-auto lg:max-h-[90vh] overflow-y-auto scrollbar-hide md:scrollbar-default">
            
            {/* Header */}
            <div className="flex items-center justify-between p-6">
              <h3 className="text-xl font-semibold text-gray-900">📋 Policy Details</h3>
              <button
                onClick={() => setShowModal(false)}
                className="w-8 h-8 rounded-full bg-blue-500 text-white hover:bg-blue-600 transition-colors cursor-pointer"
              >
                ×
              </button>
            </div>

            {/* Content */}
            <div className="p-6 space-y-6">
              
              {/* Basic Information */}
              <div className="p-4 rounded-lg border border-gray-300">
                <h4 className="font-medium text-gray-900 mb-2">
                  📄 Basic Information
                </h4>
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-gray-50 p-3 rounded">
                    <label className="text-sm font-medium text-gray-700">Policy Name</label>
                    <p className="text-sm text-gray-900 font-medium">{selectedPolicy.name}</p>
                  </div>
                  <div className="inline-block bg-gray-50 p-3 rounded">
                    <div className="inline-flex flex-col gap-1.5">
                    <label className="text-sm font-medium text-gray-700">Status</label>
                    <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(selectedPolicy.status)}`}>
                      {selectedPolicy.status}
                    </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Financial Details */}
              <div className="p-4 rounded-lg border border-gray-300">
                <h4 className="font-medium text-gray-900 mb-2">
                  💰 Financial Details
                </h4>
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-gray-50 p-3 rounded">
                    <label className="text-sm font-medium text-gray-700">Premium Amount</label>
                    <p className="text-lg font-bold text-blue-600">₹{selectedPolicy.premiumAmount?.toLocaleString()}</p>
                  </div>
                  <div className="bg-gray-50 p-3 rounded">
                    <label className="text-sm font-medium text-gray-700">Coverage Amount</label>
                    <p className="text-lg font-bold text-blue-600">₹{selectedPolicy.coverageAmount?.toLocaleString()}</p>
                  </div>
                </div>
              </div>

              {/* Coverage Information */}
              <div className="p-4 rounded-lg border border-gray-300">
                <h4 className="font-medium text-gray-900 mb-2">
                  🛡️ Coverage Information
                </h4>
                <div className="bg-gray-50 p-3 rounded">
                  <label className="text-sm font-medium text-gray-700">Coverage Details</label>
                  <p className="text-sm text-gray-900 mt-1">{selectedPolicy.coverageDetails}</p>
                </div>
              </div>

              {/* Assignment & Timeline */}
              <div className="p-4 rounded-lg border border-gray-300">
                <h4 className="font-medium text-gray-900 mb-2">
                  👥 Assignment & Timeline
                </h4>
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-gray-50 p-3 rounded">
                    <label className="text-sm font-medium text-gray-700">Policy Holder</label>
                    <p className="text-sm text-gray-900 font-medium">{getCustomerName(selectedPolicy.customerId)}</p>
                  </div>
                  <div className="bg-gray-50 p-3 rounded">
                    <label className="text-sm font-medium text-gray-700">Managing Agent</label>
                    <p className="text-sm text-gray-900 font-medium">{getAgentName(selectedPolicy.agentId)}</p>
                  </div>
                  <div className="bg-gray-50 p-3 rounded">
                    <label className="text-sm font-medium text-gray-700">Validity Period</label>
                    <p className="text-sm text-gray-900 font-medium">{selectedPolicy.validityPeriod} months</p>
                  </div>
                  <div className="bg-gray-50 p-3 rounded">
                    <label className="text-sm font-medium text-gray-700">Policy Period</label>
                    <p className="text-sm text-gray-900 font-medium">{selectedPolicy.startDate} to {selectedPolicy.endDate}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Add/Edit Policy Form - Simple inline modal */}
      {showModal && (modalMode === 'add' || modalMode === 'edit') && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50 overflow-y-auto scrollbar-hide md:scrollbar-default">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-4xl mx-auto lg:max-h-[90vh] overflow-y-auto scrollbar-hide md:scrollbar-default">
            
            {/* Header */}
            <div className="flex items-center justify-between p-6">
              <h3 className="text-xl font-semibold text-gray-900">
                {modalMode === 'add' ? '✨ Add New Policy' : '✏️ Edit Policy'}
              </h3>
              <button
                onClick={() => setShowModal(false)}
                className="w-8 h-8 rounded-full bg-blue-500 text-white hover:bg-blue-600 transition-colors cursor-pointer"
              >
                ×
              </button>
            </div>

            {/* Form */}
            <form onSubmit={handleSubmit} className="space-y-4 p-6">
              
              {/* Basic Information */}
              <div className="p-4 rounded-lg border border-gray-300">
                <h4 className="font-medium text-gray-900 mb-2">
                  📄 Basic Information
                </h4>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Policy Name <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="Enter policy name"
                      required
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Validity Period (Months) <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="number"
                      value={formData.validityPeriod}
                      onChange={(e) => setFormData({ ...formData, validityPeriod: e.target.value })}
                      placeholder="e.g. 12"
                      min="1"
                      required
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                </div>
              </div>

              {/* Financial Details */}
              <div className="p-4 rounded-lg border border-gray-300">
                <h4 className="font-medium text-gray-900 mb-2">
                  💰 Financial Details
                </h4>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Premium Amount (₹) <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="number"
                      value={formData.premiumAmount}
                      onChange={(e) => setFormData({ ...formData, premiumAmount: e.target.value })}
                      placeholder="e.g. 25000"
                      min="0"
                      step="0.01"
                      required
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Coverage Amount (₹) <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="number"
                      value={formData.coverageAmount}
                      onChange={(e) => setFormData({ ...formData, coverageAmount: e.target.value })}
                      placeholder="e.g. 1000000"
                      min="0"
                      step="0.01"
                      required
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                </div>
              </div>

              {/* Coverage Information */}
              <div className="p-4 rounded-lg border border-gray-300">
                <h4 className="font-medium text-gray-900 mb-2">
                  🛡️ Coverage Information
                </h4>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Coverage Details <span className="text-red-500">*</span>
                  </label>
                  <textarea
                    value={formData.coverageDetails}
                    onChange={(e) => setFormData({ ...formData, coverageDetails: e.target.value })}
                    placeholder="Describe what this policy covers, benefits, and key features..."
                    rows={4}
                    required
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                  />
                </div>
              </div>

              {/* Assignment & Timeline */}
              {modalMode === 'add' && <div className="p-4 rounded-lg border border-gray-300">
                <h4 className="font-medium text-gray-900 mb-2">
                  👥 Assignment & Timeline
                </h4>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Policy Holder <span className="text-red-500">*</span>
                    </label>
                    <select
                      value={formData.customerId}
                      onChange={(e) => setFormData({ ...formData, customerId: e.target.value })}
                      required
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    >
                      <option value="">Choose customer</option>
                      {customers.map(customer => (
                        <option key={customer.id || customer.customerId} value={customer.id || customer.customerId}>
                          {customer.customerName || customer.name}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Managing Agent
                    </label>
                    <select
                      value={formData.agentId}
                      onChange={(e) => setFormData({ ...formData, agentId: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    >
                      <option value="">Choose agent (optional)</option>
                      {agents.map(agent => (
                        <option key={agent.id || agent.agentId} value={agent.id || agent.agentId}>
                          {agent.agentName || agent.name}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Start Date <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="date"
                      value={formData.startDate}
                      onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
                      required
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                </div>
              </div>}

              {/* Footer */}
              <div className="flex justify-end space-x-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200 cursor-pointer"
                  disabled={submitLoading}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed flex items-center"
                  disabled={submitLoading}
                >
                  {submitLoading && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                  {modalMode === 'add' ? 'Create Policy' : 'Update Policy'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      
      {/* Mark Inactive Confirmation Modal */}
      {showDeleteModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-md mx-auto">
            {/* Header */}
            <div className="flex items-center justify-between p-6 border-b border-gray-200">
              <h3 className="text-lg font-semibold text-gray-900">Mark Policy Inactive</h3>
              <button
                onClick={() => {
                  setShowDeleteModal(false);
                  setPolicyToDelete(null);
                  setInactiveReason('');
                }}
                className="w-6 h-6 rounded-full bg-gray-100 text-gray-500 hover:bg-gray-200 transition-colors cursor-pointer flex items-center justify-center"
              >
                ×
              </button>
            </div>

            {/* Content */}
            <div className="p-6">
              <div className="mb-4">
                <p className="text-sm text-gray-600 mb-2">
                  Are you sure you want to mark policy <strong>"{policyToDelete?.name}"</strong> as inactive?
                </p>
                <p className="text-xs text-red-600">
                  This action will affect related claims and cannot be undone.
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Reason for marking inactive <span className="text-red-500">*</span>
                </label>
                <textarea
                  value={inactiveReason}
                  onChange={(e) => setInactiveReason(e.target.value)}
                  placeholder="Please provide a reason for marking this policy as inactive..."
                  rows={3}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                />
              </div>
            </div>

            {/* Footer */}
            <div className="flex justify-end space-x-3 p-6 border-t border-gray-200">
              <button
                type="button"
                onClick={() => {
                  setShowDeleteModal(false);
                  setPolicyToDelete(null);
                  setInactiveReason('');
                }}
                className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200 cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={confirmDeletePolicy}
                disabled={!inactiveReason.trim()}
                className="px-4 py-2 text-sm font-medium text-white bg-red-600 rounded-md hover:bg-red-700 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Mark Inactive
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PolicyManagement; 
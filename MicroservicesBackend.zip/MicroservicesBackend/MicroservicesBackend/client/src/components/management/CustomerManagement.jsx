import { useState, useEffect } from 'react';
import { Search, Plus, Edit2, Eye, Phone, Mail, Calendar, User, XCircle, CheckCircle } from 'lucide-react';
import customerService from '../../services/customerService';
import authService from '../../services/authService';
import agentService from '../../services/agentService';
import ConfirmModal from '../shared/ConfirmModal';
import policyService from '../../services/policyService';
import toast from 'react-hot-toast';

const CustomerManagement = () => {
  const [customerList, setCustomerList] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [modalMode, setModalMode] = useState('add'); // 'add', 'edit', 'view'
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [selectedPolicy, setSelectedPolicy] = useState(null);
  const [showStatusModal, setShowStatusModal] = useState(false);
  const [customerToToggle, setCustomerToToggle] = useState(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [policyList, setPolicyList] = useState(null);
  const [selectedAgent, setSelectedAgent] = useState(null);
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: '',
    name: '',
    phone: '',
    address: '',
    isActive: true
  });

  // Load customers on component mount
  useEffect(() => {
    loadCustomers();
    loadPolicies();
  }, []);

  const loadCustomers = async () => {
    try {
      setLoading(true);
      const customers = await customerService.getAll();
      // Backend now includes isActive field, no need for fake status
      setCustomerList(customers);
    } catch (error) {
      console.error('Error loading customers:', error);
      toast.error(error.message || 'Failed to load customers');
    } finally {
      setLoading(false);
    }
  };

  const loadPolicies = async () => {
    try {
      setLoading(true);
      const policies = await policyService.getAll();
      setPolicyList(policies);
    } catch (error) {
      console.error('Error loading policies:', error);
      toast.error(error.message || 'Failed to load policies');
    } finally {
      setLoading(false);
    }
  };



  // Filter customers based on search term
  const filteredCustomers = customerList.filter(customer =>
    customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    customer.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    customer.phone.includes(searchTerm)
  );

  const handleSearch = (e) => {
    setSearchTerm(e.target.value);
  };

  const handleAddCustomer = () => {
    setModalMode('add');
    setFormData({
      username: '',
      email: '',
      password: '',
      name: '',
      phone: '',
      address: '',
      isActive: true
    });
    setShowModal(true);
  };

  const handleEditCustomer = (customer) => {
    setModalMode('edit');
    setSelectedCustomer(customer);
    setFormData({
      username: '', // Username cannot be edited
      email: customer.email,
      password: '', // Password field for resetting
      name: customer.name,
      phone: customer.phone,
      address: customer.address,
      isActive: customer.isActive !== undefined ? customer.isActive : true
    });
    setShowModal(true);
  };

  const handleViewCustomer = async (customer) => {
    setModalMode('view');
    setSelectedCustomer(customer);
    const policy = policyList ? policyList.find(p => p.customerId === customer.customerId) : null;
    setSelectedPolicy(policy);
    
    // Fetch agent information if policy has agentId
    if (policy && policy.agentId) {
      try {
        const agent = await agentService.getById(policy.agentId);
        setSelectedAgent(agent);
      } catch (error) {
        console.error('Error loading agent data:', error);
        setSelectedAgent(null);
      }
    } else {
      setSelectedAgent(null);
    }
    
    setShowModal(true);
  };

  const handleToggleCustomerStatus = (customer) => {
    setCustomerToToggle(customer);
    setShowStatusModal(true);
  };



    const confirmStatusToggle = async () => {
    if (customerToToggle) {
      try {
        const newStatus = !customerToToggle.isActive;
        
        console.log('Toggling customer status:', {
          customerId: customerToToggle.customerId,
          customerName: customerToToggle.name,
          currentStatus: customerToToggle.isActive,
          newStatus: newStatus
        });
        
        // Call the appropriate customer service method
                // Call the appropriate customer service method
        if (newStatus) {
          await customerService.activate(customerToToggle.customerId);
        } else {
          await customerService.deactivate(customerToToggle.customerId);
        }

        // Also update user status in auth service for login access control
-       await authService.updateUserStatus(customerToToggle.userId, newStatus);

        
        // Update local state immediately for better UX
        const updatedCustomers = customerList.map(c => 
          c.customerId === customerToToggle.customerId 
            ? { ...c, isActive: newStatus }
            : c
        );
        setCustomerList(updatedCustomers);
        
        toast.success(`Customer "${customerToToggle.name}" ${newStatus ? 'activated' : 'deactivated'} successfully!`);
        
        setShowStatusModal(false);
        setCustomerToToggle(null);
      } catch (error) {
        console.error('Error updating customer status:', error);
        toast.error(error.message || 'Failed to update customer status');
        // Revert the change on error
        loadCustomers();
        setShowStatusModal(false);
        setCustomerToToggle(null);
      }
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);

    try {
      if (modalMode === 'add') {
        // Create user with USER role (which creates customer automatically)
        const userData = {
          ...formData,
          role: 'USER' // Set role to USER for customer creation
        };
        await authService.createUser(userData);
        toast.success('Customer and login account created successfully!');
      } else if (modalMode === 'edit') {
        // For edit, only update customer data (not auth data)
        const customerData = {
          name: formData.name,
          email: formData.email,
          phone: formData.phone,
          address: formData.address
        };
        await customerService.update(selectedCustomer.customerId, customerData);
        toast.success('Customer updated successfully!');
      }
      loadCustomers(); // Reload customers to reflect changes
      setShowModal(false);
    } catch (error) {
      console.error('Error submitting form:', error);
      toast.error(error.message || 'Failed to save customer');
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="space-y-8">
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Customer Management</h1>
          <p className="text-gray-600">Manage customer accounts and information</p>
        </div>
        <button
          onClick={handleAddCustomer}
          className="flex items-center space-x-2 bg-blue-600 text-white px-3 py-2 rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium"
        >
          <Plus size={16} />
          <span>Add Customer</span>
        </button>
      </div>

      {/* Search and Filters */}
      <div className="bg-white p-6 rounded-xl shadow-sm">
        <div className="flex items-center space-x-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
            <input
              type="text"
              placeholder="Search customers by name, email, or phone..."
              className="w-full pl-10 pr-4 py-2 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none bg-gray-50"
              value={searchTerm}
              onChange={handleSearch}
            />
          </div>
        </div>
      </div>

      {/* Customer Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredCustomers.length === 0 ? (
          <div className="text-center py-12 col-span-full">
            <User className="mx-auto h-12 w-12 text-gray-400" />
            <h3 className="mt-2 text-sm font-medium text-gray-900">No customers found</h3>
            <p className="mt-1 text-sm text-gray-500">
              {searchTerm ? 'Try adjusting your search criteria.' : 'Get started by adding a new customer.'}
            </p>
          </div>
        ) : (
                     filteredCustomers.map((customer) => (
             <div key={customer.customerId} className="bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow p-6">
               <div className="flex items-start justify-between mb-4">
                 <div className="flex items-center space-x-3">
                   <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center">
                     <span className="text-white font-semibold text-lg">
                       {customer.name.split(' ').map(n => n[0]).join('')}
                     </span>
                   </div>
                   <div>
                     <h3 className="text-lg font-semibold text-gray-900">{customer.name}</h3>
                     <p className="text-sm text-gray-500">ID: {customer.customerId}</p>
                   </div>
                 </div>
                 <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                   customer.isActive 
                     ? 'bg-green-100 text-green-800' 
                     : 'bg-red-100 text-red-800'
                 }`}>
                   {customer.isActive ? 'Active' : 'Inactive'}
                   {!customer.userId && <span className="ml-1 text-orange-600">*</span>}
                 </span>
               </div>

               <div className="space-y-2 mb-4">
                 <div className="flex items-center text-sm text-gray-600">
                   <Mail size={14} className="mr-2" />
                   {customer.email}
                 </div>
                 <div className="flex items-center text-sm text-gray-600">
                   <Phone size={14} className="mr-2" />
                   {customer.phone}
                 </div>
                 <div className="flex items-center text-sm text-gray-600">
                   <Calendar size={14} className="mr-2" />
                   Joined: {customer.createdAt ? new Date(customer.createdAt).toLocaleDateString() : 'N/A'}
                 </div>
               </div>

               <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                 <div className="text-sm text-gray-500">
                   Customer Profile
                 </div>
                 <div className="flex space-x-2">
                   <button
                     onClick={() => handleViewCustomer(customer)}
                     className="text-blue-600 hover:text-blue-900 p-1 rounded hover:bg-blue-50"
                     title="View Details"
                   >
                     <Eye size={16} />
                   </button>
                   <button
                     onClick={() => handleEditCustomer(customer)}
                     className="text-indigo-600 hover:text-indigo-900 p-1 rounded hover:bg-indigo-50"
                     title="Edit Customer"
                   >
                     <Edit2 size={16} />
                   </button>

                  {customer.status?.toLowerCase() === 'active' || customer.isActive ? (
                  <button
                    onClick={() => handleToggleCustomerStatus(customer)}
                    className="text-red-600 hover:text-red-900 p-1 rounded hover:bg-red-50 cursor-pointer"
                    title="Deactivate Customer"
                  >
                    <XCircle size={16} />
                  </button>
                ) : (
                  <button
                    onClick={() => handleToggleCustomerStatus(customer)}
                    className="text-green-600 hover:text-green-900 p-1 rounded hover:bg-green-50 cursor-pointer"
                    title="Activate Customer"
                  >
                    <CheckCircle size={16} />
                  </button>
                )}
                 </div>
               </div>
             </div>
           ))
        )}
      </div>

      {/* View Customer Details - Simple inline modal */}
      {showModal && modalMode === 'view' && selectedCustomer && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50 overflow-y-auto scrollbar-hide md:scrollbar-default">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-3xl mx-auto lg:max-h-[90vh] overflow-y-auto scrollbar-hide md:scrollbar-default">
            
            {/* Header */}
            <div className="flex items-center justify-between p-6">
              <h3 className="text-xl font-semibold text-gray-900">📋 Customer Details</h3>
              <button
                onClick={() => {
                  setShowModal(false);
                  setSelectedAgent(null);
                }}
                className="w-8 h-8 rounded-full bg-blue-500 text-white hover:bg-blue-600 transition-colors cursor-pointer"
              >
                ×
              </button>
            </div>

            {/* Content */}
            <div className="p-6 space-y-6">
              
              {/* Basic Information */}
              <div className="p-4 rounded-lg border border-gray-300">
                <h4 className="font-medium text-gray-900 mb-2">
                  Basic Information
                </h4>
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-gray-50 p-3 rounded">
                    <label className="text-sm font-medium text-gray-700">Full Name</label>
                    <p className="text-sm text-gray-900 font-medium">{selectedCustomer.name}</p>
                  </div>
                  <div className="inline-block bg-gray-50 rounded p-3">
                    <div className="inline-flex flex-col gap-1.5">
                    <label className="text-sm font-medium text-gray-700">Status</label>
                    <span className="px-3 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800">
                      Active
                    </span>
                    </div>
                  </div>
                  <div className="bg-gray-50 p-3 rounded">
                    <label className="text-sm font-medium text-gray-700">Customer ID</label>
                    <p className="text-sm text-gray-900 font-medium">{selectedCustomer.customerId}</p>
                  </div>
                  <div className="bg-gray-50 p-3 rounded">
                    <label className="text-sm font-medium text-gray-700">Join Date</label>
                    <p className="text-sm text-gray-900 font-medium">
                      {selectedCustomer.createdAt ? new Date(selectedCustomer.createdAt).toLocaleDateString() : 'N/A'}
                    </p>
                  </div>
                </div>
              </div>

              {/* Contact Information */}
              <div className="p-4 rounded-lg border border-gray-300">
                <h4 className="font-medium text-gray-900 mb-2">
                Contact Information
                </h4>
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div className="bg-gray-50 p-3 rounded">
                    <label className="text-sm font-medium text-gray-700">Email Address</label>
                    <p className="text-sm text-gray-900 font-medium">{selectedCustomer.email}</p>
                  </div>
                  <div className="bg-gray-50 p-3 rounded">
                    <label className="text-sm font-medium text-gray-700">Phone Number</label>
                    <p className="text-sm text-gray-900 font-medium">{selectedCustomer.phone}</p>
                  </div>
                </div>
                <div className="bg-gray-50 p-3 rounded">
                  <label className="text-sm font-medium text-gray-700">Address</label>
                  <p className="text-sm text-gray-900">{selectedCustomer.address}</p>
                </div>
              </div>

               {/* Policy Information */}
              {selectedPolicy && (
                <div className="p-4 rounded-lg border border-gray-300">
                  <h4 className="font-medium text-gray-900 mb-2">
                    📋 Policy Information
                  </h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-gray-50 p-3 rounded">
                      <label className="text-sm font-medium text-gray-700">Policy ID</label>
                      <p className="text-sm text-gray-900 font-medium">{selectedPolicy.policyId}</p>
                    </div>
                    <div className="bg-gray-50 p-3 rounded">
                      <label className="text-sm font-medium text-gray-700">Policy Name</label>
                      <p className="text-sm text-gray-900 font-medium">{selectedPolicy.name}</p>
                    </div>
                    <div className="bg-gray-50 p-3 rounded">
                      <label className="text-sm font-medium text-gray-700">Premium Amount</label>
                      <p className="text-sm text-gray-900 font-medium">₹{selectedPolicy.premiumAmount?.toLocaleString()}</p>
                    </div>
                    <div className="bg-gray-50 p-3 rounded">
                      <label className="text-sm font-medium text-gray-700">Status</label>
                      <p className="text-sm text-gray-900 font-medium">{selectedPolicy.status}</p>
                    </div>
                  </div>
                </div>
              )}

              {/* Agent Information */}
              {selectedAgent && (
                <div className="p-4 rounded-lg border border-gray-300">
                  <h4 className="font-medium text-gray-900 mb-2">
                    👤 Assigned Agent
                  </h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-gray-50 p-3 rounded">
                      <label className="text-sm font-medium text-gray-700">Agent Name</label>
                      <p className="text-sm text-gray-900 font-medium">{selectedAgent.name || 'Not Available'}</p>
                    </div>
                    <div className="bg-gray-50 p-3 rounded">
                      <label className="text-sm font-medium text-gray-700">License Number</label>
                      <p className="text-sm text-gray-900 font-medium">{selectedAgent.licenseNumber || 'Not Available'}</p>
                    </div>
                    <div className="bg-gray-50 p-3 rounded">
                      <label className="text-sm font-medium text-gray-700">Email</label>
                      <p className="text-sm text-gray-900 font-medium">{selectedAgent.email || 'Not Available'}</p>
                    </div>
                    <div className="bg-gray-50 p-3 rounded">
                      <label className="text-sm font-medium text-gray-700">Phone</label>
                      <p className="text-sm text-gray-900 font-medium">{selectedAgent.phone || 'Not Available'}</p>
                    </div>
                    <div className="bg-gray-50 p-3 rounded col-span-2">
                      <label className="text-sm font-medium text-gray-700">Address</label>
                      <p className="text-sm text-gray-900 font-medium">{selectedAgent.address || 'Not Available'}</p>
                    </div>
                    {selectedAgent.specialization && (
                      <div className="bg-gray-50 p-3 rounded col-span-2">
                        <label className="text-sm font-medium text-gray-700">Specialization</label>
                        <p className="text-sm text-gray-900 font-medium">{selectedAgent.specialization}</p>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {!selectedPolicy && (
                <div className="p-4 rounded-lg border border-gray-300">
                  <h4 className="font-medium text-gray-900 mb-2">
                    📋 Policy Information
                  </h4>
                  <p className="text-sm text-gray-500">No policy assigned to this customer.</p>
                </div>
              )}

              {/* Account Summary */}
              <div className="p-4 rounded-lg border border-gray-300">
                <h4 className="font-medium text-gray-900 mb-2">
                  Account Summary
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="text-center p-4 bg-gray-50 rounded-lg border border-gray-200">
                    <div className="text-2xl font-bold text-gray-900">{selectedCustomer.customerId}</div>
                    <div className="text-sm text-gray-700">Customer ID</div>
                  </div>
                  <div className="text-center p-4 bg-gray-50 rounded-lg border border-gray-200">
                    <div className="text-2xl font-bold text-green-600">Active</div>
                    <div className="text-sm text-gray-700">Account Status</div>
                  </div>
                  <div className="text-center p-4 bg-gray-50 rounded-lg border border-gray-200">
                    <div className="text-2xl font-bold text-gray-900">
                      {selectedCustomer.updatedAt.split("T")[0]}
                    </div>
                    <div className="text-sm text-gray-700">Last Updated</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Add/Edit Customer Form - Simple inline modal */}
      {showModal && (modalMode === 'add' || modalMode === 'edit') && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50 overflow-y-auto scrollbar-hide md:scrollbar-default">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-3xl mx-auto lg:max-h-[90vh] overflow-y-auto scrollbar-hide md:scrollbar-default">
            
            {/* Header */}
            <div className="flex items-center justify-between p-6">
              <h3 className="text-xl font-semibold text-gray-900">
                {modalMode === 'add' ? '👤 Create Customer & Login Account' : '✏️ Edit Customer'}
              </h3>
              <button
                onClick={() => setShowModal(false)}
                className="w-8 h-8 rounded-full bg-blue-500 text-white hover:bg-blue-600 transition-colors cursor-pointer"
              >
                ×
              </button>
            </div>

            {/* Form */}
            <form onSubmit={handleSubmit} className="space-y-4 p-6">
              
              {/* Login Credentials - Only for Add mode */}
              {modalMode === 'add' && (
                <div className="p-4 rounded-lg border border-blue-300 bg-blue-50">
                  <h4 className="font-medium text-gray-900 mb-2">
                    🔐 Login Credentials
                  </h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Username <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="text"
                        value={formData.username}
                        onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                        placeholder="Enter username (min 3 chars)"
                        required
                        minLength={3}
                        maxLength={50}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Password <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="password"
                        value={formData.password}
                        onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                        placeholder="Enter password (min 6 chars)"
                        required
                        minLength={6}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      />
                    </div>
                  </div>
                  <p className="text-sm text-blue-600 mt-2">
                    ℹ️ These credentials will be used by the customer to log into the system
                  </p>
                </div>
              )}

              {/* Basic Information */}
              <div className="p-4 rounded-lg border border-gray-300">
                <h4 className="font-medium text-gray-900 mb-2">
                  👤 Basic Information
                </h4>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Full Name <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="Enter full name"
                      required
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Status
                    </label>
                    <div className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-100 text-gray-600">
                      ✅ Active (Default)
                    </div>
                  </div>
                </div>
              </div>

              {/* Contact Information */}
              <div className="p-4 rounded-lg border border-gray-300">
                <h4 className="font-medium text-gray-900 mb-2">
                  📞 Contact Information
                </h4>
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Email Address <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="customer@example.com"
                      required
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Phone Number <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      placeholder="1234567890 (10 digits only)"
                      required
                      pattern="[0-9]{10}"
                      maxLength={10}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                    <p className="text-xs text-gray-500 mt-1">Enter 10 digits without spaces or symbols</p>
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Address <span className="text-red-500">*</span>
                  </label>
                  <textarea
                    value={formData.address}
                    onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                    rows="3"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                    placeholder="Enter full address (min 10 characters)..."
                    required
                    minLength={10}
                    maxLength={200}
                  />
                </div>
              </div>

              {/* Footer */}
              <div className="flex justify-end space-x-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 cursor-pointer"
                >
                  {submitting ? 'Creating...' : modalMode === 'add' ? '🔐 Create Customer & Account' : '💾 Update Customer'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      
      {/* Status Change Confirmation Modal */}
      <ConfirmModal
        isOpen={showStatusModal}
        onClose={() => {
          setShowStatusModal(false);
          setCustomerToToggle(null);
        }}
        onConfirm={confirmStatusToggle}
        title={customerToToggle?.isActive ? "Deactivate Customer" : "Activate Customer"}
        message={
          customerToToggle?.isActive 
            ? `Are you sure you want to deactivate "${customerToToggle?.name}"? They will no longer be able to access their account and login to the system.`
            : `Are you sure you want to activate "${customerToToggle?.name}"? They will be able to access their account and login to the system again.`
        }
        confirmText={customerToToggle?.isActive ? "Deactivate" : "Activate"}
        cancelText="Cancel"
        type={customerToToggle?.isActive ? "warning" : "success"}
      />
    </div>
  );
};

export default CustomerManagement; 
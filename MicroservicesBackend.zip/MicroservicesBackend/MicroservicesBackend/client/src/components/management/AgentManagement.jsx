import { useState, useEffect } from 'react';
import { Search, Plus, Edit2, Eye, Phone, Mail, User, Shield, FileText, CheckCircle, XCircle } from 'lucide-react';
import { toast } from 'react-hot-toast';
import agentService from '../../services/agentService';
import customerService from '../../services/customerService';
import policyService from '../../services/policyService';
import authService from '../../services/authService';
import ConfirmModal from '../shared/ConfirmModal';
import PasswordInput from '../shared/PasswordInput';

const AgentManagement = () => {
  const [agentList, setAgentList] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [modalMode, setModalMode] = useState('add');
  const [selectedAgent, setSelectedAgent] = useState(null);
  const [showStatusModal, setShowStatusModal] = useState(false);
  const [agentToUpdate, setAgentToUpdate] = useState(null);
  const [statusAction, setStatusAction] = useState(''); // 'activate' or 'deactivate'
  const [agentPolicy, setAgentPolicy] = useState([]);

  const [formData, setFormData] = useState({
    username: '',
    name: '',
    email: '',
    phone: '',
    address: '',
    password: '',
    confirmPassword: '',
    licenseNumber: '',
    specialization: '',
    commissionRate: '5.0',
    status: 'Active'
  });


  useEffect(() => {
    loadAgents();
  }, []);

  const loadAgents = async () => {
    try {
      setLoading(true);
      const agents = await agentService.getAll();
      setAgentList(agents);
    } catch (error) {
      console.error('Error loading agents:', error);
      toast.error('Failed to load agents');
    } finally {
      setLoading(false);
    }
  };

  const loadAgentPolicies = async (agentId) => {
    try {
      const policies = await policyService.getByAgent(agentId);
      setAgentPolicy(policies);
      console.log('Agent Policies:', agentPolicy);
    } catch (error) {
      console.error('Error loading agent policies:', error);
      toast.error('Failed to load agent policies');
    }
  };

  const filteredAgents = agentList.filter(agent =>
    agent.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    agent.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    agent.phone?.includes(searchTerm) ||
    agent.specialization?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    agent.licenseNumber?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleAddAgent = () => {
    setModalMode('add');
    setSelectedAgent(null);
    setFormData({
      username: '',
      name: '',
      email: '',
      phone: '',
      address: '',
      password: '',
      confirmPassword: '',
      licenseNumber: '',
      specialization: '',
      commissionRate: '5.0',
      status: 'Active'
    });
    setShowModal(true);
  };

  const handleEditAgent = (agent) => {
    setModalMode('edit');
    setSelectedAgent(agent);
    // Format phone number for display (remove +1 prefix if present)
    const displayPhone = agent.phone?.replace(/^\+1/, '') || '';
    setFormData({
      username: agent.username || '',
      name: agent.name || '',
      email: agent.email || '',
      phone: displayPhone,
      address: agent.address || '',
      password: '',
      confirmPassword: '',
      licenseNumber: agent.licenseNumber || '',
      specialization: agent.specialization || '',
      commissionRate: agent.commissionRate || '5.0',
      status: agent.status || 'Active'
    });
    setShowModal(true);
  };


  const handleViewAgent = (agent) => {
    setModalMode('view');
    setSelectedAgent(agent);
    loadAgentPolicies(agent.agentId);
    setShowModal(true);
  };

  const handleActivateAgent = (agent) => {
    setAgentToUpdate(agent);
    setStatusAction('activate');
    setShowStatusModal(true);
  };

  const handleDeactivateAgent = (agent) => {
    setAgentToUpdate(agent);
    setStatusAction('deactivate');
    setShowStatusModal(true);
  };

  const confirmStatusChange = async () => {
    if (agentToUpdate) {
      try {
        const agentId = agentToUpdate.agentId || agentToUpdate.id;
        
        if (statusAction === 'activate') {
          await agentService.activate(agentId);
          await authService.updateUserStatus(agentToUpdate.userId, true);
          toast.success('Agent activated successfully');
        } else {
          await agentService.deactivate(agentId);
          await authService.updateUserStatus(agentToUpdate.userId, false);
          toast.success('Agent deactivated successfully');
        }
        
        setAgentToUpdate(null);
        setStatusAction('');
        setShowStatusModal(false);
        await loadAgents(); // Reload the list
      } catch (error) {
        console.error(`Error ${statusAction}ing agent:`, error);
        toast.error(error.message || `Failed to ${statusAction} agent`);
      }
    }
  };

  const validateForm = () => {
    if (modalMode === 'add') {
      // Validate required fields
      if (!formData.username || formData.username.length < 3) {
        toast.error('Username must be at least 3 characters long');
        return false;
      }
      
      if (!formData.name || formData.name.trim().length < 2) {
        toast.error('Name is required');
        return false;
      }
      
      if (!formData.email || !formData.email.includes('@')) {
        toast.error('Valid email is required');
        return false;
      }
      
      if (!formData.phone || formData.phone.replace(/\D/g, '').length !== 10) {
        toast.error('Phone number must be exactly 10 digits');
        return false;
      }
      
      if (!formData.address || formData.address.trim().length < 10) {
        toast.error('Address must be at least 10 characters long');
        return false;
      }
      
      if (!formData.password || formData.password.length < 6) {
        toast.error('Password must be at least 6 characters long');
        return false;
      }
      
      if (formData.password !== formData.confirmPassword) {
        toast.error('Passwords do not match');
        return false;
      }
      
      if (!formData.licenseNumber || formData.licenseNumber.trim().length < 3) {
        toast.error('License number is required');
        return false;
      }
      
      if (!formData.specialization) {
        toast.error('Specialization is required');
        return false;
      }
      
      const commissionRate = parseFloat(formData.commissionRate);
      if (isNaN(commissionRate) || commissionRate < 0 || commissionRate > 50) {
        toast.error('Commission rate must be between 0 and 50');
        return false;
      }
    }
    
    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }
    
    try {
      if (modalMode === 'add') {
        const agentData = {
          username: formData.username.trim(),
          name: formData.name.trim(),
          email: formData.email.trim(),
          phone: formData.phone.replace(/\D/g, ''), // Remove non-numeric characters
          address: formData.address.trim(),
          password: formData.password,
          licenseNumber: formData.licenseNumber.trim(),
          specialization: formData.specialization,
          commissionRate: parseFloat(formData.commissionRate) || 5.0,
          role: "AGENT"
        };

        console.log('Submitting agent data:', agentData);
        await authService.createUser(agentData);
        toast.success('Agent created successfully with login credentials');
      } else if (modalMode === 'edit') {
        // For editing, use the direct agent service (no password change)
        const agentData = {
          name: formData.name.trim(),
          email: formData.email.trim(),
          phone: formData.phone.replace(/\D/g, ''), // Remove non-numeric characters
          address: formData.address.trim(),
          licenseNumber: formData.licenseNumber.trim(),
          specialization: formData.specialization,
          commissionRate: parseFloat(formData.commissionRate) || 5.0
        };

        // Use the correct ID field - backend uses agentId
        const agentId = selectedAgent.agentId || selectedAgent.id;
        await agentService.update(agentId, agentData);
        toast.success('Agent updated successfully');
      }
      
      setShowModal(false);
      setSelectedAgent(null);
      await loadAgents(); // Reload the list
    } catch (error) {
      console.error('Error saving agent:', error);
      console.error('Error details:', error.details);
      
      // Handle specific error messages
      if (error.message) {
        if (error.message.includes('Username already exists')) {
          toast.error('Username already exists. Please choose a different username.');
        } else if (error.message.includes('Email already exists')) {
          toast.error('Email already exists. Please use a different email address.');
        } else if (error.message.includes('License number')) {
          toast.error('License number already exists. Please use a different license number.');
        } else if (error.message.includes('Phone number should be valid')) {
          toast.error('Phone number format is invalid. Please enter a valid 10-digit phone number.');
        } else if (error.message.includes('Commission rate is required')) {
          toast.error('Commission rate is required for agents.');
        } else if (error.message.includes('Specialization is required')) {
          toast.error('Specialization is required for agents.');
        } else if (error.message.includes('License number is required')) {
          toast.error('License number is required for agents.');
        } else {
          toast.error(error.message);
        }
      } else {
        toast.error('Failed to save agent. Please check all fields and try again.');
      }
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'Active': return 'bg-green-100 text-green-800';
      case 'Inactive': return 'bg-red-100 text-red-800';
      case 'On Leave': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Agent Management</h1>
          <p className="text-gray-600">Manage insurance agents and their assignments</p>
        </div>
        <button
          onClick={handleAddAgent}
          className="flex items-center space-x-2 bg-blue-600 text-white px-3 py-2 rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium cursor-pointer"
        >
          <Plus size={16} />
          <span>Add Agent</span>
        </button>
      </div>

      {/* Search and Filters */}
      <div className="bg-white p-6 rounded-xl shadow-sm">
        <div className="flex items-center space-x-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
            <input
              type="text"
              placeholder="Search agents by name, email, phone, specialization, or license number..."
              className="w-full pl-10 pr-4 py-2 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none bg-gray-50"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
      </div>

      {/* Agent Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredAgents.map((agent) => (
          <div key={agent.agentId || agent.id} className="bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow p-6">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center">
                  <span className="text-white font-semibold text-lg">
                    {agent.name?.split(' ').map(n => n[0]).join('') || 'A'}
                  </span>
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">{agent.name || 'N/A'}</h3>
                  <p className="text-sm text-gray-500">{agent.specialization || 'N/A'}</p>
                </div>
              </div>
              <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(agent.status || (agent.isActive ? 'Active' : 'Inactive'))}`}>
                {agent.status || (agent.isActive ? 'Active' : 'Inactive')}
              </span>
            </div>

            <div className="space-y-2 mb-4">
              <div className="flex items-center text-sm text-gray-600">
                <Mail size={14} className="mr-2" />
                {agent.email || 'N/A'}
              </div>
              <div className="flex items-center text-sm text-gray-600">
                <Phone size={14} className="mr-2" />
                {agent.phone?.replace(/^\+1/, '') || 'N/A'}
              </div>
              <div className="flex items-center text-sm text-gray-600">
                <FileText size={14} className="mr-2" />
                License: {agent.licenseNumber || 'N/A'}
              </div>
              {agent.commissionRate && (
                <div className="flex items-center text-sm text-gray-600">
                  <Shield size={14} className="mr-2" />
                  Commission: {agent.commissionRate}%
                </div>
              )}
            </div>

            <div className="flex items-center justify-between pt-4 border-t border-gray-100">
              <div className="text-sm text-gray-500">
                Agent ID: {agent.agentId || agent.id}
              </div>
              <div className="flex space-x-2">
                <button
                  onClick={() => handleViewAgent(agent)}
                  className="text-blue-600 hover:text-blue-900 p-1 rounded hover:bg-blue-50 cursor-pointer"
                  title="View Details"
                >
                  <Eye size={16} />
                </button>
                <button
                  onClick={() => handleEditAgent(agent)}
                  className="text-indigo-600 hover:text-indigo-900 p-1 rounded hover:bg-indigo-50 cursor-pointer"
                  title="Edit Agent"
                >
                  <Edit2 size={16} />
                </button>
                {agent.status?.toLowerCase() === 'active' || agent.isActive ? (
                  <button
                    onClick={() => handleDeactivateAgent(agent)}
                    className="text-red-600 hover:text-red-900 p-1 rounded hover:bg-red-50 cursor-pointer"
                    title="Deactivate Agent"
                  >
                    <XCircle size={16} />
                  </button>
                ) : (
                  <button
                    onClick={() => handleActivateAgent(agent)}
                    className="text-green-600 hover:text-green-900 p-1 rounded hover:bg-green-50 cursor-pointer"
                    title="Activate Agent"
                  >
                    <CheckCircle size={16} />
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredAgents.length === 0 && !loading && (
        <div className="text-center py-12">
          <User className="mx-auto h-12 w-12 text-gray-400" />
          <h3 className="mt-2 text-sm font-medium text-gray-900">No agents found</h3>
          <p className="mt-1 text-sm text-gray-500">
            {searchTerm ? 'Try adjusting your search criteria.' : 'Get started by adding a new agent.'}
          </p>
        </div>
      )}

      {/* Status Change Confirmation Modal */}
      <ConfirmModal
        isOpen={showStatusModal}
        onClose={() => {
          setShowStatusModal(false);
          setAgentToUpdate(null);
          setStatusAction('');
        }}
        onConfirm={confirmStatusChange}
        title={`${statusAction === 'activate' ? 'Activate' : 'Deactivate'} Agent`}
        message={`Are you sure you want to ${statusAction} ${agentToUpdate?.name}?`}
        confirmText={statusAction === 'activate' ? 'Activate' : 'Deactivate'}
        confirmButtonClass={statusAction === 'activate' ? 'bg-green-600 hover:bg-green-700' : 'bg-red-600 hover:bg-red-700'}
        icon={statusAction === 'activate' ? CheckCircle : XCircle}
      />

      {/* View Agent Details Modal */}
      {showModal && modalMode === 'view' && selectedAgent && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50 overflow-y-auto scrollbar-hide md:scrollbar-default">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-3xl mx-auto lg:max-h-[90vh] overflow-y-auto scrollbar-hide md:scrollbar-default">
            
            {/* Header */}
            <div className="flex items-center justify-between p-6">
              <h3 className="text-xl font-semibold text-gray-900">📋 Agent Details</h3>
              <button
                onClick={() => setShowModal(false)}
                className="w-8 h-8 rounded-full bg-blue-500 text-white hover:bg-blue-600 transition-colors cursor-pointer"
              >
                ×
              </button>
            </div>

            {/* Content */}
            <div className="p-6 space-y-6">
              
              {/* Basic Information */}
              <div className="p-4 rounded-lg border border-gray-300">
                <h4 className="font-medium text-gray-900 mb-2">
                  Basic Information
                </h4>
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-gray-50 p-3 rounded">
                    <label className="text-sm font-medium text-gray-700">Full Name</label>
                    <p className="text-sm text-gray-900 font-medium">{selectedAgent.name || 'N/A'}</p>
                  </div>
                  <div className="bg-gray-50 p-3 rounded">
                    <div className="inline-flex flex-col gap-1.5">
                    <label className="text-sm font-medium text-gray-700">Specialization</label>
                    <span className="px-3 py-1 text-sm font-medium rounded-full bg-blue-100 text-blue-800">
                      {selectedAgent.specialization || 'N/A'}
                    </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Contact Information */}
              <div className="p-4 rounded-lg border border-gray-300">
                <h4 className="font-medium text-gray-900 mb-2">
                  📞 Contact Information
                </h4>
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div className="bg-gray-50 p-3 rounded">
                    <label className="text-sm font-medium text-gray-700">Email</label>
                    <p className="text-sm text-gray-900 font-medium">{selectedAgent.email || 'N/A'}</p>
                  </div>
                  <div className="bg-gray-50 p-3 rounded">
                    <label className="text-sm font-medium text-gray-700">Phone</label>
                    <p className="text-sm text-gray-900 font-medium">{selectedAgent.phone?.replace(/^\+1/, '') || 'N/A'}</p>
                  </div>
                </div>
                <div className="bg-gray-50 p-3 rounded">
                  <label className="text-sm font-medium text-gray-700">Address</label>
                  <p className="text-sm text-gray-900">{selectedAgent.address || 'N/A'}</p>
                </div>
              </div>

              {/* Professional Details */}
              <div className="p-4 rounded-lg border border-gray-300">
                <h4 className="font-medium text-gray-900 mb-2">
                  Professional Details
                </h4>
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-gray-50 p-3 rounded">
                    <label className="text-sm font-medium text-gray-700">License Number</label>
                    <p className="text-sm text-gray-900 font-medium">{selectedAgent.licenseNumber || 'N/A'}</p>
                  </div>
                  <div className="bg-gray-50 p-3 rounded">
                    <label className="text-sm font-medium text-gray-700">Commission Rate</label>
                    <p className="text-sm text-gray-900 font-medium">{selectedAgent.commissionRate || 0}%</p>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4 mt-4">
                  <div className="bg-gray-50 p-3 rounded">
                    <label className="text-sm font-medium text-gray-700">Status</label>
                    <div>
                      <span className={`px-3 py-1 text-sm font-semibold rounded-full ${getStatusColor(selectedAgent.status || (selectedAgent.isActive ? 'Active' : 'Inactive'))}`}>
                      {selectedAgent.status || (selectedAgent.isActive ? 'Active' : 'Inactive')}
                    </span>
                    </div>
                    
                  </div>
                  <div className="bg-gray-50 p-3 rounded">
                    <label className="text-sm font-medium text-gray-700">Agent ID</label>
                    <p className="text-sm text-gray-900 font-medium">{selectedAgent.agentId || selectedAgent.id}</p>
                  </div>
                </div>
              </div>
              {/* Policy Information */}
              {agentPolicy.length > 0 && <div className="p-4 rounded-lg border border-gray-300">
                <h4 className="font-medium text-gray-900 mb-2">
                  📄 Policy Information
                </h4>
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div className="bg-gray-50 p-3 rounded">
                    <label className="text-sm font-medium text-gray-700">Policy ID</label>
                    <p className="text-sm text-gray-900 font-medium">{agentPolicy[0].policyId|| 'N/A'}</p>
                  </div>
                  <div className="bg-gray-50 p-3 rounded">
                  <label className="text-sm font-medium text-gray-700">Policy Name</label>
                  <p className="text-sm text-gray-900">{agentPolicy[0].name || 'N/A'}</p>
                  </div>
                  <div className="bg-gray-50 p-3 rounded">
                    <label className="text-sm font-medium text-gray-700">Coverage Amount</label>
                    <p className="text-sm text-gray-900 font-medium">{agentPolicy[0].coverageAmount || 'N/A'}</p>
                  </div>
                  <div className="bg-gray-50 p-3 rounded">
                    <label className="text-sm font-medium text-gray-700">Validity Period</label>
                    <p className="text-sm text-gray-900 font-medium">{agentPolicy[0].validityPeriod || 'N/A'}</p>
                  </div>
                </div>
              </div>}
            </div>
          </div>
        </div>
      )}

      {/* Add/Edit Agent Form Modal */}
      {showModal && (modalMode === 'add' || modalMode === 'edit') && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50 overflow-y-auto scrollbar-hide md:scrollbar-default">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-3xl mx-auto lg:max-h-[90vh] overflow-y-auto scrollbar-hide md:scrollbar-default">
            
            {/* Header */}
            <div className="flex items-center justify-between p-6">
              <h3 className="text-xl font-semibold text-gray-900">
                {modalMode === 'add' ? '👨‍💼 Add New Agent' : '✏️ Edit Agent'}
              </h3>
              <button
                onClick={() => setShowModal(false)}
                className="w-8 h-8 rounded-full bg-blue-500 text-white hover:bg-blue-600 transition-colors cursor-pointer"
              >
                ×
              </button>
            </div>

            {/* Form */}
            <form onSubmit={handleSubmit} className="space-y-4 p-6">
              
              {/* Basic Information */}
              <div className="p-4 rounded-lg border border-gray-300">
                <h4 className="font-medium text-gray-900 mb-2">
                  Basic Information
                </h4>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Username <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      value={formData.username}
                      onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                      placeholder="Enter username for login"
                      required
                      disabled={modalMode === 'edit'}
                      minLength={3}
                      maxLength={50}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:bg-gray-100"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Full Name <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="Enter agent's full name"
                      required
                      minLength={2}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4 mt-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Specialization <span className="text-red-500">*</span>
                    </label>
                    <select
                      value={formData.specialization}
                      onChange={(e) => setFormData({ ...formData, specialization: e.target.value })}
                      required
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    >
                      <option value="">Choose specialization</option>
                      <option value="Life Insurance">💖 Life Insurance</option>
                      <option value="Health Insurance">🏥 Health Insurance</option>
                      <option value="Auto Insurance">🚗 Auto Insurance</option>
                      <option value="Home Insurance">🏠 Home Insurance</option>
                      <option value="General Insurance">🛡️ General Insurance</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Login Credentials - Only for new agents */}
              {modalMode === 'add' && (
                <div className="p-4 rounded-lg border border-gray-300">
                  <h4 className="font-medium text-gray-900 mb-2">
                    🔐 Login Credentials
                  </h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Password <span className="text-red-500">*</span>
                      </label>
                      <PasswordInput
                        value={formData.password}
                        onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                        placeholder="Enter password (min 6 characters)"
                        required
                        minLength={6}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Confirm Password <span className="text-red-500">*</span>
                      </label>
                      <PasswordInput
                        value={formData.confirmPassword}
                        onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                        placeholder="Confirm password"
                        required
                        minLength={6}
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* Contact Information */}
              <div className="p-4 rounded-lg border border-gray-300">
                <h4 className="font-medium text-gray-900 mb-2">
                  📞 Contact Information
                </h4>
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Email <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="agent@example.com"
                      required
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Phone <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      placeholder="1234567890"
                      required
                      pattern="[0-9]{10}"
                      maxLength={10}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                    <p className="text-xs text-gray-500 mt-1">Enter 10-digit phone number (e.g., 1234567890)</p>
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Address <span className="text-red-500">*</span>
                  </label>
                  <textarea
                    value={formData.address}
                    onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                    placeholder="Enter complete address..."
                    rows={3}
                    required
                    minLength={10}
                    maxLength={200}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                  />
                </div>
              </div>

              {/* Professional Details */}
              <div className="p-4 rounded-lg border border-gray-300">
                <h4 className="font-medium text-gray-900 mb-2">
                  Professional Details
                </h4>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      License Number <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      value={formData.licenseNumber}
                      onChange={(e) => setFormData({ ...formData, licenseNumber: e.target.value })}
                      placeholder="e.g. AGT123456"
                      required
                      minLength={3}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Commission Rate (%) <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="number"
                      value={formData.commissionRate}
                      onChange={(e) => setFormData({ ...formData, commissionRate: e.target.value })}
                      placeholder="e.g. 5.0"
                      required
                      min="0"
                      max="50"
                      step="0.1"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                </div>
              </div>

              {/* Footer */}
              <div className="flex justify-end space-x-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 cursor-pointer"
                >
                  {modalMode === 'add' ? '👨‍💼 Create Agent' : '✏️ Update Agent'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default AgentManagement;
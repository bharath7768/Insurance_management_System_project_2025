import { useState, useEffect } from 'react';
import { Search, Plus, Eye, FileText, CheckCircle, X, Filter, Calendar, DollarSign, Shield, User, UserCheck, RefreshCw } from 'lucide-react';
import { claimService, customerService, policyService, agentService } from '../../services/index.js';
import ClaimFilingModal from '../shared/ClaimFilingModal';
import toast from 'react-hot-toast';

const ClaimProcessing = ({ currentUser }) => {
  const [claimsList, setClaimsList] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [policies, setPolicies] = useState([]);
  const [agents, setAgents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [showModal, setShowModal] = useState(false);
  const [modalMode, setModalMode] = useState('view');
  const [selectedClaim, setSelectedClaim] = useState(null);
  const [showFilingModal, setShowFilingModal] = useState(false);

  // get current user agent/customer data
  const getCurrentUserData = () => {
    if (currentUser?.role === 'agent') {
      return agents.find(agent => agent.email === currentUser.email);
    } else if (currentUser?.role === 'user') {
      return customers.find(customer => customer.email === currentUser.email);
    }
    return null;
  };


  // Get selected claim user data
  const getCurrentClaimUser = (id) => {
    const customer = customers.find(c => c.customerId === id);
    console.log(customer)
    return customer;
  }

  // Fetch all necessary data
  const fetchData = async (showToast = false) => {
    try {
      if (showToast) setRefreshing(true);

      let claimsData = [];
      let customersData = [];
      let policiesData = [];
      let agentsData = [];

      // Fetch data based on user role
      if (currentUser?.role === 'admin') {
        // Admin can see all data
        const [claims, customers, policies, agents] = await Promise.all([
          claimService.getAll(),
          customerService.getAll(),
          policyService.getAll(),
          agentService.getAll()
        ]);
        claimsData = claims || [];
        customersData = customers || [];
        policiesData = policies || [];
        agentsData = agents || [];
      } else if (currentUser?.role === 'agent') {
        // Agent sees their assigned claims and related data
        const agentProfile = await agentService.getProfile();
        const agentClaims = await claimService.getByAgent(agentProfile.agentId);
        const [customers, policies] = await Promise.all([
          customerService.getAll(agentProfile.agentId),
          policyService.getByAgent(agentProfile.agentId)
        ]);
        claimsData = agentClaims || [];
        customersData = customers || [];
        policiesData = policies || [];
        agentsData = [agentProfile];
      } else if (currentUser?.role === 'user') {
        // Customer sees only their claims
        const customerProfile = await customerService.getProfile();
        const customerClaims = await claimService.getByCustomer(customerProfile.customerId);
        const customerPolicies = await policyService.getByCustomer(customerProfile.customerId);
        claimsData = customerClaims || [];
        customersData = [customerProfile];
        policiesData = customerPolicies || [];
      }

      setClaimsList(claimsData);
      setCustomers(customersData);
      setPolicies(policiesData);
      setAgents(agentsData);

      if (showToast) {
        toast.success('Claims data refreshed');
      }
    } catch (error) {
      console.error('Error fetching claims data:', error);
      toast.error('Failed to load claims data');
    } finally {
      setLoading(false);
      if (showToast) setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [currentUser]);

  // get policies available for claim filing based on user role
  const getAvailablePolicies = () => {
    const userData = getCurrentUserData();
    
    if (currentUser?.role === 'user') {
      // customer can file claims for their own policies only
      return policies.filter(policy => policy.customerId === userData?.id);
    } else if (currentUser?.role === 'agent') {
      // agent can file claims for their assigned policies
      //const assignedPolicyIDs = userData?.assignedPolicies || [];
      //return policies.filter(policy => assignedPolicyIDs.includes(policy.id));
      return policies;
    } else if (currentUser?.role === 'admin') {
      // admin can file claims for any policy
      return policies;
    }
    return [];
  };

  // Filter claims based on user role and permissions
  const getVisibleClaims = () => {
    return claimsList; // Already filtered in fetchData
  };

  const filteredClaims = getVisibleClaims().filter(claim => {
    const matchesSearch = claim.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          claim.id?.toString().includes(searchTerm);
    const matchesStatus = statusFilter === 'all' || claim.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleViewClaim = (claim) => {
    setModalMode('view');
    setSelectedClaim(claim);
    setShowModal(true);
  };

  const handleProcessClaim = (claim) => {
    setModalMode('process');
    setSelectedClaim(claim);
    setShowModal(true);
  };

  const handleStatusChange = async (claimId, newStatus, reason = '') => {
    try {
      await claimService.process(claimId, {
        status: newStatus,
        reason: reason
      });

      setClaimsList(prev => {
      const updated = prev.map(claim => {
        if (claim.claimId === claimId) {
          console.log('Updating claim:', claim.claimId, 'from', claim.status, 'to', newStatus);
          return { 
            ...claim, 
            status: newStatus, 
            processedDate: new Date().toISOString().split('T')[0], 
            reason 
          };
        }
        return claim;
      });
      return updated;
    });
      
      setShowModal(false);
      toast.success(`Claim ${newStatus.toLowerCase()} successfully`);
    } catch (error) {
      console.error('Error processing claim:', error);
      toast.error('Failed to process claim');
    }
  };

  const handleFileClaim = async (claimData) => {
    try {
      const newClaim = await claimService.create(claimData);
      setClaimsList(prev => [...prev, newClaim]);
      setShowFilingModal(false);
      toast.success('Claim filed successfully');
    } catch (error) {
      console.error('Error filing claim:', error);
      toast.error('Failed to file claim');
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'APPROVED': return 'bg-green-100 text-green-800';
      case 'REJECTED': return 'bg-red-100 text-red-800';
      case 'UNDER_REVIEW': return 'bg-yellow-100 text-yellow-800';
      case 'FILED': return 'bg-blue-100 text-blue-800';
      case 'PAID': return 'bg-purple-100 text-purple-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'HIGH':
        return 'bg-red-50 text-red-700';
      case 'MEDIUM':
        return 'bg-yellow-50 text-yellow-700';
      case 'LOW':
        return 'bg-green-50 text-green-700';
      default:
        return 'bg-gray-50 text-gray-700';
    }
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Claim Processing</h1>
          <p className="text-gray-600">
            Review and process insurance claims
            {currentUser?.role === 'agent' && (
              <span className="text-sm text-blue-600 ml-2">
                (Only assigned policies visible)
              </span>
            )}
          </p>
        </div>
        <div className="flex items-center space-x-3">
          <button
            onClick={() => fetchData(true)}
            disabled={refreshing}
            className="flex items-center space-x-2 px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors disabled:bg-gray-400"
          >
            <RefreshCw className={`w-4 h-4 ${refreshing ? 'animate-spin' : ''}`} />
            <span>{refreshing ? 'Refreshing...' : 'Refresh'}</span>
          </button>
          <div className="text-sm text-gray-600">
            {currentUser?.role === 'agent' ? 'Assigned Claims' : 'Total Claims'}: <span className="font-semibold">{getVisibleClaims().length}</span>
          </div>
          {(currentUser?.role === 'user' || currentUser?.role === 'agent' || currentUser?.role === 'admin') && (
            <button
              onClick={() => setShowFilingModal(true)}
              className="flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed"
              disabled={getAvailablePolicies().length === 0}
              title={getAvailablePolicies().length === 0 ? 'No policies available for filing claims' : 'File a new insurance claim'}
            >
              <Plus size={16} />
              <span>File New Claim</span>
            </button>
          )}
        </div>
      </div>

      {/* Search and Filters */}
      <div className="bg-white p-6 rounded-xl shadow-sm">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
            <input
              type="text"
              placeholder="Search claims by ID or description..."
              className="w-full pl-10 pr-4 py-3 rounded-lg border border-gray-200 focus:ring-2 focus:ring-blue-500 focus:border-transparent focus:outline-none bg-white transition-all"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 text-gray-600">
              <Filter size={18} />
              <span className="text-sm font-medium">Filter:</span>
            </div>
            <div className="relative">
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="appearance-none bg-white border border-gray-200 rounded-lg px-4 py-3 pr-10 focus:ring-2 focus:ring-blue-500 focus:border-transparent focus:outline-none cursor-pointer hover:border-gray-300 transition-all min-w-[140px]"
              >
                <option value="all">All Status</option>
                <option value="FILED">Filed</option>
                <option value="UNDER_REVIEW">Under Review</option>
                <option value="APPROVED">Approved</option>
                <option value="REJECTED">Rejected</option>
                <option value="PAID">Paid</option>
              </select>
              <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                <svg className="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Claims Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredClaims.map((claim) => (
          <div key={claim.claimId} className="bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow p-6">
            {/* Header */}
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <h3 className="text-lg font-semibold text-gray-900">Claim #{claim.claimId}</h3>
                <div className="flex items-center gap-2 mt-1">
                  <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(claim.status)}`}>
                    {claim.status}
                  </span>
                  {claim.priority && (
                    <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getPriorityColor(claim.priority)}`}>
                      {claim.priority}
                    </span>
                  )}
                  {claim.filedBy && (
                    <span className={`inline-flex items-center px-2 py-1 text-xs font-medium rounded-full ${
                      claim.filedBy === 'customer' ? 'bg-green-100 text-green-700' : 'bg-purple-100 text-purple-700'
                    }`}>
                      {claim.filedBy === 'customer' ? (
                        <>
                          <User size={10} className="mr-1" />
                          Filed by Customer
                        </>
                      ) : (
                        <>
                          <UserCheck size={10} className="mr-1" />
                          Filed by Agent
                        </>
                      )}
                    </span>
                  )}
                </div>
              </div>
            </div>

            {/* Customer & Policy Info */}
            <div className="space-y-3 mb-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center text-sm text-gray-600">
                  <User size={14} className="mr-2 text-purple-600" />
                  <span>Customer</span>
                </div>
                <span className="text-sm font-medium text-gray-900">
                  {customers.find(c => c.id === claim.customerId)?.name || `Customer #${claim.customerId}`}
                </span>
              </div>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center text-sm text-gray-600">
                  <Shield size={14} className="mr-2 text-blue-600" />
                  <span>Policy</span>
                </div>
                <span className="text-sm font-medium text-gray-900">
                  {policies.find(p => p.id === claim.policyId)?.name || `Policy #${claim.policyId}`}
                </span>
              </div>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center text-sm text-gray-600">
                  <DollarSign size={14} className="mr-2 text-green-600" />
                  <span>Claim Amount</span>
                </div>
                <span className="font-semibold text-green-600">₹{claim.claimAmount?.toLocaleString()}</span>
              </div>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center text-sm text-gray-600">
                  <Calendar size={14} className="mr-2 text-orange-600" />
                  <span>Submitted</span>
                </div>
                <span className="text-sm text-gray-900">{claim.createdAt.split("T")[0]}</span>
              </div>
            </div>

            {/* Description */}
            <div className="mb-4 p-3 bg-gray-50 rounded-lg">
              <p className="text-sm text-gray-700 line-clamp-2">{claim.description}</p>
            </div>

            {/* Actions */}
            <div className="flex items-center justify-between pt-4 border-t border-gray-100">
              <div className="text-xs text-gray-500">
                {customers.find(c => c.id === claim.customerId)?.email || `Customer #${claim.customerId}`}
              </div>
              <div className="flex space-x-2">
                <button
                  onClick={() => handleViewClaim(claim)}
                  className="text-blue-600 hover:text-blue-900 p-1 rounded hover:bg-blue-50"
                  title="View Details"
                >
                  <Eye size={16} />
                </button>
                {(claim.status === 'FILED' || claim.status === 'UNDER_REVIEW') && 
                 (currentUser?.role?.toLowerCase() === 'admin') && (
                  <>
                    <button
                      onClick={() => handleProcessClaim(claim)}
                      className="text-gray-600 hover:text-gray-900 p-1 rounded hover:bg-gray-50"
                      title="Process with Reason"
                    >
                      <FileText size={16} />
                    </button>
                  </>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredClaims.length === 0 && (
        <div className="text-center py-12">
          <FileText className="mx-auto h-12 w-12 text-gray-400" />
          <h3 className="mt-2 text-sm font-medium text-gray-900">No claims found</h3>
          <p className="mt-1 text-sm text-gray-500">
            {searchTerm || statusFilter !== 'all' ? 'Try adjusting your search criteria.' : 
             currentUser?.role === 'agent' ? 'No claims found for your assigned policies.' : 'No claims to display.'}
          </p>
          {currentUser?.role === 'agent' && getAvailablePolicies().length === 0 && (
            <p className="mt-2 text-xs text-gray-400">
              You have no assigned policies. Contact your administrator to get policy assignments.
            </p>
          )}
        </div>
      )}

      {/* Modals */}
      {showModal && modalMode === 'process' && selectedClaim && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50 overflow-y-auto scrollbar-hide md:scrollbar-default">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-2xl mx-auto p-6 lg:max-h-[90vh] overflow-y-auto scrollbar-hide md:scrollbar-default">
            
            {/* Header */}
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-semibold text-gray-900">
                Process Claim #{selectedClaim.claimId}
              </h3>
              <button
                onClick={() => setShowModal(false)}
                className="w-8 h-8 rounded-full bg-blue-500 text-white hover:bg-blue-600 transition-colors cursor-pointer"
              >
                ×
              </button>
            </div>

            {/* Content */}
            <form onSubmit={(e) => {
              e.preventDefault();
              const formData = new FormData(e.target);
              const decision = formData.get('decision');
              const reason = formData.get('reason');
              if (decision) {
                handleStatusChange(selectedClaim.claimId, decision, reason);
              }
            }} className="space-y-4">
              
              {/* Claim Details */}
                <div className="p-4 rounded-lg border border-gray-300">
                  <h4 className="font-medium text-gray-900 mb-2">
                    Claim Details
                  </h4>
                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div className="bg-gray-50 p-3 rounded">
                      <label className="text-sm font-medium text-gray-700">Claim Amount</label>
                      <p className="text-sm text-gray-900 font-medium">₹{selectedClaim.claimAmount?.toLocaleString()}</p>
                    </div>
                    <div className="inline-block bg-gray-50 p-3 rounded">
                      <div className="inline-flex flex-col">
                      <label className="text-sm font-medium text-gray-700">Current Status</label>
                      <span className={`px-2 py-1 text-xs text-center font-semibold rounded-full ${getStatusColor(selectedClaim.status)}`}>
                        {selectedClaim.status}
                      </span>
                      </div>
                    </div>
                  </div>
                  <div className="bg-gray-50 p-3 rounded">
                    <label className="text-sm font-medium text-gray-700">Description</label>
                    <p className="text-sm text-gray-900">{selectedClaim.description}</p>
                  </div>
                </div>

                {/* Processing Decision */}
                <div className="p-4 rounded-lg border border-gray-300">
                  <h4 className="font-medium text-gray-900 mb-2">
                    Processing Decision
                  </h4>
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Decision <span className="text-red-500">*</span>
                      </label>
                      <select
                        name="decision"
                        required
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      >
                        <option value="">Select processing decision...</option>
                        <option value="APPROVED">Approve Claim</option>
                        <option value="REJECTED">Reject Claim</option>
                        <option value="UNDER_REVIEW">Mark Under Review</option>
                        <option value="FILED">Mark as Filed</option>
                      </select>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Reason/Comments
                      </label>
                      <textarea
                        name="reason"
                        placeholder="Provide reason for your decision or additional comments..."
                        rows={4}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      />
                    </div>
                  </div>
                </div>

                {/* Role Info */}
                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
                  <div className="flex items-center">
                    <span className="text-yellow-600 mr-2">👤</span>
                    <p className="text-sm text-yellow-800">
                      Processing as: <span className="font-medium">
                        {currentUser?.role === 'user' ? 'Customer' : 
                         currentUser?.role === 'agent' ? 'Agent' : 'Administrator'}
                      </span>
                    </p>
                  </div>
                </div>

              {/* Footer */}
              <div className="flex justify-end space-x-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 cursor-pointer"
                >
                  Process Claim
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* View Modal */}
      {showModal && modalMode === 'view' && selectedClaim && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50 overflow-y-auto scrollbar-hide md:scrollbar-default">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-xl mx-auto lg:max-h-[90vh] overflow-y-auto scrollbar-hide md:scrollbar-default">
            <div className="px-6 pt-6 pb-4 border-b border-gray-100 sticky top-0 bg-white rounded-t-2xl">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-semibold text-gray-900">📋 Claim Details</h3>
                <button
                  onClick={() => setShowModal(false)}
                  className="p-2 rounded-full text-gray-500 hover:bg-gray-100 hover:text-gray-700 transition-colors"
                  aria-label="Close"
                >
                  ×
                </button>
              </div>
            </div>
            <div className="px-6 py-6">
              <div className="space-y-6">
                <div className="p-4 rounded-lg border border-gray-300">
                  <h4 className="font-medium text-gray-900 mb-2">
                    <span className="mr-2">📄</span>
                    Basic Information
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Claim ID</label>
                      <div className="text-sm text-gray-900 font-medium">#{selectedClaim.claimId}</div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
                      <div className="text-sm text-gray-900 font-medium">
                        <span className={`inline-flex px-3 py-1 text-sm font-semibold rounded-full ${getStatusColor(selectedClaim.status)}`}>
                          {selectedClaim.status}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
                 
                 {/* User Information */}
                <div className="p-4 rounded-lg border border-gray-300">
                  <h4 className="font-medium text-gray-900 mb-2">
                    <span className="mr-2">👤</span>
                    Customer Information
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Customer Name</label>
                      <div className="text-sm text-gray-900 font-medium">
                        {getCurrentClaimUser(selectedClaim.customerId).name}
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Customer ID</label>
                      <div className="text-sm text-gray-900 font-medium">#{getCurrentClaimUser(selectedClaim.customerId).customerId}</div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
                      <div className="text-sm text-gray-900 font-medium">
                        {getCurrentClaimUser(selectedClaim.customerId).email}
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Phone Number</label>
                      <div className="text-sm text-gray-900 font-medium">
                        {getCurrentClaimUser(selectedClaim.customerId).phone}
                      </div>
                    </div>
                  </div>
                  {/* Address - Full width */}
                  <div className="mt-4">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Address</label>
                    <div className="text-sm text-gray-900 font-medium bg-gray-50 p-3 rounded-lg">
                      {getCurrentClaimUser(selectedClaim.customerId).address}
                    </div>
                  </div>
                </div>

                <div className="p-4 rounded-lg border border-gray-300">
                  <h4 className="font-medium text-gray-900 mb-2">
                    <span className="mr-2">💰</span>
                    Financial Information
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Claim Amount</label>
                      <div className="text-sm text-gray-900 font-medium">
                        <span className="text-2xl font-bold text-blue-600">₹{selectedClaim.claimAmount?.toLocaleString()}</span>
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Policy ID</label>
                      <div className="text-sm text-gray-900 font-medium">#{selectedClaim.policyId}</div>
                    </div>
                  </div>
                </div>

                <div className="p-4 rounded-lg border border-gray-300">
                  <h4 className="font-medium text-gray-900 mb-2">
                    <span className="mr-2">📝</span>
                    Description
                  </h4>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Claim Description</label>
                    <div className="text-sm text-gray-900 font-medium">
                      <div className="p-3 bg-gray-50 rounded-lg mt-1 leading-relaxed">
                        {selectedClaim.description}
                      </div>
                    </div>
                  </div>
                </div>

                <div className="p-4 rounded-lg border border-gray-300">
                  <h4 className="font-medium text-gray-900 mb-2">
                    <span className="mr-2">📅</span>
                    Timeline & Filing Information
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Date Submitted</label>
                      <div className="text-sm text-gray-900 font-medium">{selectedClaim.createdAt.split("T")[0]}</div>
                    </div>
                    {selectedClaim.filedBy && (
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Filed By</label>
                        <div className="text-sm text-gray-900 font-medium">
                          <div className="flex items-center">
                            {selectedClaim.filedBy === 'customer' ? (
                              <User size={14} className="text-blue-600 mr-2" />
                            ) : (
                              <UserCheck size={14} className="text-blue-600 mr-2" />
                            )}
                            <span className="text-sm font-medium text-gray-900">
                              {selectedClaim.filedBy === 'customer' ? 'Customer' : 
                               selectedClaim.filedBy === 'admin' ? 'Administrator' : 'Agent'}
                              {selectedClaim.filedByName && (
                                <span className="text-gray-600 font-normal"> ({selectedClaim.filedByName})</span>
                              )}
                            </span>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
            <div className="px-6 py-4 border-t border-gray-100">
              <div className="flex justify-end">
                <button
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200 transition-colors"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {showFilingModal && (
        <ClaimFilingModal
          isOpen={showFilingModal}
          onClose={() => setShowFilingModal(false)}
          onSubmit={handleFileClaim}
          currentUser={currentUser}
        />
      )}


    </div>
  );
};

export default ClaimProcessing; 
import React, { useState, useEffect } from 'react';
import { useUser } from '../../context/UserContext';
import { toast } from 'react-hot-toast';
import { User, Mail, Phone, Calendar, MapPin, Shield, Edit2, Save, X, Key, Eye, EyeOff } from 'lucide-react';
import authService from '../../services/authService';
import customerService from '../../services/customerService';
import agentService from '../../services/agentService';

const Profile = () => {
  const { currentUser, updateProfile } = useUser();
  const [isEditing, setIsEditing] = useState(false);
  const [showPasswordSection, setShowPasswordSection] = useState(false);
  const [profileLoading, setProfileLoading] = useState(false);
  const [passwordLoading, setPasswordLoading] = useState(false);
  
  // Profile data with only editable fields
  const [profileData, setProfileData] = useState({
    name: currentUser?.name || '',
    phone: currentUser?.phone || '',
    address: currentUser?.address || ''
  });
  
  const [passwordData, setPasswordData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });

  // Sync profile data when currentUser changes
  useEffect(() => {
    if (currentUser) {
      setProfileData({
        name: currentUser.name || '',
        phone: currentUser.phone || '',
        address: currentUser.address || ''
      });
    }
  }, [currentUser]);

  const handleProfileInputChange = (e) => {
    const { name, value } = e.target;
    setProfileData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handlePasswordInputChange = (e) => {
    const { name, value } = e.target;
    setPasswordData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const validateProfileData = () => {
    if (!profileData.name?.trim()) {
      toast.error('Name is required');
      return false;
    }
    
    if (profileData.name.trim().length < 2) {
      toast.error('Name must be at least 2 characters long');
      return false;
    }

    if (profileData.phone && profileData.phone.replace(/\D/g, '').length !== 10) {
      toast.error('Phone number must be exactly 10 digits');
      return false;
    }

    if (profileData.address && profileData.address.trim().length < 10) {
      toast.error('Address must be at least 10 characters long');
      return false;
    }

    return true;
  };

  const handleProfileSave = async (e) => {
    e.preventDefault();
    
    if (!validateProfileData()) {
      return;
    }

    try {
      setProfileLoading(true);
      
      // Clean phone number (remove non-digits)
      const cleanedData = {
        ...profileData,
        name: profileData.name.trim(),
        phone: profileData.phone,
        address: profileData.address ? profileData.address.trim() : ''
      };

      let updatedProfile;
      
      // Call the appropriate service based on user role
      if (currentUser.role === 'user') {
        updatedProfile = await customerService.updateProfile(cleanedData);
      } else if (currentUser.role === 'agent') {
        updatedProfile = await agentService.updateProfile(cleanedData);
      } else {
        throw new Error('Profile update not supported for this role');
      }
      
      // Update local context
      updateProfile(updatedProfile);
      
      setIsEditing(false);
      toast.success('Profile updated successfully!');
    } catch (error) {
      console.error('Profile update error:', error);
      toast.error(error.message || 'Failed to update profile');
    } finally {
      setProfileLoading(false);
    }
  };

  const validatePasswordData = () => {
    if (!passwordData.currentPassword) {
      toast.error('Current password is required');
      return false;
    }

    if (!passwordData.newPassword) {
      toast.error('New password is required');
      return false;
    }

    if (passwordData.newPassword.length < 6) {
      toast.error('New password must be at least 6 characters long');
      return false;
    }

    if (passwordData.newPassword !== passwordData.confirmPassword) {
      toast.error('New passwords do not match');
      return false;
    }

    if (passwordData.currentPassword === passwordData.newPassword) {
      toast.error('New password must be different from current password');
      return false;
    }

    return true;
  };

  const handlePasswordReset = async (e) => {
    e.preventDefault();
    
    if (!validatePasswordData()) {
      return;
    }

    try {
      setPasswordLoading(true);
      
      await authService.resetPassword({
        currentPassword: passwordData.currentPassword,
        newPassword: passwordData.newPassword
      });
      
      toast.success('Password updated successfully!');
      setPasswordData({
        currentPassword: '',
        newPassword: '',
        confirmPassword: ''
      });
      setShowPasswordSection(false);
    } catch (error) {
      console.error('Password reset error:', error);
      toast.error(error.message || 'Failed to update password');
    } finally {
      setPasswordLoading(false);
    }
  };

  const handleCancelEdit = () => {
    setIsEditing(false);
    // Reset to current user data
    setProfileData({
      name: currentUser?.name || '',
      phone: currentUser?.phone || '',
      address: currentUser?.address || ''
    });
  };

  const getRoleColor = (role) => {
    switch (role) {
      case 'admin':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'agent':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'user':
        return 'bg-green-100 text-green-800 border-green-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };


  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="bg-white rounded-2xl shadow-sm border border-gray-200">
        {/* Header */}
        <div className="px-6 pt-6 pb-4 border-b border-gray-100">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white text-2xl font-bold">
                {currentUser?.name?.charAt(0)?.toUpperCase() || 'U'}
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
                  👤 My Profile
                </h1>
                <p className="text-gray-600">Manage your account information and security settings</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium border ${getRoleColor(currentUser?.role)}`}>
                 {currentUser?.role?.charAt(0)?.toUpperCase() + currentUser?.role?.slice(1)}
              </span>
              {!isEditing ? (
                <button
                  onClick={() => setIsEditing(true)}
                  disabled={currentUser?.role === 'admin'}
                  className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-all disabled:bg-gray-400 disabled:cursor-not-allowed"
                  title={currentUser?.role === 'admin' ? 'Admin profile editing not supported' : 'Edit Profile'}
                >
                  <Edit2 size={16} />
                  Edit Profile
                </button>
              ) : (
                <div className="flex gap-2">
                  <button
                    onClick={handleCancelEdit}
                    className="flex items-center gap-2 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-all"
                  >
                    <X size={16} />
                    Cancel
                  </button>
                  <button
                    onClick={handleProfileSave}
                    disabled={profileLoading}
                    className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-all disabled:bg-green-400"
                  >
                    <Save size={16} />
                    {profileLoading ? 'Saving...' : 'Save Changes'}
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="p-6 space-y-6">
          {/* Personal Information */}
          <div className="p-6 rounded-xl bg-blue-50 border border-blue-100">
            <h3 className="text-lg font-semibold text-blue-900 mb-4 flex items-center gap-2">
              👤 Personal Information
            </h3>
            <form onSubmit={handleProfileSave} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Name - Editable */}
                <div>
                  <label className="block text-sm font-medium text-blue-800">
                    Full Name {isEditing && <span className="text-red-500">*</span>}
                  </label>
                  {isEditing ? (
                    <input
                      type="text"
                      name="name"
                      value={profileData.name}
                      onChange={handleProfileInputChange}
                      className="mt-1 block w-full rounded-lg border border-blue-200 px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white transition-all"
                      placeholder="Enter your full name"
                      required
                      minLength={2}
                      maxLength={100}
                    />
                  ) : (
                    <p className="mt-1 text-sm text-blue-900 font-medium flex items-center gap-2">
                      <User size={16} />
                      {currentUser?.name || 'Not provided'}
                    </p>
                  )}
                </div>

                {/* Email - Read Only */}
                <div>
                  <label className="block text-sm font-medium text-blue-800">Email Address</label>
                  <p className="mt-1 text-sm text-blue-900 flex items-center gap-2">
                    <Mail size={16} />
                    {currentUser?.email || 'Not provided'}
                    <span className="text-xs text-gray-500 ml-2">(Cannot be changed)</span>
                  </p>
                </div>

                {/* Phone - Editable */}
                <div>
                  <label className="block text-sm font-medium text-blue-800">Phone Number</label>
                  {isEditing ? (
                    <input
                      type="tel"
                      name="phone"
                      value={profileData.phone}
                      onChange={handleProfileInputChange}
                      className="mt-1 block w-full rounded-lg border border-blue-200 px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white transition-all"
                      placeholder="1234567890"
                      pattern="[0-9]{10}"
                      maxLength={10}
                    />
                  ) : (
                    <p className="mt-1 text-sm text-blue-900 flex items-center gap-2">
                      <Phone size={16} />
                      {currentUser?.phone}
                    </p>
                  )}
                  {isEditing && (
                    <p className="text-xs text-gray-500 mt-1">Enter 10-digit phone number</p>
                  )}
                </div>

                {/* Role - Read Only */}
                <div>
                  <label className="block text-sm font-medium text-blue-800">Account Type</label>
                  <p className="mt-1 text-sm text-blue-900 flex items-center gap-2">
                    <Shield size={16} />
                    {currentUser?.role?.charAt(0)?.toUpperCase() + currentUser?.role?.slice(1)}
                  </p>
                </div>
              </div>

              {/* Address - Editable, Full Width */}
              <div>
                <label className="block text-sm font-medium text-blue-800">Address</label>
                {isEditing ? (
                  <textarea
                    name="address"
                    value={profileData.address}
                    onChange={handleProfileInputChange}
                    rows="3"
                    className="mt-1 block w-full rounded-lg border border-blue-200 px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white transition-all resize-none"
                    placeholder="Enter your full address..."
                    minLength={10}
                    maxLength={200}
                  />
                ) : (
                  <p className="mt-1 text-sm text-blue-900 flex items-start gap-2">
                    <MapPin size={16} className="mt-0.5" />
                    {currentUser?.address || 'Not provided'}
                  </p>
                )}
                {isEditing && (
                  <p className="text-xs text-gray-500 mt-1">Minimum 10 characters</p>
                )}
              </div>
            </form>
          </div>

          {/* Security Settings */}
          {currentUser?.role !== 'admin' && (
            <div className="p-6 rounded-xl bg-purple-50 border border-purple-100">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-purple-900 flex items-center gap-2">
                  🔒 Security Settings
                </h3>
                <button
                  onClick={() => setShowPasswordSection(!showPasswordSection)}
                  className="flex items-center gap-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-all"
                >
                  <Key size={16} />
                  {showPasswordSection ? 'Hide' : 'Change Password'}
                </button>
              </div>

              {showPasswordSection && (
                <form onSubmit={handlePasswordReset} className="space-y-4 bg-white p-6 rounded-lg border border-purple-200">
                  <div>
                    <label className="block text-sm font-medium text-purple-800 mb-2">
                      Current Password <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="password"
                      name="currentPassword"
                      value={passwordData.currentPassword}
                      onChange={handlePasswordInputChange}
                      placeholder="Enter current password"
                      className="w-full rounded-lg border border-purple-200 px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent bg-white transition-all"
                      required
                    />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-purple-800 mb-2">
                        New Password <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="password"
                        name="newPassword"
                        value={passwordData.newPassword}
                        onChange={handlePasswordInputChange}
                        placeholder="Enter new password"
                        className="w-full rounded-lg border border-purple-200 px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent bg-white transition-all"
                        required
                        minLength={6}
                      />
                      <p className="text-xs text-purple-600 mt-1">Minimum 6 characters</p>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-purple-800 mb-2">
                        Confirm New Password <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="password"
                        name="confirmPassword"
                        value={passwordData.confirmPassword}
                        onChange={handlePasswordInputChange}
                        placeholder="Confirm new password"
                        className="w-full rounded-lg border border-purple-200 px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent bg-white transition-all"
                        required
                        minLength={6}
                      />
                    </div>
                  </div>
                  
                  <div className="flex justify-end gap-3 pt-4">
                    <button
                      type="button"
                      onClick={() => {
                        setShowPasswordSection(false);
                        setPasswordData({
                          currentPassword: '',
                          newPassword: '',
                          confirmPassword: ''
                        });
                      }}
                      className="px-6 py-2.5 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-all font-medium"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={passwordLoading}
                      className="px-6 py-2.5 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-all font-medium shadow-lg hover:shadow-xl disabled:bg-purple-400"
                    >
                      {passwordLoading ? (
                        <span className="flex items-center gap-2">
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                          Updating...
                        </span>
                      ) : (
                        '🔐 Update Password'
                      )}
                    </button>
                  </div>
                </form>
              )}

              {!showPasswordSection && (
                <div className="bg-white p-4 rounded-lg border border-purple-200">
                  <p className="text-sm text-purple-700 flex items-center gap-2">
                    <Shield size={16} />
                    Your password is secure and encrypted.
                  </p>
                </div>
              )}
            </div>
          )}

          {/* Admin Notice */}
          {currentUser?.role === 'admin' && (
            <div className="p-4 rounded-xl bg-yellow-50 border border-yellow-200">
              <p className="text-sm text-yellow-800 flex items-center gap-2">
                <Shield size={16} />
                Admin accounts have limited profile editing capabilities for security reasons.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Profile; 
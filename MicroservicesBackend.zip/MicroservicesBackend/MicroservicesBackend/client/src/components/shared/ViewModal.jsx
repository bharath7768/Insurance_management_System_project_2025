import React from 'react';

const ViewModal = ({ 
  isOpen, 
  onClose, 
  title, 
  children,
  size = 'max-w-2xl'
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50 overflow-y-auto scrollbar-hide md:scrollbar-default">
      <div className={`bg-white rounded-2xl shadow-xl w-full ${size} mx-auto lg:max-h-[90vh] overflow-y-auto scrollbar-hide md:scrollbar-default`}>
        <div className="px-6 pt-6 pb-4 border-b border-gray-100 sticky top-0 bg-white rounded-t-2xl">
          <div className="flex items-center justify-between">
            <h3 className="text-xl font-semibold text-gray-900">{title}</h3>
            <button
              onClick={onClose}
              className="p-2 rounded-full text-gray-500 hover:bg-gray-100 hover:text-gray-700 transition-colors"
              aria-label="Close"
            >
              ×
            </button>
          </div>
        </div>
        <div className="px-6 py-6">
          <div className="space-y-6">
            {children}
          </div>
        </div>
        <div className="px-6 py-4 border-t border-gray-100">
          <div className="flex justify-end">
            <button
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200 transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

// Reusable section components for consistent styling
export const ViewSection = ({ 
  title, 
  icon, 
  children
}) => (
  <div className="p-4 rounded-lg border border-gray-300">
    <h4 className="font-medium text-gray-900 mb-2">
      {icon && <span className="mr-2">{icon}</span>}
      {title}
    </h4>
    {children}
  </div>
);

export const ViewField = ({ 
  label, 
  value
}) => (
  <div>
    <label className="block text-sm font-medium text-gray-700 mb-1">
      {label}
    </label>
    <div className="text-sm text-gray-900 font-medium">
      {value}
    </div>
  </div>
);

export const ViewGrid = ({ children, cols = 2 }) => (
  <div className={`grid grid-cols-1 md:grid-cols-${cols} gap-4`}>
    {children}
  </div>
);

export default ViewModal; 
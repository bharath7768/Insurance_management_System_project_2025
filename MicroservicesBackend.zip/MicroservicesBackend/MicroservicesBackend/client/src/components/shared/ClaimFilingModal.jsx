import { useState, useEffect } from 'react';
import { User, UserCheck, ArrowLeft, ArrowRight } from 'lucide-react';
import { customerService, policyService, agentService, claimService } from '../../services/index.js';
import CustomerSelector from './CustomerSelector';
import PolicySelector from './PolicySelector';
import toast from 'react-hot-toast';

const ClaimFilingModal = ({ 
  isOpen, 
  onClose, 
  onSubmit, 
  currentUser 
}) => {
  const [currentStep, setCurrentStep] = useState(1);
  const [selectedCustomerId, setSelectedCustomerId] = useState('');
  const [selectedPolicyId, setSelectedPolicyId] = useState('');
  const [claimAmount, setClaimAmount] = useState('');
  const [description, setDescription] = useState('');
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const [policiesLoading, setPoliciesLoading] = useState(false);
  const [availablePolicies, setAvailablePolicies] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [remainingCoverageInfo, setRemainingCoverageInfo] = useState(null);
  const [coverageLoading, setCoverageLoading] = useState(false);

  // Fetch customers when modal opens
  useEffect(() => {
    if (isOpen && currentUser) {
      fetchCustomers();
    }
  }, [isOpen, currentUser]);

  // Fetch policies when customer is selected
  useEffect(() => {
    if (selectedCustomerId) {
      fetchPoliciesForCustomer(selectedCustomerId);
    } else {
      setAvailablePolicies([]);
      setSelectedPolicyId('');
    }
  }, [selectedCustomerId, currentUser]);

  // Fetch remaining coverage when policy is selected
  useEffect(() => {
    if (selectedPolicyId) {
      fetchRemainingCoverage(selectedPolicyId);
    } else {
      setRemainingCoverageInfo(null);
    }
  }, [selectedPolicyId]);

  // Reset form when modal opens/closes
  useEffect(() => {
    if (isOpen) {
      setCurrentStep(1);
      setSelectedCustomerId('');
      setSelectedPolicyId('');
      setClaimAmount('');
      setDescription('');
      setErrors({});
      setRemainingCoverageInfo(null);
    }
  }, [isOpen]);

  const fetchCustomers = async () => {
    try {
      setLoading(true);
      let customersData = [];

      if (currentUser?.role === 'user') {
        // Customer can only file for themselves
        const customerProfile = await customerService.getProfile();
        customersData = [customerProfile];
        setSelectedCustomerId(customerProfile.customerId); // Auto-select for customers
      } else if (currentUser?.role === 'agent') {
        // Agent sees customers with policies assigned to them
        const agentProfile = await agentService.getProfile();
        const allCustomers = await customerService.getAll();
        const allPolicies = await policyService.getByAgent(agentProfile.agentId);
        
        // Filter customers who have policies assigned to this agent
        const agentPolicies = allPolicies.filter(policy => policy.agentId === agentProfile.agentId);
        const customerIds = [...new Set(agentPolicies.map(policy => policy.customerId))];
        customersData = allCustomers.filter(customer => customerIds.includes(customer.customerId));
      } else if (currentUser?.role === 'admin') {
        // Admin can file for any customer
        customersData = await customerService.getAll();
      }

      setCustomers(customersData || []);
    } catch (error) {
      console.error('Error fetching customers:', error);
      toast.error('Failed to load customers');
    } finally {
      setLoading(false);
    }
  };

  const fetchPoliciesForCustomer = async (customerId) => {
    try {
      setPoliciesLoading(true);
      let policiesData = [];

      if (currentUser?.role === 'user') {
        // Customer's own policies
        console.log(await policyService.getByCustomer(customerId));
        policiesData = await policyService.getByCustomer(customerId);
      } else if (currentUser?.role === 'agent') {
        // Agent can only see policies assigned to them for this customer
        const agentProfile = await agentService.getProfile();
        const customerPolicies = await policyService.getByCustomer(customerId);
        policiesData = customerPolicies.filter(policy => policy.agentId === agentProfile.agentId);
      } else if (currentUser?.role === 'admin') {
        // Admin can see all policies for this customer
        policiesData = await policyService.getByCustomer(customerId);
      }

      setAvailablePolicies(policiesData || []);
    } catch (error) {
      console.error('Error fetching policies:', error);
      toast.error('Failed to load policies for selected customer');
    } finally {
      setPoliciesLoading(false);
    }
  };

  const fetchRemainingCoverage = async (policyId) => {
    try {
      setCoverageLoading(true);
      const coverageInfo = await claimService.getRemainingCoverage(policyId);
      setRemainingCoverageInfo(coverageInfo);
    } catch (error) {
      console.error('Error fetching remaining coverage:', error);
      // Don't show error toast as this is supplementary information
    } finally {
      setCoverageLoading(false);
    }
  };

  const selectedPolicy = availablePolicies.find(p => String(p.policyId || p.id) === String(selectedPolicyId));
  const selectedCustomer = customers.find(c => String(c.customerId || c.id) === String(selectedCustomerId));

  const validateStep1 = () => {
    if (!selectedCustomerId) {
      toast.error('Please select a customer');
      return false;
    }
    return true;
  };

  const validateStep2 = () => {
    if (!selectedPolicyId) {
      toast.error('Please select a policy');
      return false;
    }
    return true;
  };

  const validateStep3 = () => {
    const newErrors = {};
    
    if (!claimAmount || parseFloat(claimAmount) <= 0) {
      newErrors.amount = 'Enter valid amount';
    } else {
      // Check against remaining coverage if available
      if (remainingCoverageInfo && parseFloat(claimAmount) > remainingCoverageInfo.remainingCoverage) {
        newErrors.amount = `Exceeds remaining coverage of ₹${remainingCoverageInfo.remainingCoverage?.toLocaleString()}`;
      } else if (selectedPolicy && parseFloat(claimAmount) > selectedPolicy.coverageAmount) {
        // Fallback to original validation if coverage info not available
        newErrors.amount = `Exceeds coverage limit of ₹${selectedPolicy.coverageAmount?.toLocaleString()}`;
      }
    }
    
    if (!description.trim()) {
      newErrors.description = 'Description required';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNext = () => {
    if (currentStep === 1 && validateStep1()) {
      setCurrentStep(2);
    } else if (currentStep === 2 && validateStep2()) {
      setCurrentStep(3);
    }
  };

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
      setErrors({});
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validateStep3()) {
      const claimData = {
        policyId: parseInt(selectedPolicyId),
        customerId: parseInt(selectedCustomerId),
        claimAmount: parseFloat(claimAmount),
        description: description.trim(),
        agentId: selectedPolicy?.agentId || null // Auto-assign from policy
      };
      
      onSubmit(claimData);
      
      // Reset form
      setCurrentStep(1);
      setSelectedCustomerId('');
      setSelectedPolicyId('');
      setClaimAmount('');
      setDescription('');
      setErrors({});
      
      toast.success('Claim filed successfully!');
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50 overflow-y-auto scrollbar-hide md:scrollbar-default">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-xl mx-auto p-6 lg:max-h-[90vh] overflow-y-auto scrollbar-hide md:scrollbar-default">
        {/* Header with Step Indicator */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="text-xl font-semibold text-gray-900">File New Claim</h3>
            <div className="flex items-center mt-2">
              {[1, 2, 3].map((step) => (
                <div key={step} className="flex items-center">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                    currentStep >= step 
                      ? 'bg-blue-600 text-white' 
                      : 'bg-gray-200 text-gray-600'
                  }`}>
                    {step}
                  </div>
                  {step < 3 && (
                    <div className={`w-16 h-0.5 ${
                      currentStep > step ? 'bg-blue-600' : 'bg-gray-200'
                    }`} />
                  )}
                </div>
              ))}
            </div>
            <p className="text-sm text-gray-600 mt-1">
              {currentStep === 1 && 'Select Customer'}
              {currentStep === 2 && 'Choose Policy'}
              {currentStep === 3 && 'Claim Details'}
            </p>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-blue-500 text-white hover:bg-blue-600 transition-colors"
          >
            ×
          </button>
        </div>

        {/* Step Content */}
        <div className="min-h-[400px]">
          {/* Step 1: Customer Selection */}
          {currentStep === 1 && (
            <div className="space-y-6">
              <CustomerSelector
                customers={customers}
                selectedCustomerId={selectedCustomerId}
                onCustomerSelect={setSelectedCustomerId}
                currentUser={currentUser}
                loading={loading}
              />
              
              {/* Navigation */}
              <div className="flex justify-end space-x-3 pt-4 ">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200"
                >
                  Cancel
                </button>
                <button
                  onClick={handleNext}
                  disabled={!selectedCustomerId}
                  className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 disabled:bg-blue-400 disabled:cursor-not-allowed flex items-center"
                >
                  Next
                  <ArrowRight className="w-4 h-4 ml-1" />
                </button>
              </div>
            </div>
          )}

          {/* Step 2: Policy Selection */}
          {currentStep === 2 && (
            <div className="space-y-6">
              {(selectedCustomer || selectedCustomerId) && (
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h4 className="font-medium text-blue-900 mb-2">Selected Customer</h4>
                  <div className="flex items-center">
                    <User className="w-5 h-5 text-blue-600 mr-3" />
                    <div>
                      <p className="font-medium text-blue-900">
                        {selectedCustomer?.name || `Customer ID: ${selectedCustomerId}`}
                      </p>
                      {selectedCustomer?.email && (
                        <p className="text-sm text-blue-700">{selectedCustomer.email}</p>
                      )}
                    </div>
                  </div>
                </div>
              )}
              
              <PolicySelector
                policies={availablePolicies}
                selectedPolicyId={selectedPolicyId}
                onPolicySelect={setSelectedPolicyId}
                loading={policiesLoading}
              />
              
              {/* Navigation */}
              <div className="flex justify-between pt-4">
                <button
                  onClick={handleBack}
                  className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200 flex items-center"
                >
                  <ArrowLeft className="w-4 h-4 mr-1" />
                  Back
                </button>
                <button
                  onClick={handleNext}
                  disabled={!selectedPolicyId}
                  className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 disabled:bg-blue-400 disabled:cursor-not-allowed flex items-center"
                >
                  Next
                  <ArrowRight className="w-4 h-4 ml-1" />
                </button>
              </div>
            </div>
          )}

          {/* Step 3: Claim Details */}
          {currentStep === 3 && (
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Summary */}
              <div className="bg-green-50 p-4 rounded-lg">
                <h4 className="font-medium text-green-900 mb-3">Claim Summary</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="font-medium text-green-800">Customer:</span>
                    <p className="text-green-700">
                      {selectedCustomer?.name || `Customer ID: ${selectedCustomerId}`}
                    </p>
                    {selectedCustomer?.email && (
                      <p className="text-xs text-green-600">{selectedCustomer.email}</p>
                    )}
                  </div>
                  <div>
                    <span className="font-medium text-green-800">Policy:</span>
                    <p className="text-green-700">
                      {selectedPolicy?.name || `Policy ID: ${selectedPolicyId}`}
                    </p>
                    {selectedPolicy?.type && (
                      <p className="text-xs text-green-600">{selectedPolicy.type}</p>
                    )}
                  </div>
                  <div>
                    <span className="font-medium text-green-800">Premium Amount:</span>
                    <p className="text-green-700">
                      {selectedPolicy?.premiumAmount 
                        ? `₹${selectedPolicy.premiumAmount.toLocaleString()}` 
                        : 'Loading...'
                      }
                    </p>
                  </div>
                  <div>
                    <span className="font-medium text-green-800">Total Coverage:</span>
                    <p className="text-green-700">
                      {selectedPolicy?.coverageAmount 
                        ? `₹${selectedPolicy.coverageAmount.toLocaleString()}` 
                        : 'Loading...'
                      }
                    </p>
                  </div>
                  <div>
                    <span className="font-medium text-green-800">Remaining Coverage:</span>
                    <p className="text-green-700">
                      {coverageLoading ? 'Loading...' : (
                        remainingCoverageInfo 
                          ? `₹${remainingCoverageInfo.remainingCoverage.toLocaleString()}` 
                          : 'Calculating...'
                      )}
                    </p>
                    {remainingCoverageInfo && remainingCoverageInfo.existingClaimsCount > 0 && (
                      <p className="text-xs text-green-600">
                        {remainingCoverageInfo.existingClaimsCount} existing claim(s): ₹{remainingCoverageInfo.totalExistingClaims.toLocaleString()}
                      </p>
                    )}
                  </div>
                  <div>
                    <span className="font-medium text-green-800">Agent:</span>
                    <p className="text-green-700">
                      {selectedPolicy?.agentId ? `Agent ID: ${selectedPolicy.agentId}` : 'Not assigned'}
                    </p>
                  </div>
                </div>
                

              </div>

              {/* Claim Amount */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Claim Amount <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">₹</span>
                  <input
                    type="number"
                    value={claimAmount}
                    onChange={(e) => setClaimAmount(e.target.value)}
                    className={`w-full pl-8 pr-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                      errors.amount ? 'border-red-300' : 'border-gray-300'
                    }`}
                    placeholder="Enter claim amount"
                    min="1"
                    step="1"
                  />
                </div>
                {errors.amount && <p className="text-red-500 text-xs mt-1">{errors.amount}</p>}
                {remainingCoverageInfo && (
                  <div className="text-xs text-gray-600 mt-1 space-y-1">
                    <p>
                      Available coverage: ₹{remainingCoverageInfo.remainingCoverage.toLocaleString()} 
                      {remainingCoverageInfo.existingClaimsCount > 0 && (
                        <span className="text-orange-600">
                          {' '}(₹{remainingCoverageInfo.totalExistingClaims.toLocaleString()} already claimed)
                        </span>
                      )}
                    </p>
                    {remainingCoverageInfo.remainingCoverage <= 0 && (
                      <p className="text-red-600 font-medium">
                        ⚠️ No remaining coverage - policy limit reached
                      </p>
                    )}
                  </div>
                )}
              </div>

              {/* Description */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Claim Description <span className="text-red-500">*</span>
                </label>
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  rows="4"
                  className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                    errors.description ? 'border-red-300' : 'border-gray-300'
                  }`}
                  placeholder="Describe the incident or reason for this claim..."
                />
                {errors.description && <p className="text-red-500 text-xs mt-1">{errors.description}</p>}
              </div>

              <div className="text-sm text-indigo-800 mb-4 bg-indigo-100 p-2 rounded-md w-fit">
                Filing as: <span className="font-medium">
                {currentUser?.role === 'user' ? 'Customer' : 
                 currentUser?.role === 'agent' ? 'Agent' : 'Administrator'}
                </span>
              </div>

              {/* Navigation */}
              <div className="flex justify-between pt-4">
                <button
                  type="button"
                  onClick={handleBack}
                  className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200 flex items-center"
                >
                  <ArrowLeft className="w-4 h-4 mr-1" />
                  Back
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-sm font-medium text-white bg-green-600 rounded-md hover:bg-green-700"
                >
                  File Claim
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};

export default ClaimFilingModal; 
import { Link, useLocation } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { 
  Home, 
  Users, 
  FileText, 
  ClipboardCheck, 
  UserCheck, 
  Bell,
  LogOut,User,Settings,ChevronDown
} from 'lucide-react';
import { notificationService } from '../../services/index.js';

const Navbar = ({ currentUser, onLogout }) => {
  const location = useLocation();
  const [showProfileDropdown, setShowProfileDropdown] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);
  
  //= empty then not render
  if (!currentUser) {
    return null;
  }
  
  // user initials for the avatar
  const getUserInitials = () => {
    const name = currentUser.name || currentUser.email || 'User';
    return name.split(' ').map(n => n[0]).join('').toUpperCase().substring(0, 2);
  };

  // for the name display
  const getDisplayName = () => {
    return currentUser.name || currentUser.email || 'User';
  };

  // Fetch unread notification count from backend  
  const fetchUnreadCount = async () => {
    try {
      const count = await notificationService.getMyUnreadCount();
      setUnreadCount(count);
    } catch (error) {
      console.error('Error fetching unread notifications count:', error);
      // Silently fail - don't show error to user for notifications
      setUnreadCount(0);
    }
  };

  // Fetch unread count on component mount and when user changes
  useEffect(() => {
    if (currentUser) {
      fetchUnreadCount();
      
      // Temporarily disabled polling
      // const interval = setInterval(fetchUnreadCount, 30000);
      // return () => clearInterval(interval);
    }
  }, [currentUser]);
  
  // role based navigation one can see their part only
  const getNavigationItems = () => {
    if (currentUser.role === 'user') {
      return [
        { path: '/user-dashboard', label: 'My Dashboard', icon: Home }
      ];
    } else if (currentUser.role === 'agent') {
      return [
        { path: '/agent-dashboard', label: 'Agent Dashboard', icon: Home },
        { path: '/claims', label: 'Claims', icon: ClipboardCheck }
      ];
    } else {
      // Admin role - full access
      return [
        { path: '/', label: 'Dashboard', icon: Home },
        { path: '/customers', label: 'Customers', icon: Users },
        { path: '/policies', label: 'Policies', icon: FileText },
        { path: '/claims', label: 'Claims', icon: ClipboardCheck },
        { path: '/agents', label: 'Agents', icon: UserCheck }
      ];
    }
  };

  const navigationItems = getNavigationItems();


  // used for navigation highlighting
  // for the navigation items 
  const isActive = (path) => location.pathname === path;

  // Close dropdown when clicking outside
  const handleClickOutside = (e) => {
    if (!e.target.closest('.profile-dropdown')) {
      setShowProfileDropdown(false);
    }
  };

  const handleLogout = () => {
    setShowProfileDropdown(false);
    if (onLogout) {
      onLogout();
    }
  };

  // adds an event listener to the entire document
  // every click anywhere on the page will trigger handleClickOutside
  // this is why we can detect clicks outside the dropdown
  useEffect(() => {
    document.addEventListener('click', handleClickOutside);
    return () => document.removeEventListener('click', handleClickOutside);
  }, []);

  return (
    <nav className="bg-blue-900 text-white shadow-lg">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-8">
            <div className="flex-shrink-0">
              <h1 className="text-xl font-bold">Insurance MS</h1>
            </div>
            <div className="hidden md:block">
              {/* navigation items */}
              <div className="ml-10 flex items-baseline space-x-4">
                {navigationItems.map((item) => {
                  const Icon = item.icon;
                  return (
                    <Link
                      key={item.path}
                      to={item.path}
                      className={`px-3 py-2 rounded-md text-sm font-medium transition-colors duration-200 flex items-center space-x-2 ${
                        isActive(item.path)
                          ? 'bg-blue-700 text-white'
                          : 'text-blue-100 hover:bg-blue-700 hover:text-white'
                      }`}
                    >
                      <Icon size={18} />
                      <span>{item.label}</span>
                    </Link>
                  );
                })}
              </div>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            {/* notifications */}
            <Link 
              to="/notifications"
              className="relative p-2 rounded-md text-blue-100 hover:bg-blue-700 hover:text-white transition-colors duration-200"
              title={`${unreadCount} unread notifications`}
              onClick={fetchUnreadCount} // Refresh count when clicked
            >
              <Bell size={18} />
              {/* notification badge - only show if there are unread notifications */}
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-4 w-4 flex items-center justify-center text-[10px]">
                  {unreadCount > 9 ? '9+' : unreadCount}
                </span>
              )}
            </Link>

            {/* profile dropdown */}
            <div className="relative profile-dropdown">
              <button
                onClick={() => setShowProfileDropdown(!showProfileDropdown)}
                className="flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium text-blue-100 hover:bg-blue-700 hover:text-white transition-colors duration-200"
              >
                {/* Profile Avatar */}
                <div className="w-7 h-7 bg-blue-300 rounded-full flex items-center justify-center">
                <span className="text-blue-900 font-bold text-xs">
                      {(currentUser.name || 'User').split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2)}
                </span>
                </div>
                <span className="hidden lg:block text-sm">{currentUser.name || currentUser.email || 'User'}</span>
                <ChevronDown size={14} className={`transition-transform duration-200 ${showProfileDropdown ? 'rotate-180' : ''}`} />
              </button>

              {/* dropdown menu */}
              {showProfileDropdown && (
                <div className="absolute right-0 mt-2 w-56 bg-white rounded-xl shadow-sm backdrop-blur-sm z-50">
                  <div className="py-2">
                    {/* User Info */}
                    <div className="px-4 py-3 border-b border-gray-100">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center shadow-sm">
                          <span className="text-white font-bold text-sm">
                            {getUserInitials()}
                          </span>
                        </div>
                        <div>
                          <p className="text-sm font-semibold text-gray-900">{getDisplayName()}</p>
                          <p className="text-xs text-gray-500 capitalize bg-gray-100 px-2 py-1 rounded-full inline-block">
                            {currentUser.role}
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* menu items */}
                    <div className="py-2">
                      <Link 
                        to="/profile"
                        className="flex items-center space-x-3 w-full px-4 py-2 text-sm text-gray-700 hover:bg-blue-50 hover:text-blue-700 transition-colors"
                        onClick={() => setShowProfileDropdown(false)}
                      >
                        <User size={16} className="text-gray-400" />
                        <span>View Profile</span>
                      </Link>
                      <Link 
                        to="/notifications"
                        className="flex items-center space-x-3 w-full px-4 py-2 text-sm text-gray-700 hover:bg-blue-50 hover:text-blue-700 transition-colors"
                        onClick={() => {
                          setShowProfileDropdown(false);
                          fetchUnreadCount(); // Refresh count when navigating to notifications
                        }}
                      >
                        <Bell size={16} className="text-gray-400" />
                        <span>Notifications</span>
                        {unreadCount > 0 && (
                          <span className="ml-auto bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                            {unreadCount > 9 ? '9+' : unreadCount}
                          </span>
                        )}
                      </Link>
                     
                     {/* role-specific options */}
                      {currentUser.role === 'user' && (
                        <Link 
                          to="/user-dashboard"
                          className="flex items-center space-x-3 w-full px-4 py-2 text-sm text-gray-700 hover:bg-blue-50 hover:text-blue-700 transition-colors"
                          onClick={() => setShowProfileDropdown(false)}
                        >
                          <Home size={16} className="text-gray-400" />
                          <span>My Dashboard</span>
                        </Link>
                      )}
                      
                      {currentUser.role === 'agent' && (
                        <Link 
                          to="/agent-dashboard"
                          className="flex items-center space-x-3 w-full px-4 py-2 text-sm text-gray-700 hover:bg-blue-50 hover:text-blue-700 transition-colors"
                          onClick={() => setShowProfileDropdown(false)}
                        >
                          <Home size={16} className="text-gray-400" />
                          <span>Agent Dashboard</span>
                        </Link>
                      )}
                      
                      {currentUser.role === 'admin' && (
                        <Link 
                          to="/"
                          className="flex items-center space-x-3 w-full px-4 py-2 text-sm text-gray-700 hover:bg-blue-50 hover:text-blue-700 transition-colors"
                          onClick={() => setShowProfileDropdown(false)}
                        >
                          <Home size={16} className="text-gray-400" />
                          <span>Admin Dashboard</span>
                        </Link>
                      )}
                   </div>

                    {/* logout */}
                    <div className="border-t border-gray-100 py-2">
                      <button 
                        onClick={() => {
                          handleLogout();
                        }}
                        className="flex items-center space-x-3 w-full px-4 py-2 text-sm text-red-600 hover:bg-red-50 hover:text-red-700 transition-colors font-medium"
                        type="button"
                      >
                        <LogOut size={16} className="text-red-500" />
                        <span>Sign Out</span>
                      </button>
                    </div>
                 </div>
               </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar; 
import { useState, useEffect } from 'react';
import { User, Search } from 'lucide-react';

const CustomerSelector = ({ 
  customers, 
  selectedCustomerId, 
  onCustomerSelect, 
  currentUser,
  loading = false,
  error = null 
}) => {
  const [searchTerm, setSearchTerm] = useState('');

  // Early return if customers data is not ready
  if (!Array.isArray(customers)) {
    return (
      <div className="space-y-4">
        <label className="block text-sm font-medium text-gray-700">
          Select Customer <span className="text-red-500">*</span>
        </label>
        <div className="w-full px-3 py-3 border border-gray-300 rounded-lg bg-gray-50">
          <div className="flex items-center justify-center">
            <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-blue-600"></div>
            <span className="ml-2 text-gray-600">Loading customers...</span>
          </div>
        </div>
      </div>
    );
  }

  // Helper function to safely get customers array and length
  const safeCustomers = customers || [];
  const customersLength = safeCustomers.length;

  // Helper function to get customer ID (handles field name differences)
  const getCustomerId = (customer) => {
    if (!customer) return null;
    return customer.customerId || customer.id;
  };
  
  // Helper function to check if customer is selected (handles type differences)
  const isSelected = (customer) => {
    if (!customer) return false;
    const customerId = getCustomerId(customer);
    return customerId && String(selectedCustomerId) === String(customerId);
  };

  // Filter customers based on search term
  const filteredCustomers = (customers || []).filter(customer => {
    if (!customer) return false;
    return customer.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
           customer.email?.toLowerCase().includes(searchTerm.toLowerCase());
  });

  // For non-admin users, if only one customer available, auto-select
  useEffect(() => {
    if (currentUser?.role === 'user' && (customers || []).length === 1 && !selectedCustomerId && customers?.[0]) {
      const customerId = getCustomerId(customers[0]);
      if (customerId) {
        onCustomerSelect(customerId);
      }
    }
  }, [customers, currentUser, selectedCustomerId, onCustomerSelect]);

  if (loading) {
    return (
      <div className="space-y-4">
        <label className="block text-sm font-medium text-gray-700">
          Select Customer <span className="text-red-500">*</span>
        </label>
        <div className="w-full px-3 py-3 border border-gray-300 rounded-lg bg-gray-50">
          <div className="flex items-center justify-center">
            <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-blue-600"></div>
            <span className="ml-2 text-gray-600">Loading customers...</span>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="space-y-4">
        <label className="block text-sm font-medium text-gray-700">
          Select Customer <span className="text-red-500">*</span>
        </label>
        <div className="w-full px-3 py-3 border border-red-300 rounded-lg bg-red-50">
          <p className="text-red-600 text-sm">{error}</p>
        </div>
      </div>
    );
  }

  // For customers (USER role), show their info directly (no selection needed)
  if (currentUser?.role === 'user' && (customers || []).length === 1) {
    const customer = customers[0];
    return (
      <div className="space-y-4">
        <label className="block text-sm font-medium text-gray-700">
          Filing Claim For
        </label>
        <div className="w-full px-4 py-3 border border-blue-200 rounded-lg bg-blue-50">
          <div className="flex items-center">
            <User className="w-5 h-5 text-blue-600 mr-3" />
            <div>
              <p className="font-medium text-blue-900">{customer.name}</p>
              <p className="text-sm text-blue-700">{customer.email}</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <label className="block text-sm font-medium text-gray-700">
          Select Customer <span className="text-red-500">*</span>
        </label>
        <span className="text-xs text-gray-500">
          {currentUser?.role === 'admin' ? `${(customers || []).length} customers available` :
           currentUser?.role === 'agent' ? `${(customers || []).length} assigned customers` :
           'Your account'}
        </span>
      </div>
      
      {/* Search Input for multiple customers */}
      {(customers || []).length > 3 && (
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={16} />
          <input
            type="text"
            placeholder={`Search ${(customers || []).length} customers...`}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
          />
        </div>
      )}

      {/* Role-based info message */}
      {customers.length > 1 && (
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
          <p className="text-sm text-blue-800">
            {currentUser?.role === 'admin' ? 
              '💼 As an admin, you can file claims for any customer in the system.' :
              currentUser?.role === 'agent' ? 
              '👨‍💼 You can only file claims for customers with policies assigned to you.' :
              '👤 Filing claim for your account.'
            }
          </p>
        </div>
      )}

      {/* Customer Selection */}
      <div className="space-y-3 max-h-80 overflow-y-auto">
        {filteredCustomers.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <User className="w-12 h-12 mx-auto mb-4 text-gray-400" />
            <p className="font-medium">No customers found</p>
            <p className="text-sm mt-1">No customers available for claim filing</p>
          </div>
        ) : (
          filteredCustomers.map((customer) => (
            <div
              key={getCustomerId(customer)}
              onClick={() => onCustomerSelect(getCustomerId(customer))}
              className={`border rounded-xl p-4 cursor-pointer transition-all ${
                isSelected(customer)
                  ? 'border-blue-500 bg-blue-50 '
                  : 'border-gray-200 hover:border-blue-300 hover:bg-blue-25'
              }`}
            >
              {/* Customer Header */}
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center">
                  <User className={`w-6 h-6 mr-3 ${
                    isSelected(customer) ? 'text-blue-600' : 'text-purple-600'
                  }`} />
                  <div>
                    <h4 className={`font-semibold ${
                      isSelected(customer) ? 'text-blue-900' : 'text-gray-900'
                    }`}>
                      {customer.name}
                    </h4>
                    <p className={`text-sm ${
                      isSelected(customer) ? 'text-blue-700' : 'text-gray-600'
                    }`}>
                      Customer ID: #{getCustomerId(customer)}
                    </p>
                  </div>
                </div>
                
                {isSelected(customer) && (
                  <div className="w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center">
                    <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                )}
              </div>

              {/* Customer Details Grid */}
              <div className="grid grid-cols-1 gap-3">
                <div className="flex items-center">
                  <svg className={`w-4 h-4 mr-2 ${
                    isSelected(customer) ? 'text-blue-600' : 'text-gray-500'
                  }`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 12a4 4 0 10-8 0 4 4 0 008 0zm0 0v1.5a2.5 2.5 0 005 0V12a9 9 0 10-9 9m4.5-1.206a8.959 8.959 0 01-4.5 1.207" />
                  </svg>
                  <div>
                    <p className={`text-xs ${
                      isSelected(customer) ? 'text-blue-700' : 'text-gray-600'
                    }`}>
                      Email Address
                    </p>
                    <p className={`font-medium ${
                      isSelected(customer) ? 'text-blue-900' : 'text-gray-900'
                    }`}>
                      {customer.email}
                    </p>
                  </div>
                </div>

                {customer.phone && (
                  <div className="flex items-center">
                    <svg className={`w-4 h-4 mr-2 ${
                      isSelected(customer) ? 'text-blue-600' : 'text-gray-500'
                    }`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                    </svg>
                    <div>
                      <p className={`text-xs ${
                        isSelected(customer) ? 'text-blue-700' : 'text-gray-600'
                      }`}>
                        Phone Number
                      </p>
                      <p className={`font-medium ${
                        isSelected(customer) ? 'text-blue-900' : 'text-gray-900'
                      }`}>
                        {customer.phone}
                      </p>
                    </div>
                  </div>
                )}

                {customer.address && (
                  <div className="flex items-center">
                    <svg className={`w-4 h-4 mr-2 ${
                      isSelected(customer) ? 'text-blue-600' : 'text-gray-500'
                    }`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                    </svg>
                    <div>
                      <p className={`text-xs ${
                        isSelected(customer) ? 'text-blue-700' : 'text-gray-600'
                      }`}>
                        Address
                      </p>
                      <p className={`font-medium text-sm line-clamp-1 ${
                        isSelected(customer) ? 'text-blue-900' : 'text-gray-900'
                      }`}>
                        {customer.address}
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))
        )}
      </div>

      {customers.length === 0 && (
        <div className="text-center py-8 text-gray-500">
          <User className="w-12 h-12 mx-auto mb-4 text-gray-400" />
          <p className="font-medium">No customers available</p>
          <p className="text-sm mt-1">
            {currentUser?.role === 'agent' 
              ? 'You have no assigned customers'
              : 'No customers found in the system'
            }
          </p>
        </div>
      )}
    </div>
  );
};

export default CustomerSelector; 
import { useState, useEffect } from 'react';
import { Bell, X, CheckCircle, AlertTriangle, Info, Clock, User, UserCheck, Shield } from 'lucide-react';
import { notificationService } from '../../services/index.js';
import toast from 'react-hot-toast';
 
const Notifications = ({ currentUser }) => {
  const [notifications, setNotifications] = useState([]);
  const [filter, setFilter] = useState('all');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
 
  // Load notifications from API
  useEffect(() => {
    if (currentUser) {
      fetchNotifications();
    }
  }, [currentUser]);
 
  const fetchNotifications = async () => {
    try {
      setLoading(true);
      setError(null);
      if (!currentUser?.customerId) {
      const processedNotifications = await notificationService.getAll();
      console.log('Fetched notifications:', processedNotifications);
      setNotifications(processedNotifications);
      } else{
      const processedNotifications = await notificationService.getByCustomer(currentUser.customerId);
      setNotifications(processedNotifications);
      }
    } catch (error) {
      console.error('Error fetching notifications:', error);
      setError('Failed to load notifications');
      toast.error('Failed to load notifications');
      setNotifications([]);
    } finally {
      setLoading(false);
    }
  };
 
  const markAsRead = async (id) => {
    try {
      await notificationService.markAsRead(id);
      setNotifications(prev =>
        prev.map(notif =>
          notif.notificationId === id ? { ...notif, readAt: new Date().toISOString() } : notif
        )
      );
      toast.success('Notification marked as read');
    } catch (error) {
      console.error('Error marking notification as read:', error);
      toast.error('Failed to mark notification as read');
    }
  };
 
  const markAllAsRead = async () => {
    try {
      await notificationService.markAllMyNotificationsAsRead();
      setNotifications(prev =>
        prev.map(notif => ({ ...notif, readAt: new Date().toISOString() }))
      );
      toast.success('All notifications marked as read');
    } catch (error) {
      console.error('Error marking all notifications as read:', error);
      toast.error('Failed to mark all notifications as read');
    }
  };
 
 
 
  const filteredNotifications = notifications.filter(notif => {
    const isRead = notif.readAt != null; // Backend uses readAt timestamp
    if (filter === 'unread') return !isRead;
    if (filter === 'read') return isRead;
    return true;
  });
 
  const getIcon = (category) => {
    switch (category) {
      case 'SUCCESS': return <CheckCircle className="w-5 h-5 text-green-500" />;
      case 'WARNING': return <AlertTriangle className="w-5 h-5 text-yellow-500" />;
      case 'ERROR': return <AlertTriangle className="w-5 h-5 text-red-500" />;
      case 'INFO': return <Info className="w-5 h-5 text-blue-500" />;
      default: return <Bell className="w-5 h-5 text-gray-500" />;
    }
  };
 
  const getBgColor = (category, readAt) => {
    const isRead = readAt != null;
    const baseColors = {
      SUCCESS: isRead ? 'bg-green-50' : 'bg-green-100',
      WARNING: isRead ? 'bg-yellow-50' : 'bg-yellow-100',
      ERROR: isRead ? 'bg-red-50' : 'bg-red-100',
      INFO: isRead ? 'bg-blue-50' : 'bg-blue-100'
    };
    return baseColors[category] || (isRead ? 'bg-gray-50' : 'bg-gray-100');
  };
 
  const getRoleIcon = () => {
    switch (currentUser?.role) {
      case 'user': return <User className="w-4 h-4 text-blue-600" />;
      case 'agent': return <UserCheck className="w-4 h-4 text-purple-600" />;
      case 'admin': return <Shield className="w-4 h-4 text-red-600" />;
      default: return <Bell className="w-4 h-4 text-gray-500" />;
    }
  };
 
  const getRoleLabel = () => {
    switch (currentUser?.role) {
      case 'user': return 'Customer';
      case 'agent': return 'Agent';
      case 'admin': return 'Administrator';
      default: return 'User';
    }
  };
 
  const unreadCount = notifications.filter(n => !n.readAt).length;
 
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <h1 className="text-2xl font-bold text-gray-900">Notifications</h1>
            <div className="flex items-center gap-1 px-2 py-1 bg-gray-100 rounded-full">
              {getRoleIcon()}
              <span className="text-xs font-medium text-gray-700">{getRoleLabel()}</span>
            </div>
          </div>
          <p className="text-gray-600">
            {unreadCount > 0 ? `${unreadCount} unread notifications` : 'All notifications read'}
          </p>
        </div>
        <div className="flex items-center space-x-3">
          <button
            onClick={markAllAsRead}
            className="text-xs text-blue-600 hover:text-blue-800 font-medium disabled:text-gray-400 disabled:cursor-not-allowed cursor-pointer"
            disabled={unreadCount === 0}
          >
            Mark all as read
          </button>
        </div>
      </div>
 
      {/* Filters */}
      <div className="bg-white p-4 rounded-xl shadow-sm">
        <div className="flex items-center space-x-4">
          <span className="text-sm font-medium text-gray-700">Filter:</span>
          <button
            onClick={() => setFilter('all')}
            className={`px-3 py-1 rounded-full text-xs font-medium transition-colors cursor-pointer ${
              filter === 'all'
                ? 'bg-blue-100 text-blue-800'
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            All ({notifications.length})
          </button>
          <button
            onClick={() => setFilter('unread')}
            className={`px-3 py-1 rounded-full text-xs font-medium transition-colors cursor-pointer ${
              filter === 'unread'
                ? 'bg-blue-100 text-blue-800'
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            Unread ({unreadCount})
          </button>
          <button
            onClick={() => setFilter('read')}
            className={`px-3 py-1 rounded-full text-xs font-medium transition-colors cursor-pointer ${
              filter === 'read'
                ? 'bg-blue-100 text-blue-800'
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            Read ({notifications.length - unreadCount})
          </button>
        </div>
      </div>
 
      {/* Notifications List */}
      <div className="space-y-3">
        {loading ? (
          <div className="bg-white p-8 rounded-xl shadow-sm text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">Loading notifications...</h3>
            <p className="text-gray-500">Please wait while we fetch your notifications.</p>
          </div>
        ) : error ? (
          <div className="bg-white p-8 rounded-xl shadow-sm text-center">
            <AlertTriangle className="mx-auto h-12 w-12 text-red-400 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">Error loading notifications</h3>
            <p className="text-gray-500 mb-4">{error}</p>
            <button
              onClick={fetchNotifications}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              Try Again
            </button>
          </div>
        ) : filteredNotifications.length === 0 ? (
          <div className="bg-white p-8 rounded-xl shadow-sm text-center">
            <Bell className="mx-auto h-12 w-12 text-gray-400 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No notifications</h3>
            <p className="text-gray-500">
              {filter === 'all'
                ? "You don't have any notifications yet."
                : `No ${filter} notifications.`
              }
            </p>
          </div>
        ) : (
          filteredNotifications.map((notification) => (
            <div
              key={notification.notificationId}
                              className={`${getBgColor(notification.category, notification.readAt)} p-4 rounded-xl shadow-sm transition-all duration-200 hover:shadow-md`}
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start space-x-3">
                  <div className="flex-shrink-0 mt-1">
                    {getIcon(notification.category)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className={`text-sm font-medium ${notification.read ? 'text-gray-700' : 'text-gray-900'}`}>
                            {notification.title}
                          </h3>
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                            notification.priority === 'High' ? 'bg-red-100 text-red-700' :
                            notification.priority === 'Medium' ? 'bg-yellow-100 text-yellow-700' :
                            'bg-green-100 text-green-700'
                          }`}>
                            {notification.priority}
                          </span>
                        </div>
                        <p className={`mt-1 text-sm ${notification.read ? 'text-gray-500' : 'text-gray-700'}`}>
                          {notification.message}
                        </p>
                        <div className="mt-2 flex items-center space-x-4">
                          <span className="flex items-center text-xs text-gray-500">
                            <Clock className="w-3 h-3 mr-1" />
                            {notification.date}
                          </span>
                          <span className="text-xs text-gray-500">
                            {notification.type}
                          </span>
                          {!notification.readAt && (
                            <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                              New
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="flex items-center space-x-2 ml-4">
                  {!notification.readAt && (
                    <button
                      onClick={() => markAsRead(notification.notificationId)}
                      className="text-xs text-blue-600 hover:text-blue-800 font-medium px-2 py-1 rounded hover:bg-blue-50 cursor-pointer"
                    >
                      Mark as read
                    </button>
                  )}
                  
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
 
export default Notifications;
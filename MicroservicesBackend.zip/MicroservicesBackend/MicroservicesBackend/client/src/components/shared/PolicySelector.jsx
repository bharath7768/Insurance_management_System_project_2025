import { Shield, Calendar, DollarSign, CheckCircle, XCircle } from 'lucide-react';

const PolicySelector = ({ 
  policies, 
  selectedPolicyId, 
  onPolicySelect, 
  loading = false,
  error = null 
}) => {

  if (loading) {
    return (
      <div className="space-y-4">
        <label className="block text-sm font-medium text-gray-700">
          Select Policy <span className="text-red-500">*</span>
        </label>
        <div className="w-full px-3 py-3 border border-gray-300 rounded-lg bg-gray-50">
          <div className="flex items-center justify-center">
            <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-blue-600"></div>
            <span className="ml-2 text-gray-600">Loading policies...</span>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="space-y-4">
        <label className="block text-sm font-medium text-gray-700">
          Select Policy <span className="text-red-500">*</span>
        </label>
        <div className="w-full px-3 py-3 border border-red-300 rounded-lg bg-red-50">
          <p className="text-red-600 text-sm">{error}</p>
        </div>
      </div>
    );
  }

  const formatCurrency = (amount) => {
    return `₹${amount?.toLocaleString() || '0'}`;
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString();
  };

  const isActivePolicy = (policy) => {
    return policy.status === 'ACTIVE';
  };

  const isPolicyExpired = (policy) => {
    if (!policy.endDate) return false;
    return new Date(policy.endDate) < new Date();
  };

  return (
    <div className="space-y-4">
      <label className="block text-sm font-medium text-gray-700">
        Select Policy <span className="text-red-500">*</span>
      </label>
      
      {policies.length === 0 ? (
        <div className="text-center py-8 text-gray-500">
          <Shield className="w-12 h-12 mx-auto mb-4 text-gray-400" />
          <p className="font-medium">No policies available</p>
          <p className="text-sm mt-1">This customer has no active policies for filing claims</p>
        </div>
      ) : (
        <div className="space-y-3 max-h-80 overflow-y-auto">
          {policies.map((policy) => {
            const isExpired = isPolicyExpired(policy);
            const isActive = isActivePolicy(policy);
            const isSelectable = isActive && !isExpired;
            
            return (
              <div
                key={policy.policyId}
                onClick={() => isSelectable && onPolicySelect(policy.policyId)}
                className={`border rounded-xl p-4 transition-all ${
                  !isSelectable
                    ? 'border-gray-200 bg-gray-50 cursor-not-allowed opacity-60'
                    : selectedPolicyId === policy.policyId
                    ? 'border-blue-500 bg-blue-50 cursor-pointer'
                    : 'border-gray-200 hover:border-blue-300 hover:bg-blue-25 cursor-pointer'
                }`}
              >
                {/* Policy Header */}
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center">
                    <Shield className={`w-6 h-6 mr-3 ${
                      selectedPolicyId === policy.policyId ? 'text-blue-600' : 
                      isSelectable ? 'text-green-600' : 'text-gray-400'
                    }`} />
                    <div>
                      <h4 className={`font-semibold ${
                        selectedPolicyId === policy.policyId ? 'text-blue-900' : 
                        isSelectable ? 'text-gray-900' : 'text-gray-500'
                      }`}>
                        {policy.name}
                      </h4>
                      <p className={`text-sm ${
                        selectedPolicyId === policy.policyId ? 'text-blue-700' : 
                        isSelectable ? 'text-gray-600' : 'text-gray-400'
                      }`}>
                        Policy #{policy.policyId}
                      </p>
                    </div>
                  </div>
                  
                  {/* Status Badge */}
                  <div className="flex items-center space-x-2">
                    {isExpired ? (
                      <span className="inline-flex items-center px-2 py-1 text-xs font-medium rounded-full bg-red-100 text-red-800">
                        <XCircle className="w-3 h-3 mr-1" />
                        Expired
                      </span>
                    ) : isActive ? (
                      <span className="inline-flex items-center px-2 py-1 text-xs font-medium rounded-full bg-green-100 text-green-800">
                        <CheckCircle className="w-3 h-3 mr-1" />
                        Active
                      </span>
                    ) : (
                      <span className="inline-flex items-center px-2 py-1 text-xs font-medium rounded-full bg-gray-100 text-gray-800">
                        {policy.status}
                      </span>
                    )}
                    
                    {selectedPolicyId === policy.policyId && (
                      <div className="w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center">
                        <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                      </div>
                    )}
                  </div>
                </div>

                {/* Policy Details Grid */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex items-center">
                    <DollarSign className={`w-4 h-4 mr-2 ${
                      selectedPolicyId === policy.policyId ? 'text-blue-600' : 
                      isSelectable ? 'text-green-600' : 'text-gray-400'
                    }`} />
                    <div>
                      <p className={`text-xs ${
                        selectedPolicyId === policy.policyId ? 'text-blue-700' : 
                        isSelectable ? 'text-gray-600' : 'text-gray-400'
                      }`}>
                        Coverage Amount
                      </p>
                      <p className={`font-semibold ${
                        selectedPolicyId === policy.policyId ? 'text-blue-900' : 
                        isSelectable ? 'text-gray-900' : 'text-gray-500'
                      }`}>
                        {formatCurrency(policy.coverageAmount)}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center">
                    <DollarSign className={`w-4 h-4 mr-2 ${
                      selectedPolicyId === policy.policyId ? 'text-blue-600' : 
                      isSelectable ? 'text-orange-600' : 'text-gray-400'
                    }`} />
                    <div>
                      <p className={`text-xs ${
                        selectedPolicyId === policy.policyId ? 'text-blue-700' : 
                        isSelectable ? 'text-gray-600' : 'text-gray-400'
                      }`}>
                        Premium Amount
                      </p>
                      <p className={`font-semibold ${
                        selectedPolicyId === policy.policyId ? 'text-blue-900' : 
                        isSelectable ? 'text-gray-900' : 'text-gray-500'
                      }`}>
                        {formatCurrency(policy.premiumAmount)}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center">
                    <Calendar className={`w-4 h-4 mr-2 ${
                      selectedPolicyId === policy.policyId ? 'text-blue-600' : 
                      isSelectable ? 'text-blue-600' : 'text-gray-400'
                    }`} />
                    <div>
                      <p className={`text-xs ${
                        selectedPolicyId === policy.policyId ? 'text-blue-700' : 
                        isSelectable ? 'text-gray-600' : 'text-gray-400'
                      }`}>
                        Start Date
                      </p>
                      <p className={`font-semibold ${
                        selectedPolicyId === policy.policyId ? 'text-blue-900' : 
                        isSelectable ? 'text-gray-900' : 'text-gray-500'
                      }`}>
                        {formatDate(policy.startDate)}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center">
                    <Calendar className={`w-4 h-4 mr-2 ${
                      selectedPolicyId === policy.policyId ? 'text-blue-600' : 
                      isExpired ? 'text-red-600' : isSelectable ? 'text-green-600' : 'text-gray-400'
                    }`} />
                    <div>
                      <p className={`text-xs ${
                        selectedPolicyId === policy.policyId ? 'text-blue-700' : 
                        isSelectable ? 'text-gray-600' : 'text-gray-400'
                      }`}>
                        End Date
                      </p>
                      <p className={`font-semibold ${
                        selectedPolicyId === policy.policyId ? 'text-blue-900' : 
                        isExpired ? 'text-red-700' : isSelectable ? 'text-gray-900' : 'text-gray-500'
                      }`}>
                        {formatDate(policy.endDate)}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Coverage Details */}
                {policy.coverageDetails && (
                  <div className="mt-3 pt-3 border-t border-gray-200">
                    <p className={`text-xs ${
                      selectedPolicyId === policy.policyId ? 'text-blue-700' : 
                      isSelectable ? 'text-gray-600' : 'text-gray-400'
                    }`}>
                      Coverage Details
                    </p>
                    <p className={`text-sm mt-1 line-clamp-2 ${
                      selectedPolicyId === policy.policyId ? 'text-blue-800' : 
                      isSelectable ? 'text-gray-700' : 'text-gray-500'
                    }`}>
                      {policy.coverageDetails}
                    </p>
                  </div>
                )}

                {/* Ineligibility Message */}
                {!isSelectable && (
                  <div className="mt-3 pt-3 border-t border-gray-200">
                    <p className="text-xs text-red-600 font-medium">
                      {isExpired ? 'Policy has expired - Cannot file claims' : 
                       !isActive ? 'Policy is not active - Cannot file claims' : 
                       'Policy not eligible for claims'}
                    </p>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
      
      {policies.length > 0 && !policies.some(p => isActivePolicy(p) && !isPolicyExpired(p)) && (
        <div className="mt-4 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
          <p className="text-yellow-800 text-sm font-medium">
            ⚠️ No eligible policies available
          </p>
          <p className="text-yellow-700 text-xs mt-1">
            All policies are either expired or inactive. Claims can only be filed for active policies.
          </p>
        </div>
      )}
    </div>
  );
};

export default PolicySelector; 
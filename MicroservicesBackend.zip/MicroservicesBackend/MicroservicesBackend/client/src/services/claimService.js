import axiosInstance from '../utils/axiosInstance.js';

const claimService = {
  // Get all claims (admin only)
  async getAll() {
    try {
      const response = await axiosInstance.get('/api/claims');
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Failed to fetch claims' };
    }
  },

  // Get claim by ID
  async getById(id) {
    try {
      const response = await axiosInstance.get(`/api/claims/${id}`);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Failed to fetch claim' };
    }
  },

  // Get claims by customer ID
  async getByCustomer(customerId) {
    try {
      const response = await axiosInstance.get(`/api/claims/customer/${customerId}`);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Failed to fetch customer claims' };
    }
  },

  // Get claims by policy ID
  async getByPolicy(policyId) {
    try {
      const response = await axiosInstance.get(`/api/claims/policy/${policyId}`);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Failed to fetch policy claims' };
    }
  },

  // Get claims by agent ID
  async getByAgent(agentId) {
    try {
      const response = await axiosInstance.get(`/api/claims/agent/${agentId}`);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Failed to fetch agent claims' };
    }
  },

  // Get claims by status
  async getByStatus(status) {
    try {
      const response = await axiosInstance.get(`/api/claims/status/${status}`);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Failed to fetch claims by status' };
    }
  },

  // Create new claim
  async create(claimData) {
    try {
      console.log(claimData);
      const response = await axiosInstance.post('/api/claims', claimData);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Failed to create claim' };
    }
  },

  // Update claim
  async update(id, claimData) {
    try {
      const response = await axiosInstance.put(`/api/claims/${id}`, claimData);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Failed to update claim' };
    }
  },

  // Process claim (approve/reject)
  async process(id, processData) {
    try {
      const response = await axiosInstance.put(`/api/claims/${id}/process`, processData);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Failed to process claim' };
    }
  },

  // Get remaining coverage for a policy (coverage amount - existing claims)
  async getRemainingCoverage(policyId) {
    try {
      const [policy, claims] = await Promise.all([
        axiosInstance.get(`/api/policies/${policyId}`),
        axiosInstance.get(`/api/claims/policy/${policyId}`)
      ]);
      
      const coverageAmount = policy.data.coverageAmount || 0;
      const existingClaims = claims.data || [];
      
      // Calculate total of approved and pending claims (rejected claims don't count)
      const totalExistingClaims = existingClaims
        .filter(claim => ['APPROVED', 'FILED', 'UNDER_REVIEW'].includes(claim.status))
        .reduce((sum, claim) => sum + (claim.claimAmount || 0), 0);
      
      const remainingCoverage = coverageAmount - totalExistingClaims;
      
      return {
        coverageAmount,
        totalExistingClaims,
        remainingCoverage: Math.max(0, remainingCoverage), // Ensure non-negative
        existingClaimsCount: existingClaims.length
      };
    } catch (error) {
      throw error.response?.data || { message: 'Failed to get remaining coverage' };
    }
  }
};

export default claimService; 
import axiosInstance from '../utils/axiosInstance.js';

const policyService = {
  // Get all policies (admin only)
  async getAll() {
    try {
      const response = await axiosInstance.get('/api/policies');
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Failed to fetch policies' };
    }
  },

  // Get policy by ID
  async getById(id) {
    try {
      const response = await axiosInstance.get(`/api/policies/${id}`);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Failed to fetch policy' };
    }
  },

  // Get policies by customer ID
  async getByCustomer(customerId) {
    try {
      const response = await axiosInstance.get(`/api/policies/customer/${customerId}`);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Failed to fetch customer policies' };
    }
  },

  // Get policies by agent ID
  async getByAgent(agentId) {
    try {
      const response = await axiosInstance.get(`/api/policies/agent/${agentId}`);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Failed to fetch agent policies' };
    }
  },

  // Create new policy
  async create(policyData) {
    try {
      const response = await axiosInstance.post('/api/policies', policyData);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Failed to create policy' };
    }
  },

  // Update policy
  async update(id, policyData) {
    try {
      const response = await axiosInstance.put(`/api/policies/${id}`, policyData);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Failed to update policy' };
    }
  },

  // Mark policy as inactive
  async markInactive(id, reason) {
    try {
      const response = await axiosInstance.put(`/api/policies/${id}/inactive`, { reason });
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Failed to mark policy as inactive' };
    }
  },

  // Get expiring policies
  async getExpiring() {
    try {
      const response = await axiosInstance.get('/api/policies/expiring');
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Failed to fetch expiring policies' };
    }
  }
};

export default policyService; 
import axiosInstance from '../utils/axiosInstance.js';

const authService = {
  // Login user and return JWT token
  async login(credentials) {
    try {
      const response = await axiosInstance.post('/api/auth/login', {
        username: credentials.email, // Backend expects username field
        password: credentials.password
      });
      
      console.log(response.data)
      const { token, role } = response.data.data;
      
      // Store token in localStorage
      localStorage.setItem('token', token);
      
      return { token, role: role.toLowerCase() };
    } catch (error) {
      throw error.response?.data || { message: 'Login failed' };
    }
  },

  // Get user profile based on role
  async getProfile(role) {
    try {
      const normalizedRole = role.toLowerCase();
      let endpoint;
      switch (normalizedRole) {
        case 'user':
          endpoint = '/api/customers/me';
          break;
        case 'agent':
          endpoint = '/api/agents/profile';
          break;
        case 'admin':
        default:
          // Admin doesn't have a specific profile endpoint
          return { name: 'Admin User', role: 'admin' };
      }
      
      const response = await axiosInstance.get(endpoint);
      return { ...response.data, role: normalizedRole };
    } catch (error) {
      throw error.response?.data || { message: 'Failed to fetch profile' };
    }
  },

  // Login and fetch profile in one call
  async loginWithProfile(credentials) {
    try {
      // First authenticate
      const { token, role } = await this.login(credentials);
      
      // Then fetch profile data
      const profile = await this.getProfile(role);
      
      return {
        token,
        user: profile
      };
    } catch (error) {
      // Clear token if login/profile fetch fails
      localStorage.removeItem('token');
      throw error;
    }
  },

  // Reset/Change password
  async resetPassword(passwordData) {
    try {
      const response = await axiosInstance.put('/api/auth/reset-password', {
        currentPassword: passwordData.currentPassword,
        newPassword: passwordData.newPassword
      });
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Failed to reset password' };
    }
  },

  // Logout user
  logout() {
    localStorage.removeItem('token');
  },

  // Check if user is authenticated
  isAuthenticated() {
    return !!localStorage.getItem('token');
  },

  // Get stored token
  getToken() {
    return localStorage.getItem('token');
  },

  // Create user (admin only)
  async createUser(userData) {
    try {
      const response = await axiosInstance.post('/api/auth/admin/create-user', userData);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Failed to create user' };
    }
  },

  // Update user status (admin only)
  async updateUserStatus(userId, isActive) {
    try {
      const response = await axiosInstance.put(`/api/auth/admin/users/${userId}/status`, null, {
        params: { isActive }
      });
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Failed to update user status' };
    }
  },

  // Get user status (admin only)
  async getUserStatus(userId) {
    try {
      const response = await axiosInstance.get(`/api/auth/admin/users/${userId}/status`);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Failed to get user status' };
    }
  }
};

export default authService; 
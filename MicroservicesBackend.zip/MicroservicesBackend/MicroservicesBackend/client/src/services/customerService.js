import axiosInstance from '../utils/axiosInstance.js';

const customerService = {
  // Get all customers (admin only)
  async getAll() {
    try {
      const response = await axiosInstance.get('/api/customers');
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Failed to fetch customers' };
    }
  },

  // Get customer by ID
  async getById(id) {
    try {
      const response = await axiosInstance.get(`/api/customers/${id}`);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Failed to fetch customer' };
    }
  },

  // Get current customer profile
  async getProfile() {
    try {
      const response = await axiosInstance.get('/api/customers/me');
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Failed to fetch profile' };
    }
  },

  // Update customer profile (self)
  async updateProfile(profileData) {
    try {
      const response = await axiosInstance.put('/api/customers/me', profileData);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Failed to update profile' };
    }
  },

  // Get my assigned agent
  async getMyAgent() {
    try {
      const response = await axiosInstance.get('/api/customers/my-agent');
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Failed to fetch agent info' };
    }
  },

  // Update customer
  async update(id, customerData) {
    try {
      const response = await axiosInstance.put(`/api/customers/${id}`, customerData);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Failed to update customer' };
    }
  },

  // Create customer (admin only)
  async create(customerData) {
    try {
      const response = await axiosInstance.post('/api/customers', customerData);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Failed to create customer' };
    }
  },

  // Activate customer (admin only)
  async activate(customerId) {
    try {
      const response = await axiosInstance.post(`/api/customers/${customerId}/activate`);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Failed to activate customer' };
    }
  },

  // Deactivate customer (admin only)
  async deactivate(customerId) {
    try {
      const response = await axiosInstance.post(`/api/customers/${customerId}/deactivate`);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Failed to deactivate customer' };
    }
  },

  // Get customer status (admin/agent only)
  async getStatus(customerId) {
    try {
      const response = await axiosInstance.get(`/api/customers/${customerId}/status`);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Failed to get customer status' };
    }
  }
};

export default customerService;


import axiosInstance from '../utils/axiosInstance.js';

const notificationService = {
  // ENHANCED API - Get all notifications for current user (auto-detects role)
  async getMyNotifications() {
    try {
      const response = await axiosInstance.get('/api/notifications/my');
      return response.data;
    } catch (error) {
      console.error('Error fetching notifications:', error);
      throw error.response?.data || { message: 'Failed to fetch notifications' };
    }
  },

  // Get unread notifications for current user
  async getMyUnreadNotifications() {
    try {
      const response = await axiosInstance.get('/api/notifications/my/unread');
      return response.data;
    } catch (error) {
      console.error('Error fetching unread notifications:', error);
      throw error.response?.data || { message: 'Failed to fetch unread notifications' };
    }
  },

  // Get unread count for current user
  async getMyUnreadCount() {
    try {
      const response = await axiosInstance.get('/api/notifications/my/unread/count');
      return response.data || 0;
    } catch (error) {
      console.error('Error fetching unread count:', error);
      return 0; // Return 0 if error, don't break UI
    }
  },

  // Mark all notifications as read for current user
  async markAllMyNotificationsAsRead() {
    try {
      const response = await axiosInstance.put('/api/notifications/my/read-all');
      return response.data;
    } catch (error) {
      console.error('Error marking all as read:', error);
      throw error.response?.data || { message: 'Failed to mark all notifications as read' };
    }
  },

  // Mark specific notification as read
  async markAsRead(notificationId) {
    try {
      const response = await axiosInstance.put(`/api/notifications/${notificationId}/read`);
      return response.data;
    } catch (error) {
      console.error('Error marking notification as read:', error);
      throw error.response?.data || { message: 'Failed to mark notification as read' };
    }
  },

  // Map backend response to frontend format
  mapBackendToFrontend(backendNotification) {
    return {
      notificationID: backendNotification.notificationId,
      targetRole: this.mapBackendRoleToFrontend(backendNotification.targetRole),
      targetID: backendNotification.customerId,
      type: this.mapBackendTypeToFrontend(backendNotification.type),
      category: backendNotification.category?.toLowerCase() || 'info',
      title: backendNotification.title,
      message: backendNotification.message,
      date: backendNotification.createdAt?.split('T')[0] || new Date().toISOString().split('T')[0],
      read: backendNotification.readAt !== null && backendNotification.readAt !== undefined,
      priority: this.mapBackendPriorityToFrontend(backendNotification.priority)
    };
  },

  // Map backend role to frontend format
  mapBackendRoleToFrontend(backendRole) {
    const roleMap = {
      'USER': 'user',
      'AGENT': 'agent',
      'ADMIN': 'admin'
    };
    return roleMap[backendRole] || 'user';
  },

  // Map backend notification type to frontend format
  mapBackendTypeToFrontend(backendType) {
    const typeMap = {
      'CLAIM_STATUS_UPDATE': 'Claim Update',
      'POLICY_RENEWAL': 'Policy Renewal',
      'PAYMENT_REMINDER': 'Payment Due',
      'WELCOME_MESSAGE': 'Welcome',
      'GENERAL_ALERT': 'System Alert'
    };
    return typeMap[backendType] || backendType?.replace(/_/g, ' ') || 'Notification';
  },

  // Map backend priority to frontend format
  mapBackendPriorityToFrontend(backendPriority) {
    if (!backendPriority) return 'Medium';
    const priorityMap = {
      'HIGH': 'High',
      'MEDIUM': 'Medium', 
      'LOW': 'Low'
    };
    return priorityMap[backendPriority] || 'Medium';
  },

  // Get processed notifications (mapped to frontend format)
  async getProcessedNotifications() {
    try {
      const backendNotifications = await this.getMyNotifications();
      return backendNotifications.map(notification => this.mapBackendToFrontend(notification));
    } catch (error) {
      console.error('Error fetching processed notifications:', error);
      return [];
    }
  },

  // LEGACY METHODS (for backward compatibility)
  
  // Get notification by ID
  async getById(id) {
    try {
      const response = await axiosInstance.get(`/api/notifications/${id}`);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Failed to fetch notification' };
    }
  },

  // Get notifications by customer ID (legacy - use getMyNotifications instead)
  async getByCustomer(customerId) {
    try {
      const response = await axiosInstance.get(`/api/notifications/customer/${customerId}`);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Failed to fetch customer notifications' };
    }
  },

  // Create notification (admin/agent only)
  async create(notification) {
    try {
      const response = await axiosInstance.post('/api/notifications', notification);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Failed to create notification' };
    }
  },

  // Legacy aliases for backward compatibility
  getAll: function() { return this.getMyNotifications(); },
  getUnread: function() { return this.getMyUnreadNotifications(); },
  getUnreadCount: function() { return this.getMyUnreadCount(); },
  markAllAsRead: function() { return this.markAllMyNotificationsAsRead(); }
};

export default notificationService; 
import axiosInstance from '../utils/axiosInstance.js';

const agentService = {
  // Get all agents (admin only)
  async getAll() {
    try {
      const response = await axiosInstance.get('/api/agents');
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Failed to fetch agents' };
    }
  },

  // Get agent by ID
  async getById(id) {
    try {
      const response = await axiosInstance.get(`/api/agents/${id}`);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Failed to fetch agent' };
    }
  },

  // Get agent profile
  async getProfile() {
    try {
      const response = await axiosInstance.get('/api/agents/profile');
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Failed to fetch profile' };
    }
  },

  // Update agent profile (self)
  async updateProfile(profileData) {
    try {
      const response = await axiosInstance.put('/api/agents/profile', profileData);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Failed to update profile' };
    }
  },

  // Get active agents
  async getActive() {
    try {
      const response = await axiosInstance.get('/api/agents/active');
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Failed to fetch active agents' };
    }
  },

  // Update agent
  async update(id, agentData) {
    try {
      const response = await axiosInstance.put(`/api/agents/${id}`, agentData);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Failed to update agent' };
    }
  },

  // Deactivate agent
  async deactivate(id) {
    try {
      const response = await axiosInstance.post(`/api/agents/${id}/deactivate`);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Failed to deactivate agent' };
    }
  },

  // Activate agent
  async activate(id) {
    try {
      const response = await axiosInstance.post(`/api/agents/${id}/activate`);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Failed to activate agent' };
    }
  },

  // Create agent (admin only)
  async create(agentData) {
    try {
      const response = await axiosInstance.post('/api/agents', agentData);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Failed to create agent' };
    }
  }
};

export default agentService; 
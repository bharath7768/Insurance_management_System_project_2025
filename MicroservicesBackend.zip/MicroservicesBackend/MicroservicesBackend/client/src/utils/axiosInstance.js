import axios from "axios"
import { BASE_URL } from "./constant.js";

const axiosInstance = axios.create({
    baseURL: BASE_URL,
    timeout: 20000,
    headers: {
        "Content-Type": "application/json"
    }
});

axiosInstance.interceptors.request.use(
    (config) => {
        // Don't add token for login endpoints
        const isLoginEndpoint = config.url?.includes('/api/auth/login');
        
        if (!isLoginEndpoint) {
            const accessToken = localStorage.getItem("token");
            if (accessToken){
                config.headers.Authorization = `Bearer ${accessToken}`;
            }
        }
        return config;
    }, (error) => {
        return Promise.reject(error)
    }
);

export default axiosInstance;

import { createContext, useContext, useState, useEffect } from 'react';

// initialize context
const UserContext = createContext();

// custom hook to access context easily
// only to used under userprovider
export const useUser = () => {
  const context = useContext(UserContext);
  if (!context) {
    throw new Error('useUser must be used within a UserProvider');
  }
  return context;
};

export const UserProvider = ({ children }) => {
  const [currentUser, setCurrentUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  // load user from localStorage on app start
  useEffect(() => {
    const savedUser = localStorage.getItem('insurance_user');
    const savedToken = localStorage.getItem('token');
    
    if (savedUser && savedToken) {
      try {
        const user = JSON.parse(savedUser);
        setCurrentUser(user);
      } catch (error) {
        console.error('Error parsing saved user:', error);
        localStorage.removeItem('insurance_user');
        localStorage.removeItem('token');
      }
    }
    
    setIsLoading(false);
  }, []);

  const login = (userData) => {
    let user;
    
    if (typeof userData === 'string') {
      // handle role
      user = { role: userData, name: 'User' };
    } else {
      // handle user object
      user = {
        id: userData.id || 1,
        name: userData.name || userData.email || 'User',
        email: userData.email,
        role: userData.role,
        phone: userData.phone,
        address: userData.address,
        dateOfBirth: userData.dateOfBirth,
        joinDate: userData.joinDate,
        customerId: userData.customerId,
        agentId: userData.agentId
      };
    }
    
    setCurrentUser(user);
    // save to localstorage
    localStorage.setItem('insurance_user', JSON.stringify(user));
  };

  const logout = () => {
    setCurrentUser(null);
    localStorage.removeItem('insurance_user');
    localStorage.removeItem('token');
  };

  // Update user profile in context and localStorage
  const updateProfile = (updatedUserData) => {
    const updatedUser = { ...currentUser, ...updatedUserData };
    setCurrentUser(updatedUser);
    localStorage.setItem('insurance_user', JSON.stringify(updatedUser));
  };

  const value = {
    currentUser,
    isLoading,
    login,
    logout,
    updateProfile
  };

  return <UserContext.Provider value={value}>{children}</UserContext.Provider>;
}; 